"""
AI & Marketing Routes
=====================
Works offline with template-based generation.
Enable real AI by setting ai_enabled=true and ai_api_key in Admin > Settings.
"""
import json
import random
import re
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, g
from database import SessionLocal, SiteSetting, Product, MarketingCampaign
from auth_helper import require_admin

ai_bp = Blueprint("ai", __name__)

ADJECTIVES = ["powerful", "elegant", "modern", "stunning", "professional", "beautiful", "dynamic", "responsive", "clean"]
BENEFITS = ["boost conversions", "impress your visitors", "save development time", "grow your business", "stand out online"]


def get_setting(db, key, default=""):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return s.value if s else default


def is_ai_enabled(db):
    return get_setting(db, "ai_enabled", "false").lower() == "true"


def call_ai_api(db, prompt, max_tokens=200):
    """Call real AI API if configured, otherwise use offline template generation."""
    api_key = get_setting(db, "ai_api_key", "")
    provider = get_setting(db, "ai_provider", "openai")
    model = get_setting(db, "ai_model", "gpt-3.5-turbo")

    if not api_key:
        return None, "AI API key not configured. Using offline template generation."

    try:
        import urllib.request
        import urllib.error

        if provider == "openai":
            payload = json.dumps({
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
            }).encode()
            req = urllib.request.Request(
                "https://api.openai.com/v1/chat/completions",
                data=payload,
                headers={"Authorization": "Bearer {}".format(api_key), "Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())
                return data["choices"][0]["message"]["content"].strip(), None

        return None, "Unsupported AI provider: {}".format(provider)
    except Exception as e:
        return None, "AI API error: {}".format(str(e))


def offline_description(name, category, product_type):
    adj = random.choice(ADJECTIVES)
    benefit = random.choice(BENEFITS)
    return (
        "{name} is a {adj} {type} designed for the modern web. "
        "Perfect for {cat} projects, this {type} helps you {benefit} "
        "with ease. Built with best practices, it includes everything you need "
        "to launch a professional online presence quickly. "
        "Fully responsive, well-documented, and easy to customize.".format(
            name=name, adj=adj, type=product_type, cat=category, benefit=benefit
        )
    )


def offline_meta_title(name, site_name):
    return "{} | {}".format(name[:40], site_name)[:60]


def offline_meta_description(name, category):
    return "Buy {} — a premium {} product. High quality, easy to use, and fully customizable. Download instantly after purchase.".format(name, category)[:157]


def offline_keywords(name, category, tags=None):
    parts = [name.lower(), category]
    if tags:
        parts.extend(tags[:5])
    return ", ".join(parts)[:200]


# ─── AI Content Generation ────────────────────────────────────────────────────

@ai_bp.route("/api/admin/ai/status", methods=["GET"])
@require_admin
def ai_status():
    db = SessionLocal()
    try:
        enabled = is_ai_enabled(db)
        has_key = bool(get_setting(db, "ai_api_key", ""))
        provider = get_setting(db, "ai_provider", "openai")
        model = get_setting(db, "ai_model", "gpt-3.5-turbo")
        return jsonify({
            "aiEnabled": enabled,
            "hasApiKey": has_key,
            "provider": provider,
            "model": model,
            "offlineMode": not has_key,
            "message": "AI ready (online)" if (enabled and has_key) else "Using offline template generation",
        })
    finally:
        db.close()


@ai_bp.route("/api/admin/ai/generate-description", methods=["POST"])
@require_admin
def generate_description():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        name = data.get("name", "")
        category = data.get("category", "template")
        product_type = data.get("type", "template")
        existing_desc = data.get("description", "")

        if not name:
            return jsonify({"error": "Product name is required"}), 400

        ai_result = None
        offline = True
        message = ""

        if is_ai_enabled(db) and get_setting(db, "ai_api_key", ""):
            prompt = (
                "Write a professional product description for a digital product called '{}'. "
                "Category: {}. Type: {}. "
                "Keep it 2-3 sentences, highlight key benefits, no markdown.".format(name, category, product_type)
            )
            ai_result, err = call_ai_api(db, prompt, 150)
            if ai_result:
                offline = False
            else:
                message = err

        description = ai_result if ai_result else offline_description(name, category, product_type)
        return jsonify({
            "description": description,
            "offline": offline,
            "message": message or ("Generated with AI" if not offline else "Generated offline (set AI API key for better results)"),
        })
    finally:
        db.close()


@ai_bp.route("/api/admin/ai/generate-meta", methods=["POST"])
@require_admin
def ai_generate_meta():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        product_id = data.get("productId")
        name = data.get("name", "")
        category = data.get("category", "template")
        tags = data.get("tags", [])

        if not name and not product_id:
            return jsonify({"error": "productId or name required"}), 400

        p = None
        if product_id:
            p = db.query(Product).filter(Product.id == int(product_id)).first()
            if p:
                name = name or p.name
                category = category or p.category
                tags = tags or (p.tags if isinstance(p.tags, list) else [])

        site_name = get_setting(db, "site_name", "Web Designs & Care")
        meta_title = offline_meta_title(name, site_name)
        meta_description = offline_meta_description(name, category)
        keywords = offline_keywords(name, category, tags)

        if is_ai_enabled(db) and get_setting(db, "ai_api_key", ""):
            prompt = "Write an SEO meta title (max 60 chars) and meta description (max 157 chars) for: '{}' ({} product). Return JSON: {{\"metaTitle\": \"...\", \"metaDescription\": \"...\"}}".format(name, category)
            ai_result, _ = call_ai_api(db, prompt, 100)
            if ai_result:
                try:
                    parsed = json.loads(ai_result)
                    meta_title = parsed.get("metaTitle", meta_title)[:60]
                    meta_description = parsed.get("metaDescription", meta_description)[:157]
                except Exception:
                    pass

        # Optionally save to product
        if p and data.get("save", False):
            if not p.meta_title:
                p.meta_title = meta_title
            if not p.meta_description:
                p.meta_description = meta_description
            if not p.keywords:
                p.keywords = keywords
            db.commit()

        return jsonify({
            "metaTitle": meta_title,
            "metaDescription": meta_description,
            "keywords": keywords,
        })
    finally:
        db.close()


@ai_bp.route("/api/admin/ai/generate-social-post", methods=["POST"])
@require_admin
def generate_social_post():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        product_name = data.get("productName", "")
        platform = data.get("platform", "twitter")
        price = data.get("price", "")

        if not product_name:
            return jsonify({"error": "productName is required"}), 400

        if platform == "twitter":
            post = "Just launched: {} — get it for ${} on our store! #webdesign #template #developers".format(product_name, price)
        elif platform == "facebook":
            post = "Excited to announce: {} is now available! Perfect for modern web projects. Price: ${}. Visit our store now!".format(product_name, price)
        elif platform == "instagram":
            post = "New drop: {}! Starting at ${}. Swipe to see more. Link in bio! #webdesign #template #developers #uidesign".format(product_name, price)
        else:
            post = "Check out our new product: {} — available now for ${}!".format(product_name, price)

        if is_ai_enabled(db) and get_setting(db, "ai_api_key", ""):
            prompt = "Write a short {} post for a digital product called '{}' priced at ${}. Keep it engaging and under 280 chars for Twitter. No hashtag spam.".format(platform, product_name, price)
            ai_result, _ = call_ai_api(db, prompt, 100)
            if ai_result:
                post = ai_result

        return jsonify({"post": post, "platform": platform, "characterCount": len(post)})
    finally:
        db.close()


@ai_bp.route("/api/admin/ai/generate-email", methods=["POST"])
@require_admin
def generate_email():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        campaign_type = data.get("type", "promotion")
        product_name = data.get("productName", "")
        discount = data.get("discount", "")
        site_name = get_setting(db, "site_name", "Web Designs & Care")

        if campaign_type == "promotion":
            subject = "Exclusive offer: {} off {}".format(discount, product_name) if discount else "New product: {}".format(product_name)
            body = """Hi {{name}},

We have an exciting offer for you! {product} is now available{discount}.

Click here to check it out: {{site_url}}/products

Best regards,
{site}""".format(
                product=product_name,
                discount=" with {}% off".format(discount) if discount else "",
                site=site_name
            )
        elif campaign_type == "welcome":
            subject = "Welcome to {}!".format(site_name)
            body = """Hi {{name}},

Welcome to {}! We're excited to have you on board.

Browse our collection of premium digital products and use coupon WELCOME for 15% off your first order.

Visit: {{site_url}}

Best regards,
The {} Team""".format(site_name, site_name)
        else:
            subject = "Update from {}".format(site_name)
            body = "Hi {{name}},\n\nThank you for being a valued customer.\n\nBest regards,\n{}".format(site_name)

        return jsonify({"subject": subject, "body": body, "type": campaign_type})
    finally:
        db.close()


# ─── Automarketing ────────────────────────────────────────────────────────────

@ai_bp.route("/api/admin/automarketing/status", methods=["GET"])
@require_admin
def automarketing_status():
    db = SessionLocal()
    try:
        enabled = get_setting(db, "automarketing_enabled", "false") == "true"
        return jsonify({
            "enabled": enabled,
            "platforms": {
                "facebook": get_setting(db, "automarketing_facebook", "false") == "true",
                "twitter": get_setting(db, "automarketing_twitter", "false") == "true",
                "instagram": get_setting(db, "automarketing_instagram", "false") == "true",
            },
            "schedule": get_setting(db, "automarketing_schedule", "daily"),
            "message": "Automarketing active" if enabled else "Enable in Admin > Settings > Automarketing",
        })
    finally:
        db.close()


@ai_bp.route("/api/admin/automarketing/schedule", methods=["POST"])
@require_admin
def schedule_automarketing():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        s = db.query(SiteSetting).filter(SiteSetting.key == "automarketing_enabled").first()
        if s:
            s.value = "true"
        else:
            db.add(SiteSetting(key="automarketing_enabled", value="true"))
        db.commit()
        return jsonify({
            "success": True,
            "schedule": data.get("schedule", "daily"),
            "message": "Automarketing scheduled. Posts will be generated and queued automatically.",
        })
    finally:
        db.close()


@ai_bp.route("/api/admin/ai/bulk-generate", methods=["POST"])
@require_admin
def bulk_generate():
    """Generate AI content for all products missing descriptions/meta."""
    db = SessionLocal()
    try:
        site_name = get_setting(db, "site_name", "Web Designs & Care")
        products = db.query(Product).all()
        updated = 0
        for p in products:
            changed = False
            if not p.description or len(p.description) < 50:
                p.description = offline_description(p.name, p.category, p.type)
                changed = True
            if not p.meta_title:
                p.meta_title = offline_meta_title(p.name, site_name)
                changed = True
            if not p.meta_description:
                p.meta_description = offline_meta_description(p.name, p.category)
                changed = True
            if not p.keywords:
                tags = p.tags if isinstance(p.tags, list) else []
                p.keywords = offline_keywords(p.name, p.category, tags)
                changed = True
            if changed:
                updated += 1
        db.commit()
        return jsonify({"updated": updated, "total": len(products), "message": "Content generated for {} products".format(updated)})
    finally:
        db.close()
