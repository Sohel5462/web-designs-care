"""
Notification utility — call push_notification() inside any route
to create a persistent admin notification without committing.

Usage:
    push_notification(db, "New Order", "Order #42 placed — $29.00", "order", "/api/admin/orders", "🛒")
    db.commit()   # caller's commit picks it up
"""

from database import Notification


def push_notification(db, title: str, message: str,
                      notif_type: str = "info",
                      link: str = None,
                      icon: str = "🔔",
                      user_id: int = None):
    """
    Add a Notification row to the session (no commit — caller commits).
    Safe to call even if the session is in a bad state (errors are swallowed).
    """
    try:
        notif = Notification(
            user_id=user_id,
            title=title,
            message=message,
            type=notif_type,
            icon=icon,
            link=link,
            is_read=False,
        )
        db.add(notif)
    except Exception:
        pass
