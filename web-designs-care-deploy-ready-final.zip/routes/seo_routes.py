"""
SEO Routes — Sitemap, Robots.txt, Structured Data, Meta Analysis
All SEO features work offline. Google indexing needs internet.
"""
import json
import re
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, Response, g
from database import SessionLocal, Product, SiteSetting
from auth_helper import require_admin

seo_bp = Blueprint("seo", __name__)


def get_setting(db, key, default=""):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return s.value if s else default


def set_setting(db, key, value):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    if s:
        s.value = value
    else:
        db.add(SiteSetting(key=key, value=value))
    db.commit()


# ─── Public SEO endpoints ────────────────────────────────────────────────────

@seo_bp.route("/api/seo/meta", methods=["GET"])
def seo_meta():
    """Dynamic meta tags for any page path — used by React frontend."""
    path = request.args.get("path", "/")
    db = SessionLocal()
    try:
        site_name = get_setting(db, "site_name", "Web Designs & Care")
        site_desc = get_setting(db, "seo_default_meta_description", "Premium digital assets for modern developers.")
        og_image = get_setting(db, "seo_og_image_url", "")
        parts = [p for p in path.strip("/").split("/") if p]
        title = site_name
        description = site_desc
        if len(parts) >= 2 and parts[0] == "products":
            slug = parts[1]
            p = db.query(Product).filter(Product.slug == slug, Product.status == "published").first()
            if p:
                title = (p.meta_title or "{} | {}".format(p.name, site_name))
                description = p.meta_description or p.description or site_desc
                og_image = og_image or p.thumbnail_url or ""
        return jsonify({"title": title, "description": description, "ogImage": og_image, "siteName": site_name})
    finally:
        db.close()


@seo_bp.route("/sitemap.xml", methods=["GET"])
def sitemap_xml():
    """Auto-generate XML sitemap for all published products."""
    db = SessionLocal()
    try:
        site_url = get_setting(db, "site_url", "http://localhost:5000")
        products = db.query(Product).filter(Product.status == "published").all()

        urls = [
            {"loc": site_url + "/", "priority": "1.0", "changefreq": "weekly"},
            {"loc": site_url + "/products", "priority": "0.9", "changefreq": "daily"},
            {"loc": site_url + "/about", "priority": "0.5", "changefreq": "monthly"},
            {"loc": site_url + "/contact", "priority": "0.5", "changefreq": "monthly"},
        ]

        for p in products:
            urls.append({
                "loc": "{}/products/{}".format(site_url, p.slug),
                "priority": "0.8",
                "changefreq": "weekly",
                "lastmod": p.updated_at.strftime("%Y-%m-%d") if p.updated_at else datetime.now().strftime("%Y-%m-%d"),
            })

        xml_parts = ['<?xml version="1.0" encoding="UTF-8"?>']
        xml_parts.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')
        for url in urls:
            xml_parts.append("  <url>")
            xml_parts.append("    <loc>{}</loc>".format(url["loc"]))
            xml_parts.append("    <priority>{}</priority>".format(url.get("priority", "0.5")))
            xml_parts.append("    <changefreq>{}</changefreq>".format(url.get("changefreq", "weekly")))
            if "lastmod" in url:
                xml_parts.append("    <lastmod>{}</lastmod>".format(url["lastmod"]))
            xml_parts.append("  </url>")
        xml_parts.append("</urlset>")

        return Response("\n".join(xml_parts), mimetype="application/xml")
    finally:
        db.close()


@seo_bp.route("/robots.txt", methods=["GET"])
def robots_txt():
    """Serve configurable robots.txt."""
    db = SessionLocal()
    try:
        content = get_setting(db, "seo_robots_txt", "User-agent: *\nAllow: /\nSitemap: /sitemap.xml")
        return Response(content, mimetype="text/plain")
    finally:
        db.close()


@seo_bp.route("/api/seo/structured-data/<slug>", methods=["GET"])
def structured_data(slug):
    """JSON-LD structured data for a product (for Google rich results)."""
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.slug == slug, Product.status == "published").first()
        if not p:
            return jsonify({"error": "Not found"}), 404

        site_name = get_setting(db, "site_name", "Web Designs & Care")
        site_url = get_setting(db, "site_url", "http://localhost:5000")
        currency = get_setting(db, "currency", "USD")

        schema = {
            "@context": "https://schema.org/",
            "@type": "Product",
            "name": p.name,
            "description": p.description or "",
            "image": p.thumbnail_url or "",
            "url": "{}/products/{}".format(site_url, p.slug),
            "brand": {"@type": "Brand", "name": site_name},
            "offers": {
                "@type": "Offer",
                "priceCurrency": currency,
                "price": str(p.price),
                "availability": "https://schema.org/InStock",
                "seller": {"@type": "Organization", "name": site_name},
            },
        }
        if p.rating and float(p.rating) > 0:
            schema["aggregateRating"] = {
                "@type": "AggregateRating",
                "ratingValue": str(p.rating),
                "reviewCount": str(p.rating_count or 0),
            }

        return jsonify(schema)
    finally:
        db.close()


# ─── Admin SEO management ────────────────────────────────────────────────────

@seo_bp.route("/api/admin/seo/settings", methods=["GET"])
@require_admin
def get_seo_settings():
    """Get all SEO-related settings. Returns camelCase keys for the admin panel."""
    db = SessionLocal()
    try:
        # Map: DB key → camelCase key
        key_map = {
            "site_url":                          "siteUrl",
            "seo_robots_txt":                    "seoRobotsTxt",
            "seo_google_analytics_id":           "seoGoogleAnalyticsId",
            "seo_google_site_verification":      "seoGoogleSiteVerification",
            "seo_bing_site_verification":        "seoBingSiteVerification",
            "seo_structured_data_enabled":       "seoStructuredDataEnabled",
            "seo_sitemap_enabled":               "seoSitemapEnabled",
            "seo_default_meta_title_template":   "seoDefaultMetaTitleTemplate",
            "seo_default_meta_description":      "seoDefaultMetaDescription",
            "seo_og_image_url":                  "seoOgImageUrl",
            "seo_twitter_handle":                "seoTwitterHandle",
            "seo_twitter_card_type":             "seoTwitterCardType",
            "seo_canonical_url":                 "seoCanonicalUrl",
        }
        result = {}
        for db_key, camel_key in key_map.items():
            val = get_setting(db, db_key, "")
            result[camel_key] = val
            result[db_key] = val  # keep snake_case aliases for compatibility
        return jsonify(result)
    finally:
        db.close()


@seo_bp.route("/api/admin/seo/settings", methods=["PUT", "POST"])
@require_admin
def update_seo_settings():
    """Update SEO settings. Accepts both camelCase and snake_case keys."""
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        # Map camelCase → DB key (and also accept snake_case directly)
        camel_to_db = {
            "siteUrl":                        "site_url",
            "seoRobotsTxt":                   "seo_robots_txt",
            "seoGoogleAnalyticsId":           "seo_google_analytics_id",
            "seoGoogleSiteVerification":      "seo_google_site_verification",
            "seoBingSiteVerification":        "seo_bing_site_verification",
            "seoStructuredDataEnabled":       "seo_structured_data_enabled",
            "seoSitemapEnabled":              "seo_sitemap_enabled",
            "seoDefaultMetaTitleTemplate":    "seo_default_meta_title_template",
            "seoDefaultMetaDescription":      "seo_default_meta_description",
            "seoOgImageUrl":                  "seo_og_image_url",
            "seoTwitterHandle":               "seo_twitter_handle",
            "seoTwitterCardType":             "seo_twitter_card_type",
            "seoCanonicalUrl":                "seo_canonical_url",
        }
        # Also allow direct snake_case keys
        direct_keys = set(camel_to_db.values())
        saved = 0
        for field, val in data.items():
            db_key = camel_to_db.get(field) or (field if field in direct_keys else None)
            if db_key:
                set_setting(db, db_key, str(val))
                saved += 1
        return jsonify({"success": True, "saved": saved})
    finally:
        db.close()


@seo_bp.route("/api/admin/seo/analysis", methods=["GET"])
@require_admin
def seo_analysis():
    """SEO health check for all products."""
    db = SessionLocal()
    try:
        products = db.query(Product).filter(Product.status == "published").all()
        total = len(products)
        issues = []
        scores = []

        for p in products:
            product_issues = []
            score = 100

            if not p.meta_title:
                product_issues.append("Missing meta title")
                score -= 20
            elif len(p.meta_title) > 60:
                product_issues.append("Meta title too long (>60 chars)")
                score -= 5
            elif len(p.meta_title) < 30:
                product_issues.append("Meta title too short (<30 chars)")
                score -= 5

            if not p.meta_description:
                product_issues.append("Missing meta description")
                score -= 20
            elif len(p.meta_description) > 160:
                product_issues.append("Meta description too long (>160 chars)")
                score -= 5
            elif len(p.meta_description) < 70:
                product_issues.append("Meta description too short (<70 chars)")
                score -= 5

            if not p.keywords:
                product_issues.append("Missing keywords")
                score -= 10

            if not p.thumbnail_url:
                product_issues.append("Missing thumbnail image (bad for social sharing)")
                score -= 15

            if not p.description or len(p.description) < 100:
                product_issues.append("Description too short (<100 chars)")
                score -= 10

            scores.append(max(0, score))
            if product_issues:
                issues.append({
                    "productId": p.id,
                    "productName": p.name,
                    "slug": p.slug,
                    "score": max(0, score),
                    "issues": product_issues,
                })

        avg_score = round(sum(scores) / len(scores)) if scores else 0
        perfect = sum(1 for s in scores if s == 100)

        return jsonify({
            "totalProducts": total,
            "averageScore": avg_score,
            "perfectScore": perfect,
            "productsWithIssues": len(issues),
            "issues": sorted(issues, key=lambda x: x["score"]),
        })
    finally:
        db.close()


@seo_bp.route("/api/admin/seo/generate-meta/<int:product_id>", methods=["POST"])
@require_admin
def generate_meta(product_id):
    """Auto-generate SEO meta tags for a product."""
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.id == product_id).first()
        if not p:
            return jsonify({"error": "Not found"}), 404

        site_name = get_setting(db, "site_name", "Web Designs & Care")
        template = get_setting(db, "seo_default_meta_title_template", "{name} | {site_name}")

        meta_title = template.replace("{name}", p.name).replace("{site_name}", site_name)
        if len(meta_title) > 60:
            meta_title = meta_title[:57] + "..."

        meta_description = ""
        if p.description:
            clean = re.sub(r"<[^>]+>", "", p.description)
            meta_description = clean[:157] + "..." if len(clean) > 157 else clean
        if not meta_description:
            meta_description = "Buy {} - {}. Available at {}.".format(p.name, p.type, site_name)

        tags_list = []
        if p.tags:
            tags_list = p.tags if isinstance(p.tags, list) else []
        if p.category:
            tags_list.append(p.category)
        keywords = ", ".join(tags_list[:10]) if tags_list else p.name.lower()

        # Save generated values
        if not p.meta_title:
            p.meta_title = meta_title
        if not p.meta_description:
            p.meta_description = meta_description
        if not p.keywords:
            p.keywords = keywords
        db.commit()

        return jsonify({
            "metaTitle": meta_title,
            "metaDescription": meta_description,
            "keywords": keywords,
            "saved": True,
        })
    finally:
        db.close()


@seo_bp.route("/api/admin/seo/bulk-generate-meta", methods=["POST"])
@require_admin
def bulk_generate_meta():
    """Auto-generate SEO meta for ALL products that are missing them."""
    db = SessionLocal()
    try:
        site_name = get_setting(db, "site_name", "Web Designs & Care")
        template = get_setting(db, "seo_default_meta_title_template", "{name} | {site_name}")
        products = db.query(Product).all()
        updated = 0

        for p in products:
            changed = False

            if not p.meta_title:
                title = template.replace("{name}", p.name).replace("{site_name}", site_name)
                p.meta_title = title[:57] + "..." if len(title) > 57 else title
                changed = True

            if not p.meta_description:
                desc = re.sub(r"<[^>]+>", "", p.description or "")
                if not desc:
                    desc = "Buy {} - {}. Available at {}.".format(p.name, p.type, site_name)
                p.meta_description = desc[:157] + "..." if len(desc) > 157 else desc
                changed = True

            if not p.keywords:
                tags = p.tags if isinstance(p.tags, list) else []
                if p.category:
                    tags.append(p.category)
                p.keywords = ", ".join(tags[:10]) if tags else p.name.lower()
                changed = True

            if changed:
                updated += 1

        db.commit()
        return jsonify({"updated": updated, "total": len(products)})
    finally:
        db.close()


@seo_bp.route("/api/admin/seo/sitemap-preview", methods=["GET"])
@require_admin
def sitemap_preview():
    """Preview sitemap URLs without serving as XML."""
    db = SessionLocal()
    try:
        site_url = get_setting(db, "site_url", "http://localhost:5000")
        products = db.query(Product).filter(Product.status == "published").all()
        urls = [
            site_url + "/",
            site_url + "/products",
        ]
        for p in products:
            urls.append("{}/products/{}".format(site_url, p.slug))
        return jsonify({"totalUrls": len(urls), "urls": urls})
    finally:
        db.close()
