from flask import Blueprint, request, jsonify, g
from database import SessionLocal, CartItem, Product
from auth_helper import require_auth

cart_bp = Blueprint("cart", __name__)


def cart_item_to_dict(item: CartItem) -> dict:
    p = item.product
    return {
        "id": item.id,
        "productId": item.product_id,
        "product": {
            "id": p.id,
            "name": p.name,
            "slug": p.slug,
            "price": str(p.price),
            "thumbnailUrl": p.thumbnail_url,
            "category": p.category,
        } if p else None,
        "createdAt": item.created_at.isoformat() if item.created_at else None,
    }


@cart_bp.route("/api/cart", methods=["GET"])
@require_auth
def get_cart():
    db = SessionLocal()
    try:
        items = db.query(CartItem).filter(CartItem.user_id == g.user.id).all()
        return jsonify([cart_item_to_dict(i) for i in items])
    finally:
        db.close()


@cart_bp.route("/api/cart", methods=["POST"])
@require_auth
def add_to_cart():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        product_id = data.get("productId")
        if not product_id:
            return jsonify({"error": "productId required"}), 400
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return jsonify({"error": "Product not found"}), 404
        existing = db.query(CartItem).filter(CartItem.user_id == g.user.id, CartItem.product_id == product_id).first()
        if existing:
            return jsonify(cart_item_to_dict(existing))
        item = CartItem(user_id=g.user.id, product_id=product_id)
        db.add(item)
        db.commit()
        db.refresh(item)
        return jsonify(cart_item_to_dict(item)), 201
    finally:
        db.close()


@cart_bp.route("/api/cart/<int:item_id>", methods=["DELETE"])
@require_auth
def remove_from_cart(item_id):
    db = SessionLocal()
    try:
        item = db.query(CartItem).filter(CartItem.id == item_id, CartItem.user_id == g.user.id).first()
        if not item:
            return jsonify({"error": "Not found"}), 404
        db.delete(item)
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()
