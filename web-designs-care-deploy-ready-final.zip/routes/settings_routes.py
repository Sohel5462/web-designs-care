import re
import json
from flask import Blueprint, request, jsonify
from database import SessionLocal, SiteSetting, ProductCategory
from auth_helper import require_admin

settings_bp = Blueprint("settings", __name__)

SAFE_KEY = re.compile(r'^[a-zA-Z][a-zA-Z0-9_]*$')


def camel_to_snake(name):
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def get_setting(db, key, default=""):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return s.value if s and s.value is not None else default


def set_setting(db, key, value):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    if s:
        s.value = str(value) if not isinstance(value, str) else value
    else:
        db.add(SiteSetting(key=key, value=str(value) if not isinstance(value, str) else value))


def bool_val(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, str):
        return v.lower()
    return str(v)


def get_all_settings(db) -> dict:
    rows = db.query(SiteSetting).all()
    raw = {}
    for row in rows:
        raw[row.key] = row.value or ""

    # Template types (JSON list)
    try:
        template_types = json.loads(raw.get("template_types", "[]"))
    except Exception:
        template_types = ["React", "Vue.js", "Nuxt.js", "Angular", "Svelte",
                          "Laravel (PHP)", "Django (Python)", "Shopify Liquid",
                          "Next.js", "Portfolio", "SaaS / App UI"]

    return {
        # Site basics
        "siteName": raw.get("site_name", "Web Designs & Care"),
        "siteTagline": raw.get("site_tagline", "Premium Digital Assets"),
        "siteDescription": raw.get("site_description", ""),
        "siteUrl": raw.get("site_url", "http://localhost:5000"),
        "contactEmail": raw.get("contact_email", ""),
        "footerText": raw.get("footer_text", ""),
        "currency": raw.get("currency", "USD"),
        "language": raw.get("language", "en"),
        "maintenanceMode": raw.get("maintenance_mode", "false") == "true",
        "demoMode": raw.get("demo_mode", "true") == "true",
        # Appearance
        "logoUrl": raw.get("logo_url", ""),
        "faviconUrl": raw.get("favicon_url", ""),
        "defaultTheme": raw.get("default_theme", "light"),
        "primaryColor": raw.get("primary_color", "#3b82f6"),
        "secondaryColor": raw.get("secondary_color", "#1e293b"),
        "accentColor": raw.get("accent_color", "#8b5cf6"),
        "customCss": raw.get("custom_css", ""),
        "customHeaderHtml": raw.get("custom_header_html", ""),
        "customFooterHtml": raw.get("custom_footer_html", ""),
        "fontFamily": raw.get("font_family", "Inter"),
        "heroTitle": raw.get("hero_title", ""),
        "heroSubtitle": raw.get("hero_subtitle", ""),
        "heroBgUrl": raw.get("hero_bg_url", ""),
        "announcementBar": raw.get("announcement_bar", ""),
        "tagline": raw.get("site_tagline", "Premium Digital Assets"),
        # Payments
        "stripeEnabled": raw.get("stripe_enabled", "false") == "true",
        "stripePublishableKey": raw.get("stripe_publishable_key", ""),
        # SEO
        "seoSitemapEnabled": raw.get("seo_sitemap_enabled", "true") == "true",
        "seoStructuredDataEnabled": raw.get("seo_structured_data_enabled", "true") == "true",
        "seoGoogleAnalyticsId": raw.get("seo_google_analytics_id", ""),
        "seoGoogleSiteVerification": raw.get("seo_google_site_verification", ""),
        "seoBingSiteVerification": raw.get("seo_bing_site_verification", ""),
        "seoDefaultMetaTitleTemplate": raw.get("seo_default_meta_title_template", "{name} | {site_name}"),
        "seoDefaultMetaDescription": raw.get("seo_default_meta_description", ""),
        "seoOgImageUrl": raw.get("seo_og_image_url", ""),
        "seoTwitterHandle": raw.get("seo_twitter_handle", ""),
        "seoTwitterCardType": raw.get("seo_twitter_card_type", "summary_large_image"),
        "seoRobotsTxt": raw.get("seo_robots_txt", "User-agent: *\nAllow: /"),
        # Dropshipping / AutoDS
        "dropshippingEnabled": raw.get("dropshipping_enabled", "false") == "true",
        "autodsEnabled": raw.get("autods_enabled", "false") == "true",
        "autodsApiKey": raw.get("autods_api_key", ""),
        "autodsUserId": raw.get("autods_user_id", ""),
        "autodsAutoFulfill": raw.get("autods_auto_fulfill", "false") == "true",
        "autodysPriceMarkup": raw.get("autods_price_markup", "30"),
        "autodsDefaultSupplier": raw.get("autods_default_supplier", "amazon"),
        "autodsStockMonitoring": raw.get("autods_stock_monitoring", "true") == "true",
        "autodysPriceMonitoring": raw.get("autods_price_monitoring", "true") == "true",
        "autodsAutoTitles": raw.get("autods_auto_titles", "true") == "true",
        # AI
        "aiEnabled": raw.get("ai_enabled", "false") == "true",
        "aiProvider": raw.get("ai_provider", "openai"),
        "aiApiKey": raw.get("ai_api_key", ""),
        "aiModel": raw.get("ai_model", "gpt-3.5-turbo"),
        # Marketing
        "marketingEmailEnabled": raw.get("marketing_email_enabled", "false") == "true",
        "marketingSmtpHost": raw.get("marketing_smtp_host", ""),
        "marketingSmtpPort": raw.get("marketing_smtp_port", "587"),
        "marketingSmtpUser": raw.get("marketing_smtp_user", ""),
        "marketingFromEmail": raw.get("marketing_from_email", ""),
        "marketingFromName": raw.get("marketing_from_name", "Web Designs & Care"),
        # Automarketing
        "automarketingEnabled": raw.get("automarketing_enabled", "false") == "true",
        "automarketingFacebook": raw.get("automarketing_facebook", "false") == "true",
        "automarketingTwitter": raw.get("automarketing_twitter", "false") == "true",
        "automarketingInstagram": raw.get("automarketing_instagram", "false") == "true",
        "automarketingSchedule": raw.get("automarketing_schedule", "daily"),
        # Template types
        "templateTypes": template_types,
        # Social Media
        "socialFacebook": raw.get("social_facebook", ""),
        "socialTwitter": raw.get("social_twitter", ""),
        "socialInstagram": raw.get("social_instagram", ""),
        "socialYoutube": raw.get("social_youtube", ""),
        "socialLinkedin": raw.get("social_linkedin", ""),
        "socialTiktok": raw.get("social_tiktok", ""),
        "socialGithub": raw.get("social_github", ""),
        "socialDiscord": raw.get("social_discord", ""),
        "socialTelegram": raw.get("social_telegram", ""),
        # Chatbot
        "chatbotEnabled": raw.get("chatbot_enabled", "true") == "true",
        "chatbotGreeting": raw.get("chatbot_greeting", "\U0001f44b Hi! How can I help you today?"),
        "chatbotColor": raw.get("chatbot_color", "#3b82f6"),
        "chatbotAiProvider": raw.get("chatbot_ai_provider", "local"),
        "chatbotApiKey": raw.get("chatbot_api_key", ""),
        "chatbotAiModel": raw.get("chatbot_ai_model", "gemini-1.5-flash"),
        # Wallet & Store
        "walletMinTopup": float(raw.get("wallet_min_topup", "1") or 1),
        "walletMaxTopup": float(raw.get("wallet_max_topup", "500") or 500),
        "taxRate": float(raw.get("tax_rate", "0") or 0),
        "downloadLinkExpiry": int(raw.get("download_link_expiry", "48") or 48),
        "guestCheckout": raw.get("guest_checkout", "false") == "true",
        "reviewsEnabled": raw.get("reviews_enabled", "true") == "true",
        # Aliases — backward compat for storefront / mobile clients
        "storeName": raw.get("site_name", "Web Designs & Care"),
        "tagline": raw.get("site_tagline", "Premium Digital Assets"),
        "currencySymbol": raw.get("currency_symbol", "$"),
        "currencyCode": raw.get("currency", "USD"),
    }


@settings_bp.route("/api/settings", methods=["GET"])
def get_settings():
    db = SessionLocal()
    try:
        return jsonify(get_all_settings(db))
    finally:
        db.close()


@settings_bp.route("/api/settings", methods=["PUT", "PATCH"])
@require_admin
def update_settings():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        # Map camelCase API keys → snake_case DB keys
        field_map = {
            "siteName": "site_name",
            "siteTagline": "site_tagline",
            "siteDescription": "site_description",
            "siteUrl": "site_url",
            "contactEmail": "contact_email",
            "footerText": "footer_text",
            "currency": "currency",
            "language": "language",
            "maintenanceMode": "maintenance_mode",
            "demoMode": "demo_mode",
            "logoUrl": "logo_url",
            "faviconUrl": "favicon_url",
            "defaultTheme": "default_theme",
            "primaryColor": "primary_color",
            "secondaryColor": "secondary_color",
            "accentColor": "accent_color",
            "customCss": "custom_css",
            "customHeaderHtml": "custom_header_html",
            "customFooterHtml": "custom_footer_html",
            "stripeEnabled": "stripe_enabled",
            "stripePublishableKey": "stripe_publishable_key",
            "stripeSecretKey": "stripe_secret_key",
            "stripeWebhookSecret": "stripe_webhook_secret",
            "seoSitemapEnabled": "seo_sitemap_enabled",
            "seoStructuredDataEnabled": "seo_structured_data_enabled",
            "seoGoogleAnalyticsId": "seo_google_analytics_id",
            "seoGoogleSiteVerification": "seo_google_site_verification",
            "seoBingSiteVerification": "seo_bing_site_verification",
            "seoDefaultMetaTitleTemplate": "seo_default_meta_title_template",
            "seoDefaultMetaDescription": "seo_default_meta_description",
            "seoOgImageUrl": "seo_og_image_url",
            "seoTwitterHandle": "seo_twitter_handle",
            "seoTwitterCardType": "seo_twitter_card_type",
            "seoRobotsTxt": "seo_robots_txt",
            "seoCanonicalUrl": "seo_canonical_url",
            "dropshippingEnabled": "dropshipping_enabled",
            "autodsEnabled": "autods_enabled",
            "autodsApiKey": "autods_api_key",
            "autodsUserId": "autods_user_id",
            "autodsAutoFulfill": "autods_auto_fulfill",
            "autodysPriceMarkup": "autods_price_markup",
            "autodsDefaultSupplier": "autods_default_supplier",
            "autodsStockMonitoring": "autods_stock_monitoring",
            "autodysPriceMonitoring": "autods_price_monitoring",
            "autodsAutoTitles": "autods_auto_titles",
            "dropshippingProcessingDays": "dropshipping_processing_days",
            "dropshippingReturnPolicy": "dropshipping_return_policy",
            "dropshippingShippingNote": "dropshipping_shipping_note",
            "aiEnabled": "ai_enabled",
            "aiProvider": "ai_provider",
            "aiApiKey": "ai_api_key",
            "aiModel": "ai_model",
            "marketingEmailEnabled": "marketing_email_enabled",
            "marketingSmtpHost": "marketing_smtp_host",
            "marketingSmtpPort": "marketing_smtp_port",
            "marketingSmtpUser": "marketing_smtp_user",
            "marketingSmtpPass": "marketing_smtp_pass",
            "marketingFromEmail": "marketing_from_email",
            "marketingFromName": "marketing_from_name",
            "automarketingEnabled": "automarketing_enabled",
            "automarketingFacebook": "automarketing_facebook",
            "automarketingTwitter": "automarketing_twitter",
            "automarketingInstagram": "automarketing_instagram",
            "automarketingSchedule": "automarketing_schedule",
            # Social media
            "socialFacebook": "social_facebook",
            "socialTwitter": "social_twitter",
            "socialInstagram": "social_instagram",
            "socialYoutube": "social_youtube",
            "socialLinkedin": "social_linkedin",
            "socialTiktok": "social_tiktok",
            "socialGithub": "social_github",
            "socialDiscord": "social_discord",
            "socialTelegram": "social_telegram",
            # Chatbot
            "chatbotEnabled": "chatbot_enabled",
            "chatbotGreeting": "chatbot_greeting",
            "chatbotColor": "chatbot_color",
            "chatbotAiProvider": "chatbot_ai_provider",
            "chatbotApiKey": "chatbot_api_key",
            "chatbotAiModel": "chatbot_ai_model",
            # Wallet & Store
            "walletMinTopup": "wallet_min_topup",
            "walletMaxTopup": "wallet_max_topup",
            "taxRate": "tax_rate",
            "downloadLinkExpiry": "download_link_expiry",
            "guestCheckout": "guest_checkout",
            "reviewsEnabled": "reviews_enabled",
            "currencySymbol": "currency_symbol",
            "storeName": "site_name",
            "tagline": "site_tagline",
            "fontFamily": "font_family",
            "heroTitle": "hero_title",
            "heroSubtitle": "hero_subtitle",
            "heroBgUrl": "hero_bg_url",
            "announcementBar": "announcement_bar",
        }

        for api_key, db_key in field_map.items():
            if api_key in data:
                val = data[api_key]
                if isinstance(val, bool):
                    val = "true" if val else "false"
                elif isinstance(val, list):
                    val = json.dumps(val)
                else:
                    val = str(val)
                set_setting(db, db_key, val)

        # Also accept templateTypes as a JSON list
        if "templateTypes" in data:
            v = data["templateTypes"]
            if isinstance(v, list):
                set_setting(db, "template_types", json.dumps(v))
            else:
                set_setting(db, "template_types", str(v))

        # Accept any remaining safe snake_case keys directly
        for k, v in data.items():
            if k not in field_map and k != "templateTypes" and SAFE_KEY.match(k):
                db_key = camel_to_snake(k) if k[0].islower() and any(c.isupper() for c in k) else k
                if isinstance(v, bool):
                    v = "true" if v else "false"
                elif isinstance(v, list):
                    v = json.dumps(v)
                else:
                    v = str(v)
                set_setting(db, db_key, v)

        db.commit()
        return jsonify({"success": True, "settings": get_all_settings(db)})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Product Category Management ─────────────────────────────────────────────

@settings_bp.route("/api/admin/settings/product-categories", methods=["GET"])
@require_admin
def get_product_categories():
    db = SessionLocal()
    try:
        cats = db.query(ProductCategory).order_by(ProductCategory.sort_order, ProductCategory.name).all()
        return jsonify([{
            "id": c.id, "name": c.name, "slug": c.slug,
            "description": c.description, "isActive": c.is_active, "sortOrder": c.sort_order,
        } for c in cats])
    finally:
        db.close()


@settings_bp.route("/api/admin/settings/product-categories", methods=["POST"])
@require_admin
def create_product_category():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        name = data.get("name", "").strip()
        if not name:
            return jsonify({"error": "Name is required"}), 400
        slug = data.get("slug", "") or re.sub(r'[^a-z0-9-]', '-', name.lower()).strip('-')
        existing = db.query(ProductCategory).filter(ProductCategory.slug == slug).first()
        if existing:
            return jsonify({"error": "Category slug already exists"}), 409
        cat = ProductCategory(
            name=name, slug=slug,
            description=data.get("description", ""),
            is_active=data.get("isActive", True),
            sort_order=data.get("sortOrder", 0),
        )
        db.add(cat)
        db.commit()
        db.refresh(cat)
        return jsonify({"id": cat.id, "name": cat.name, "slug": cat.slug, "isActive": cat.is_active}), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@settings_bp.route("/api/admin/settings/product-categories/<int:cat_id>", methods=["PUT", "PATCH"])
@require_admin
def update_product_category(cat_id):
    db = SessionLocal()
    try:
        cat = db.query(ProductCategory).filter(ProductCategory.id == cat_id).first()
        if not cat:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        if "name" in data and data["name"].strip():
            cat.name = data["name"].strip()
        if "slug" in data and data["slug"].strip():
            cat.slug = data["slug"].strip()
        if "description" in data:
            cat.description = data["description"]
        if "isActive" in data:
            cat.is_active = bool(data["isActive"])
        if "sortOrder" in data:
            cat.sort_order = int(data["sortOrder"])
        db.commit()
        return jsonify({"id": cat.id, "name": cat.name, "slug": cat.slug, "isActive": cat.is_active})
    finally:
        db.close()


@settings_bp.route("/api/admin/settings/product-categories/<int:cat_id>", methods=["DELETE"])
@require_admin
def delete_product_category(cat_id):
    db = SessionLocal()
    try:
        cat = db.query(ProductCategory).filter(ProductCategory.id == cat_id).first()
        if cat:
            db.delete(cat)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Bulk settings reset ──────────────────────────────────────────────────────

@settings_bp.route("/api/admin/settings/reset", methods=["POST"])
@require_admin
def reset_settings():
    db = SessionLocal()
    try:
        db.query(SiteSetting).delete()
        db.commit()
        return jsonify({"success": True, "message": "All settings reset to defaults. Restart the app to re-seed."})
    finally:
        db.close()
