import re
import json
import os
from flask import Blueprint, request, jsonify, g
from sqlalchemy import or_, and_, desc, asc, func
from database import SessionLocal, Product, Review, User
from auth_helper import require_auth, require_admin, get_current_user

product_bp = Blueprint("products", __name__)


def _make_unique_slug(db, base_slug, exclude_id=None):
    """Generate a unique slug, appending -2, -3 etc. if needed."""
    slug = base_slug
    counter = 1
    while True:
        q = db.query(Product).filter(Product.slug == slug)
        if exclude_id:
            q = q.filter(Product.id != exclude_id)
        if not q.first():
            return slug
        counter += 1
        slug = "{}-{}".format(base_slug, counter)


def product_to_dict(p: Product) -> dict:
    return {
        "id": p.id,
        "name": p.name,
        "slug": p.slug,
        "description": p.description,
        "category": p.category,
        "type": p.type,
        "price": str(p.price),
        "originalPrice": str(p.original_price) if p.original_price else None,
        "discount": p.discount,
        "thumbnailUrl": p.thumbnail_url,
        "previewUrl": p.preview_url,
        "demoUrl": p.demo_url,
        "fileKey": p.file_key,
        "fileName": p.file_name,
        "fileSize": p.file_size,
        "status": p.status,
        "rating": str(p.rating or "0.00"),
        "ratingCount": p.rating_count,
        "downloads": p.downloads,
        "sales": p.sales,
        "tags": p.tags or [],
        "features": p.features or [],
        "metaTitle": p.meta_title,
        "metaDescription": p.meta_description,
        "keywords": p.keywords,
        "createdAt": p.created_at.isoformat() if p.created_at else None,
        "updatedAt": p.updated_at.isoformat() if p.updated_at else None,
    }


# ─── Public Product Routes ────────────────────────────────────────────────────

@product_bp.route("/api/products", methods=["GET"])
def list_products():
    db = SessionLocal()
    try:
        q = db.query(Product).filter(Product.status == "published")
        category = request.args.get("category")
        search = request.args.get("search")
        sort_by = request.args.get("sortBy", "newest")
        min_price = request.args.get("minPrice", type=float)
        max_price = request.args.get("maxPrice", type=float)
        limit = min(int(request.args.get("limit", 12)), 100)
        offset = int(request.args.get("offset", 0))

        if category:
            q = q.filter(Product.category == category)
        if search:
            q = q.filter(or_(
                Product.name.ilike("%{}%".format(search)),
                Product.description.ilike("%{}%".format(search)),
                Product.keywords.ilike("%{}%".format(search)),
            ))
        if min_price is not None:
            q = q.filter(Product.price >= min_price)
        if max_price is not None:
            q = q.filter(Product.price <= max_price)

        sort_map = {
            "price-low": asc(Product.price),
            "price-high": desc(Product.price),
            "rating": desc(Product.rating),
            "popular": desc(Product.downloads),
            "sales": desc(Product.sales),
        }
        q = q.order_by(sort_map.get(sort_by, desc(Product.created_at)))

        total = q.count()
        products = q.offset(offset).limit(limit).all()
        return jsonify({"products": [product_to_dict(p) for p in products], "total": total})
    finally:
        db.close()


@product_bp.route("/api/products/featured", methods=["GET"])
def featured_products():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 6)), 20)
        products = db.query(Product).filter(Product.status == "published").order_by(desc(Product.sales)).limit(limit).all()
        return jsonify([product_to_dict(p) for p in products])
    finally:
        db.close()


@product_bp.route("/api/products/new-arrivals", methods=["GET"])
def new_arrivals():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 8)), 20)
        products = db.query(Product).filter(Product.status == "published").order_by(desc(Product.created_at)).limit(limit).all()
        return jsonify([product_to_dict(p) for p in products])
    finally:
        db.close()


@product_bp.route("/api/products/categories", methods=["GET"])
def list_categories():
    """Get all product categories with counts."""
    db = SessionLocal()
    try:
        cats = db.query(Product.category, func.count(Product.id)).filter(
            Product.status == "published"
        ).group_by(Product.category).all()
        return jsonify([{"name": c, "count": n} for c, n in cats])
    finally:
        db.close()


@product_bp.route("/api/products/<slug>", methods=["GET"])
def get_product(slug):
    db = SessionLocal()
    try:
        # Try slug first, then numeric ID
        if slug.isdigit():
            p = db.query(Product).filter(Product.id == int(slug)).first()
        else:
            p = db.query(Product).filter(Product.slug == slug).first()
        if not p:
            return jsonify({"error": "Product not found"}), 404
        return jsonify(product_to_dict(p))
    finally:
        db.close()


@product_bp.route("/api/products/<int:product_id>/reviews", methods=["GET"])
def get_product_reviews(product_id):
    db = SessionLocal()
    try:
        reviews = db.query(Review, User).join(User, Review.user_id == User.id).filter(
            Review.product_id == product_id
        ).order_by(desc(Review.created_at)).all()
        return jsonify([{
            "id": rev.id,
            "rating": rev.rating,
            "comment": rev.comment,
            "createdAt": rev.created_at.isoformat() if rev.created_at else None,
            "user": {"id": user.id, "name": user.name},
        } for rev, user in reviews])
    finally:
        db.close()


# ─── Admin Product Routes ─────────────────────────────────────────────────────

@product_bp.route("/api/admin/products", methods=["GET"])
@require_admin
def admin_list_products():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 20)), 100)
        offset = int(request.args.get("offset", 0))
        search = request.args.get("search", "")
        q = db.query(Product)
        status = request.args.get("status")
        category = request.args.get("category")
        if status:
            q = q.filter(Product.status == status)
        if category:
            q = q.filter(Product.category == category)
        if search:
            q = q.filter(or_(
                Product.name.ilike("%{}%".format(search)),
                Product.slug.ilike("%{}%".format(search)),
            ))
        total = q.count()
        products = q.order_by(desc(Product.created_at)).offset(offset).limit(limit).all()
        return jsonify({"products": [product_to_dict(p) for p in products], "total": total})
    finally:
        db.close()


@product_bp.route("/api/admin/products/stats", methods=["GET"])
@require_admin
def admin_product_stats():
    """Product statistics for admin dashboard."""
    db = SessionLocal()
    try:
        total = db.query(Product).count()
        published = db.query(Product).filter(Product.status == "published").count()
        draft = db.query(Product).filter(Product.status == "draft").count()
        archived = db.query(Product).filter(Product.status == "archived").count()
        total_downloads = db.query(func.sum(Product.downloads)).scalar() or 0
        total_sales = db.query(func.sum(Product.sales)).scalar() or 0
        cats = db.query(Product.category, func.count(Product.id)).group_by(Product.category).all()
        return jsonify({
            "total": total,
            "published": published,
            "draft": draft,
            "archived": archived,
            "totalDownloads": int(total_downloads),
            "totalSales": int(total_sales),
            "byCategory": [{"category": c, "count": n} for c, n in cats],
        })
    finally:
        db.close()


@product_bp.route("/api/admin/products", methods=["POST"])
@require_admin
def admin_create_product():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        name = (data.get("name") or "").strip()
        if not name:
            return jsonify({"error": "Product name is required"}), 400

        base_slug = data.get("slug") or re.sub(r"[^a-z0-9-]", "-", name.lower()).strip("-")
        base_slug = re.sub(r"-+", "-", base_slug)
        slug = _make_unique_slug(db, base_slug)

        p = Product(
            name=name,
            slug=slug,
            description=data.get("description", ""),
            category=data.get("category", "templates"),
            type=data.get("type", "template"),
            price=float(data.get("price", 0)),
            original_price=float(data.get("originalPrice")) if data.get("originalPrice") else None,
            discount=int(data.get("discount", 0)),
            thumbnail_url=data.get("thumbnailUrl", ""),
            preview_url=data.get("previewUrl", ""),
            demo_url=data.get("demoUrl", ""),
            status=data.get("status", "draft"),
            tags=data.get("tags", []),
            features=data.get("features", []),
            meta_title=data.get("metaTitle", ""),
            meta_description=data.get("metaDescription", ""),
            keywords=data.get("keywords", ""),
        )
        db.add(p)
        db.commit()
        db.refresh(p)
        return jsonify(product_to_dict(p)), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@product_bp.route("/api/admin/products/<int:product_id>", methods=["GET"])
@require_admin
def admin_get_product(product_id):
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.id == product_id).first()
        if not p:
            return jsonify({"error": "Not found"}), 404
        return jsonify(product_to_dict(p))
    finally:
        db.close()


@product_bp.route("/api/admin/products/<int:product_id>", methods=["PUT", "PATCH"])
@require_admin
def admin_update_product(product_id):
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.id == product_id).first()
        if not p:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}

        # Handle slug uniqueness on update
        if "slug" in data and data["slug"] != p.slug:
            data["slug"] = _make_unique_slug(db, data["slug"], exclude_id=product_id)

        for field, col in {
            "name": "name", "description": "description", "category": "category",
            "type": "type", "price": "price", "originalPrice": "original_price",
            "discount": "discount", "thumbnailUrl": "thumbnail_url",
            "previewUrl": "preview_url", "demoUrl": "demo_url", "slug": "slug",
            "status": "status", "tags": "tags", "features": "features",
            "metaTitle": "meta_title", "metaDescription": "meta_description",
            "keywords": "keywords",
        }.items():
            if field in data:
                setattr(p, col, data[field])
        db.commit()
        db.refresh(p)
        return jsonify(product_to_dict(p))
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@product_bp.route("/api/admin/products/<int:product_id>", methods=["DELETE"])
@require_admin
def admin_delete_product(product_id):
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.id == product_id).first()
        if not p:
            return jsonify({"error": "Not found"}), 404
        db.delete(p)
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


@product_bp.route("/api/admin/products/<int:product_id>/duplicate", methods=["POST"])
@require_admin
def admin_duplicate_product(product_id):
    """Clone/duplicate an existing product."""
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.id == product_id).first()
        if not p:
            return jsonify({"error": "Not found"}), 404

        base_slug = "{}-copy".format(p.slug)
        slug = _make_unique_slug(db, base_slug)

        clone = Product(
            name="{} (Copy)".format(p.name),
            slug=slug,
            description=p.description,
            category=p.category,
            type=p.type,
            price=p.price,
            original_price=p.original_price,
            discount=p.discount,
            thumbnail_url=p.thumbnail_url,
            preview_url=p.preview_url,
            demo_url=p.demo_url,
            status="draft",
            tags=p.tags,
            features=p.features,
            meta_title=p.meta_title,
            meta_description=p.meta_description,
            keywords=p.keywords,
        )
        db.add(clone)
        db.commit()
        db.refresh(clone)
        return jsonify(product_to_dict(clone)), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@product_bp.route("/api/admin/products/<int:product_id>/upload", methods=["POST"])
@require_admin
def admin_upload_product_file(product_id):
    """Upload a file (ZIP, PDF, etc.) for a product."""
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.id == product_id).first()
        if not p:
            return jsonify({"error": "Product not found"}), 404
        if "file" not in request.files:
            return jsonify({"error": "No file provided"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"error": "Empty filename"}), 400

        uploads_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")
        os.makedirs(uploads_dir, exist_ok=True)

        safe_name = re.sub(r"[^\w\.\-]", "_", file.filename)
        stored_name = "product_{}_{}".format(product_id, safe_name)
        file_path = os.path.join(uploads_dir, stored_name)
        file.save(file_path)

        file_size = os.path.getsize(file_path)
        p.file_key = stored_name
        p.file_name = file.filename
        p.file_size = file_size
        db.commit()

        return jsonify({
            "success": True,
            "fileName": file.filename,
            "fileKey": stored_name,
            "fileSize": file_size,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Product Import ───────────────────────────────────────────────────────────

@product_bp.route("/api/admin/products/import", methods=["POST"])
@require_admin
def admin_import_products():
    """Bulk import products from CSV or Excel file."""
    db = SessionLocal()
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file provided"}), 400

        file = request.files["file"]
        filename = (file.filename or "").lower()
        rows = []

        if filename.endswith(".csv"):
            import csv
            import io as _io
            content = file.read().decode("utf-8-sig")
            reader = csv.DictReader(_io.StringIO(content))
            rows = list(reader)

        elif filename.endswith(".xlsx") or filename.endswith(".xls"):
            try:
                import openpyxl
                import io as _io
                wb = openpyxl.load_workbook(_io.BytesIO(file.read()), read_only=True, data_only=True)
                ws = wb.active
                headers = None
                for i, row in enumerate(ws.iter_rows(values_only=True)):
                    if i == 0:
                        headers = [str(c or "").strip() for c in row]
                    elif headers:
                        rows.append(dict(zip(headers, [str(c or "").strip() for c in row])))
            except ImportError:
                return jsonify({"error": "openpyxl not installed. Run: pip install openpyxl"}), 400
        else:
            return jsonify({"error": "Only CSV, XLSX, and XLS files are supported"}), 400

        created = 0
        errors = []
        for i, row in enumerate(rows):
            try:
                name = row.get("name") or row.get("Name") or ""
                if not name:
                    continue
                base_slug = row.get("slug") or re.sub(r"[^a-z0-9-]", "-", name.lower()).strip("-")
                slug = _make_unique_slug(db, base_slug)

                tags_raw = row.get("tags") or row.get("Tags") or "[]"
                features_raw = row.get("features") or row.get("Features") or "[]"
                try:
                    tags = json.loads(tags_raw) if tags_raw.startswith("[") else [t.strip() for t in tags_raw.split(",") if t.strip()]
                except Exception:
                    tags = []
                try:
                    features = json.loads(features_raw) if features_raw.startswith("[") else [f.strip() for f in features_raw.split(",") if f.strip()]
                except Exception:
                    features = []

                price_raw = row.get("price") or row.get("Price") or "0"
                try:
                    price = float(price_raw)
                except Exception:
                    price = 0.0

                p = Product(
                    name=name,
                    slug=slug,
                    description=row.get("description") or row.get("Description") or "",
                    category=row.get("category") or row.get("Category") or "templates",
                    type=row.get("type") or row.get("Type") or "template",
                    price=price,
                    original_price=float(row.get("originalPrice") or row.get("original_price") or 0) or None,
                    thumbnail_url=row.get("thumbnailUrl") or row.get("thumbnail_url") or row.get("image") or "",
                    status=row.get("status") or row.get("Status") or "draft",
                    tags=tags,
                    features=features,
                    meta_title=row.get("metaTitle") or row.get("meta_title") or "",
                    meta_description=row.get("metaDescription") or row.get("meta_description") or "",
                    keywords=row.get("keywords") or row.get("Keywords") or "",
                )
                db.add(p)
                created += 1
            except Exception as e:
                errors.append("Row {}: {}".format(i + 2, str(e)))

        db.commit()
        return jsonify({
            "created": created,
            "skipped": len(errors),
            "errors": errors[:10],
        })
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── ThemeForest URL Bulk Import ──────────────────────────────────────────────

@product_bp.route("/api/admin/products/import-url", methods=["POST"])
@require_admin
def admin_import_from_url():
    import re as _r
    import urllib.request
    import urllib.error
    import html as _h

    data = request.get_json() or {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"error": "URL is required"}), 400

    allowed = ("themeforest.net", "codecanyon.net", "videohive.net",
               "graphicriver.net", "activeden.net", "audiojungle.net")
    clean = url.lower().replace("https://", "").replace("http://", "")
    if not any(clean.startswith(d) for d in allowed):
        return jsonify({"error": "Only ThemeForest/Envato URLs are supported"}), 400

    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html;q=0.9",
        })
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read(400000)
        try:
            html = raw.decode("utf-8")
        except UnicodeDecodeError:
            html = raw.decode("latin-1", errors="replace")
    except urllib.error.URLError as e:
        return jsonify({"error": "Cannot fetch URL: " + str(e)}), 400
    except Exception as e:
        return jsonify({"error": "Fetch error: " + str(e)}), 400

    quot = "[" + chr(34) + chr(39) + "]"

    def _og(prop):
        esc_prop = _r.escape(prop)
        for pat in [
            "property=" + quot + "og:" + esc_prop + quot + "[^>]*content=" + quot + "([^" + chr(34) + chr(39) + ">]+)" + quot,
            "name=" + quot + esc_prop + quot + "[^>]*content=" + quot + "([^" + chr(34) + chr(39) + ">]+)" + quot,
            "content=" + quot + "([^" + chr(34) + chr(39) + ">]+)" + quot + r"\s+property=" + quot + "og:" + esc_prop + quot,
        ]:
            m = _r.search(pat, html, _r.IGNORECASE)
            if m:
                return _h.unescape(m.group(1).strip())
        return ""

    def _page_title():
        m = _r.search("<title[^>]*>([^<]+)</title>", html, _r.IGNORECASE)
        if m:
            t = _h.unescape(m.group(1).strip())
            t = _r.sub(r"\s*[|\-]\s*(ThemeForest|Envato|CodeCanyon)[^\n]*", "", t, flags=_r.IGNORECASE)
            return t.strip()
        return ""

    name = _og("title") or _page_title() or "Imported Product"
    description = _og("description") or ""
    thumbnail_url = _og("image") or ""
    page_url = _og("url") or url

    price = 0.0
    price_pats = [
        '"price":\\s*"?([\\d.]+)"?',
        "\\$([\\d]+(?:\\.[\\d]{1,2})?)",
        "USD\\s+([\\d]+(?:\\.[\\d]{1,2})?)",
    ]
    for pat in price_pats:
        m = _r.search(pat, html)
        if m:
            try:
                v = float(m.group(1))
                if v > 1:
                    price = v
                    break
            except Exception:
                pass

    url_lower = url.lower()
    category = "templates"
    if "wordpress" in url_lower or "woocommerce" in url_lower:
        category = "themes"
    elif "plugin" in url_lower or "addon" in url_lower:
        category = "plugins"
    elif "ui-kit" in url_lower or "component" in url_lower:
        category = "ui-kits"

    kw_pat = "keywords" + quot + "[^>]*content=" + quot + "([^" + chr(34) + chr(39) + ">]+)" + quot
    kw_m = _r.search(kw_pat, html, _r.IGNORECASE)
    tags = [t.strip() for t in kw_m.group(1).split(",") if t.strip()][:8] if kw_m else []

    db = SessionLocal()
    try:
        base_slug = _r.sub(r"[^a-z0-9-]", "-", name.lower()).strip("-")
        base_slug = _r.sub(r"-+", "-", base_slug)[:80]
        slug = _make_unique_slug(db, base_slug)

        if data.get("preview", False):
            return jsonify({
                "preview": True, "name": name,
                "description": description[:500], "price": price,
                "category": category, "thumbnailUrl": thumbnail_url,
                "previewUrl": url, "tags": tags, "slug": slug,
            })

        status = data.get("status", "draft")
        p = Product(
            name=name, slug=slug, description=description,
            category=category, type=category.rstrip("s"), price=price,
            original_price=price if price > 0 else None, discount=0,
            thumbnail_url=thumbnail_url, preview_url=url, demo_url=page_url,
            status=status, tags=tags, features=[], meta_title=name[:55],
            meta_description=description[:157], keywords=", ".join(tags),
        )
        db.add(p)
        db.commit()
        db.refresh(p)
        return jsonify({
            "success": True, "product": product_to_dict(p),
            "message": "Product imported: " + name,
        }), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()
