from flask import Blueprint, request, jsonify, g
from database import SessionLocal, Review, Product, User, Order, OrderItem
from auth_helper import require_auth, require_admin
from sqlalchemy import func

review_bp = Blueprint("reviews", __name__)


def _recalc_product_rating(db, product_id):
    avg = db.query(func.avg(Review.rating)).filter(Review.product_id == product_id).scalar()
    count = db.query(func.count(Review.id)).filter(Review.product_id == product_id).scalar()
    product = db.query(Product).filter(Product.id == product_id).first()
    if product:
        product.rating = round(float(avg or 0), 2)
        product.rating_count = count or 0


def review_to_dict(r, include_user=False):
    d = {
        "id": r.id,
        "productId": r.product_id,
        "rating": r.rating,
        "comment": r.comment or "",
        "isApproved": bool(getattr(r, "is_approved", True)),
        "adminReply": getattr(r, "admin_reply", None),
        "createdAt": r.created_at.isoformat() if r.created_at else None,
    }
    if include_user and r.user:
        d["userName"] = r.user.name or r.user.email
    return d


@review_bp.route("/api/reviews", methods=["POST"])
@require_auth
def create_review():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        product_id = data.get("productId")
        rating = data.get("rating")
        comment = data.get("comment", "").strip()

        if not product_id or not rating:
            return jsonify({"error": "productId and rating are required"}), 400

        try:
            rating = int(rating)
        except (TypeError, ValueError):
            return jsonify({"error": "Rating must be a number 1-5"}), 400

        if not (1 <= rating <= 5):
            return jsonify({"error": "Rating must be between 1 and 5"}), 400

        # Verify user purchased this product
        purchased = (
            db.query(OrderItem)
            .join(Order, OrderItem.order_id == Order.id)
            .filter(Order.user_id == g.user.id, OrderItem.product_id == product_id, Order.status == "completed")
            .first()
        )
        if not purchased:
            return jsonify({"error": "You can only review products you have purchased"}), 403

        existing = db.query(Review).filter(Review.user_id == g.user.id, Review.product_id == product_id).first()
        if existing:
            existing.rating = rating
            existing.comment = comment
            db.commit()
            review = existing
        else:
            review = Review(user_id=g.user.id, product_id=product_id, rating=rating, comment=comment)
            db.add(review)
            db.commit()
            db.refresh(review)

        _recalc_product_rating(db, product_id)
        db.commit()

        return jsonify(review_to_dict(review)), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@review_bp.route("/api/products/<int:product_id>/my-review", methods=["GET"])
@require_auth
def get_my_review(product_id):
    """Return current user's review for a product (if any)."""
    db = SessionLocal()
    try:
        review = db.query(Review).filter(Review.user_id == g.user.id, Review.product_id == product_id).first()
        if not review:
            return jsonify({"review": None})
        return jsonify({"review": review_to_dict(review)})
    finally:
        db.close()


# ─── Admin: List all reviews ──────────────────────────────────────────────────

@review_bp.route("/api/admin/reviews", methods=["GET"])
@require_admin
def admin_list_reviews():
    db = SessionLocal()
    try:
        limit = int(request.args.get("limit", 200))
        reviews = db.query(Review).order_by(Review.created_at.desc()).limit(limit).all()
        result = []
        for r in reviews:
            product = db.query(Product).filter(Product.id == r.product_id).first()
            user = db.query(User).filter(User.id == r.user_id).first()
            result.append({
                "id": r.id,
                "productId": r.product_id,
                "productName": product.name if product else None,
                "userId": r.user_id,
                "userName": user.name if user else None,
                "userEmail": user.email if user else None,
                "rating": r.rating,
                "comment": r.comment,
                "isApproved": bool(getattr(r, 'is_approved', True)),
                "adminReply": getattr(r, 'admin_reply', None),
                "createdAt": r.created_at.isoformat() if r.created_at else None,
            })
        return jsonify({"reviews": result, "total": len(result)})
    finally:
        db.close()


# ─── Admin: Update review (approve/hide/reply) ────────────────────────────────

@review_bp.route("/api/admin/reviews/<int:review_id>", methods=["PUT", "PATCH"])
@require_admin
def admin_update_review(review_id):
    db = SessionLocal()
    try:
        review = db.query(Review).filter(Review.id == review_id).first()
        if not review:
            return jsonify({"error": "Review not found"}), 404
        data = request.get_json() or {}
        if "isApproved" in data:
            review.is_approved = bool(data["isApproved"])
        if "adminReply" in data:
            review.admin_reply = data["adminReply"] or None
        if "rating" in data:
            review.rating = int(data["rating"])
        if "comment" in data:
            review.comment = data["comment"]
        db.commit()
        return jsonify({"ok": True, "id": review.id})
    finally:
        db.close()


# ─── Admin: Delete review ─────────────────────────────────────────────────────

@review_bp.route("/api/admin/reviews/<int:review_id>", methods=["DELETE"])
@require_admin
def admin_delete_review(review_id):
    db = SessionLocal()
    try:
        review = db.query(Review).filter(Review.id == review_id).first()
        if not review:
            return jsonify({"error": "Review not found"}), 404
        product_id = review.product_id
        db.delete(review)
        db.commit()
        # Recalculate product rating
        product = db.query(Product).filter(Product.id == product_id).first()
        if product:
            avg = db.query(func.avg(Review.rating)).filter(Review.product_id == product_id).scalar()
            count = db.query(func.count(Review.id)).filter(Review.product_id == product_id).scalar()
            product.rating = round(float(avg or 0), 2)
            product.rating_count = count or 0
            db.commit()
        return jsonify({"ok": True})
    finally:
        db.close()
