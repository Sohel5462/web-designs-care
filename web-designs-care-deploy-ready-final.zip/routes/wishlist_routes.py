from flask import Blueprint, request, jsonify, g
from database import SessionLocal, WishlistItem, Product
from auth_helper import require_auth

wishlist_bp = Blueprint("wishlist", __name__)


@wishlist_bp.route("/api/wishlist", methods=["GET"])
@require_auth
def get_wishlist():
    db = SessionLocal()
    try:
        items = db.query(WishlistItem).filter(WishlistItem.user_id == g.user.id).all()
        result = []
        for item in items:
            p = item.product
            result.append({
                "id": item.id,
                "productId": item.product_id,
                "product": {
                    "id": p.id,
                    "name": p.name,
                    "slug": p.slug,
                    "price": str(p.price),
                    "thumbnailUrl": p.thumbnail_url,
                    "rating": str(p.rating or "0"),
                    "ratingCount": p.rating_count,
                } if p else None,
                "createdAt": item.created_at.isoformat() if item.created_at else None,
            })
        return jsonify(result)
    finally:
        db.close()


@wishlist_bp.route("/api/wishlist", methods=["POST"])
@require_auth
def add_to_wishlist():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        product_id = data.get("productId")
        if not product_id:
            return jsonify({"error": "productId required"}), 400
        existing = db.query(WishlistItem).filter(WishlistItem.user_id == g.user.id, WishlistItem.product_id == product_id).first()
        if existing:
            db.delete(existing)
            db.commit()
            return jsonify({"removed": True})
        item = WishlistItem(user_id=g.user.id, product_id=product_id)
        db.add(item)
        db.commit()
        db.refresh(item)
        return jsonify({"id": item.id, "productId": item.product_id}), 201
    finally:
        db.close()


@wishlist_bp.route("/api/wishlist/<int:product_id>", methods=["DELETE"])
@require_auth
def remove_from_wishlist(product_id):
    db = SessionLocal()
    try:
        item = db.query(WishlistItem).filter(WishlistItem.user_id == g.user.id, WishlistItem.product_id == product_id).first()
        if item:
            db.delete(item)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()
