from flask import Blueprint, request, jsonify, g
from sqlalchemy import desc
from database import SessionLocal, Ticket
from auth_helper import require_auth, require_admin, get_current_user

ticket_bp = Blueprint("tickets", __name__)


def ticket_to_dict(t: Ticket) -> dict:
    return {
        "id": t.id,
        "subject": t.subject,
        "message": t.message,
        "status": t.status,
        "priority": t.priority,
        "adminReply": t.admin_reply,
        "createdAt": t.created_at.isoformat() if t.created_at else None,
        "updatedAt": t.updated_at.isoformat() if t.updated_at else None,
        "user": {"id": t.user.id, "name": t.user.name, "email": t.user.email} if t.user else None,
    }


@ticket_bp.route("/api/tickets", methods=["GET"])
@require_auth
def get_tickets():
    db = SessionLocal()
    try:
        tickets = db.query(Ticket).filter(Ticket.user_id == g.user.id).order_by(desc(Ticket.created_at)).all()
        return jsonify([ticket_to_dict(t) for t in tickets])
    finally:
        db.close()


@ticket_bp.route("/api/tickets", methods=["POST"])
@require_auth
def create_ticket():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        subject = data.get("subject", "").strip()
        message = data.get("message", "").strip()
        priority = data.get("priority", "medium")

        if not subject:
            return jsonify({"error": "Subject is required"}), 400
        if not message:
            return jsonify({"error": "Message/description is required"}), 400
        if priority not in ["low", "medium", "high", "urgent"]:
            priority = "medium"

        ticket = Ticket(
            user_id=g.user.id,
            subject=subject,
            message=message,
            priority=priority,
            status="open",
        )
        db.add(ticket)
        db.flush()

        # ── Admin notification ──
        try:
            from routes.notif_utils import push_notification
            from database import User
            user = db.query(User).filter(User.id == g.user.id).first()
            uname = user.name if user else "Customer"
            push_notification(
                db,
                title=f"🎫 New Ticket #{ticket.id}: {subject[:60]}",
                message=f"From {uname} — priority: {priority}",
                notif_type="ticket",
                link="#tickets",
                icon="🎫",
            )
        except Exception:
            pass

        db.commit()
        db.refresh(ticket)
        return jsonify(ticket_to_dict(ticket)), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@ticket_bp.route("/api/tickets/<int:ticket_id>", methods=["GET"])
@require_auth
def get_ticket(ticket_id):
    db = SessionLocal()
    try:
        ticket = db.query(Ticket).filter(Ticket.id == ticket_id, Ticket.user_id == g.user.id).first()
        if not ticket:
            return jsonify({"error": "Not found"}), 404
        return jsonify(ticket_to_dict(ticket))
    finally:
        db.close()


@ticket_bp.route("/api/admin/tickets", methods=["GET"])
@require_admin
def admin_get_tickets():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 20)), 100)
        offset = int(request.args.get("offset", 0))
        status_filter = request.args.get("status")
        q = db.query(Ticket)
        if status_filter:
            q = q.filter(Ticket.status == status_filter)
        tickets = q.order_by(desc(Ticket.created_at)).offset(offset).limit(limit).all()
        total = db.query(Ticket).count()
        return jsonify({"tickets": [ticket_to_dict(t) for t in tickets], "total": total})
    finally:
        db.close()


@ticket_bp.route("/api/admin/tickets/<int:ticket_id>", methods=["PUT"])
@require_admin
def admin_update_ticket(ticket_id):
    db = SessionLocal()
    try:
        ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
        if not ticket:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        if "status" in data:
            ticket.status = data["status"]
        if "priority" in data:
            ticket.priority = data["priority"]
        if "adminReply" in data:
            ticket.admin_reply = data["adminReply"]
            if data["adminReply"] and ticket.status == "open":
                ticket.status = "answered"
        db.commit()
        return jsonify(ticket_to_dict(ticket))
    finally:
        db.close()


@ticket_bp.route("/api/admin/tickets/<int:ticket_id>", methods=["DELETE"])
@require_admin
def admin_delete_ticket(ticket_id):
    db = SessionLocal()
    try:
        ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
        if ticket:
            db.delete(ticket)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()
