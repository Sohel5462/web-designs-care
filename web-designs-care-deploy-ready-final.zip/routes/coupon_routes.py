from flask import Blueprint, request, jsonify, g
from sqlalchemy import desc
from database import SessionLocal, Coupon
from auth_helper import require_auth
from datetime import datetime, timezone

coupon_bp = Blueprint("coupons", __name__)


def coupon_to_dict(c: Coupon) -> dict:
    return {
        "id": c.id,
        "code": c.code,
        "description": c.description,
        "type": c.type,
        "value": str(c.value),
        "minOrderAmount": str(c.min_order_amount or "0.00"),
        "maxUses": c.max_uses,
        "usedCount": c.used_count,
        "expiresAt": c.expires_at.isoformat() if c.expires_at else None,
        "isActive": c.is_active,
        "createdAt": c.created_at.isoformat() if c.created_at else None,
    }


@coupon_bp.route("/api/coupons/check", methods=["POST"])
@coupon_bp.route("/api/coupons/validate", methods=["POST"])
def validate_coupon():
    """Validate a coupon code against an order amount (public — no auth required)."""
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        code = data.get("code", "").upper().strip()
        order_amount = float(data.get("orderAmount") or data.get("orderTotal") or 0)

        if not code:
            return jsonify({"valid": False, "error": "Coupon code is required"}), 400

        coupon = db.query(Coupon).filter(Coupon.code == code, Coupon.is_active == True).first()
        if not coupon:
            return jsonify({"valid": False, "error": "Invalid or inactive coupon code"}), 400

        now = datetime.now(timezone.utc)
        if coupon.expires_at:
            exp = coupon.expires_at
            if exp.tzinfo is None:
                from datetime import timezone as _tz
                exp = exp.replace(tzinfo=_tz.utc)
            if exp < now:
                return jsonify({"valid": False, "error": "Coupon has expired"}), 400

        if coupon.max_uses and (coupon.used_count or 0) >= coupon.max_uses:
            return jsonify({"valid": False, "error": "Coupon usage limit reached"}), 400

        if coupon.min_order_amount and order_amount < float(coupon.min_order_amount):
            return jsonify({
                "valid": False,
                "error": "Minimum order amount is ${:.2f}".format(float(coupon.min_order_amount)),
            }), 400

        if coupon.type == "percentage":
            discount = order_amount * float(coupon.value) / 100
        else:
            discount = float(coupon.value)

        discount = min(discount, order_amount)

        return jsonify({
            "valid": True,
            "coupon": coupon_to_dict(coupon),
            "discountAmount": round(discount, 2),
            "finalAmount": round(order_amount - discount, 2),
        })
    except ValueError:
        return jsonify({"valid": False, "error": "Invalid order amount"}), 400
    finally:
        db.close()


@coupon_bp.route("/api/coupons/apply", methods=["POST"])
@require_auth
def apply_coupon():
    """Preview coupon savings without actually using it."""
    return validate_coupon()
