from flask import Blueprint, request, jsonify, g
from sqlalchemy import desc
from database import SessionLocal, License
from auth_helper import require_auth

license_bp = Blueprint("licenses", __name__)


def license_to_dict(lic: License) -> dict:
    return {
        "id": lic.id,
        "licenseKey": lic.license_key,
        "status": lic.status,
        "createdAt": lic.created_at.isoformat() if lic.created_at else None,
        "expiresAt": lic.expires_at.isoformat() if lic.expires_at else None,
        "product": {
            "id": lic.product.id,
            "name": lic.product.name,
            "slug": lic.product.slug,
            "thumbnailUrl": lic.product.thumbnail_url,
            "category": lic.product.category,
        } if lic.product else None,
    }


@license_bp.route("/api/licenses", methods=["GET"])
@require_auth
def get_licenses():
    db = SessionLocal()
    try:
        licenses = db.query(License).filter(License.user_id == g.user.id).order_by(desc(License.created_at)).all()
        return jsonify([license_to_dict(l) for l in licenses])
    finally:
        db.close()
