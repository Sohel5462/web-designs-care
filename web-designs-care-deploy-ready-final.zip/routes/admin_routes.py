from flask import Blueprint, request, jsonify, g, Response, stream_with_context
from sqlalchemy import desc, func, extract
import time
from database import (
    SessionLocal, User, Order, OrderItem, Product, AffiliateCode, AffiliateClick,
    SiteSetting, Webhook, Domain, InstalledApp, MarketingCampaign, Notification,
    NewsletterSubscriber, ContactMessage, Coupon, WalletTransaction,
    ChatbotLead, PageView,
)
from auth_helper import require_admin
from config import Config
import uuid
import io
import json
from datetime import datetime, timedelta, timezone

admin_bp = Blueprint("admin", __name__)

MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

IS_SQLITE = "sqlite" in Config.DATABASE_URL.lower()


def _month_filter(year, month):
    """Return SQLAlchemy filter expressions for a given year/month."""
    if IS_SQLITE:
        return [
            func.strftime("%Y", Order.created_at) == str(year),
            func.strftime("%m", Order.created_at) == "{:02d}".format(month),
        ]
    else:
        return [
            extract("year", Order.created_at) == year,
            extract("month", Order.created_at) == month,
        ]


# ─── Quick Stats (Admin Dashboard) ───────────────────────────────────────────

@admin_bp.route("/api/admin/stats", methods=["GET"])
@require_admin
def admin_quick_stats():
    """Combined quick stats for the admin dashboard header."""
    db = SessionLocal()
    try:
        total_revenue = db.query(func.sum(Order.total)).filter(Order.status == "completed").scalar() or 0
        total_orders = db.query(Order).count()
        total_users = db.query(User).count()
        total_products = db.query(Product).filter(Product.status == "published").count()
        pending_orders = db.query(Order).filter(Order.status == "pending").count()
        open_tickets_count = 0
        try:
            from database import Ticket
            open_tickets_count = db.query(Ticket).filter(Ticket.status == "open").count()
        except Exception:
            pass
        unread_messages = db.query(ContactMessage).filter(ContactMessage.is_read == False).count()
        active_subscribers = db.query(NewsletterSubscriber).filter(NewsletterSubscriber.is_active == True).count()
        unread_notifications = db.query(Notification).filter(Notification.is_read == False).count()

        # Today's revenue
        today = datetime.now(timezone.utc).date()
        today_revenue = 0
        if IS_SQLITE:
            today_str = today.isoformat()
            today_revenue = db.query(func.sum(Order.total)).filter(
                Order.status == "completed",
                func.strftime("%Y-%m-%d", Order.created_at) == today_str,
            ).scalar() or 0
        else:
            today_revenue = db.query(func.sum(Order.total)).filter(
                Order.status == "completed",
                func.date(Order.created_at) == today,
            ).scalar() or 0

        return jsonify({
            "totalRevenue": float(total_revenue),
            "todayRevenue": float(today_revenue),
            "totalOrders": total_orders,
            "pendingOrders": pending_orders,
            "totalUsers": total_users,
            "totalProducts": total_products,
            "openTickets": open_tickets_count,
            "unreadMessages": unread_messages,
            "activeSubscribers": active_subscribers,
            "unreadNotifications": unread_notifications,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Analytics ────────────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/analytics", methods=["GET"])
@require_admin
def get_analytics():
    db = SessionLocal()
    try:
        total_revenue = db.query(func.sum(Order.total)).filter(Order.status == "completed").scalar() or 0
        total_orders = db.query(func.count(Order.id)).scalar() or 0
        total_users = db.query(func.count(User.id)).scalar() or 0
        total_products = db.query(func.count(Product.id)).filter(Product.status == "published").scalar() or 0

        # Real monthly sales for last 12 months
        now = datetime.now(timezone.utc)
        monthly = []
        for i in range(11, -1, -1):
            target = now - timedelta(days=30 * i)
            m = target.month
            y = target.year
            filters = _month_filter(y, m)
            month_revenue = db.query(func.sum(Order.total)).filter(
                Order.status == "completed", *filters
            ).scalar() or 0
            month_orders = db.query(func.count(Order.id)).filter(
                Order.status == "completed", *filters
            ).scalar() or 0
            monthly.append({
                "month": MONTH_NAMES[m - 1],
                "year": y,
                "revenue": float(month_revenue),
                "orders": month_orders,
            })

        categories = db.query(Product.category, func.count(Product.id)).group_by(Product.category).all()
        category_dist = [{"category": c, "count": n} for c, n in categories]

        top_products = db.query(Product).filter(Product.status == "published").order_by(desc(Product.sales)).limit(5).all()
        top_products_data = [{"id": p.id, "name": p.name, "sales": p.sales or 0, "revenue": float(p.price) * (p.sales or 0)} for p in top_products]

        recent_orders = db.query(Order).order_by(desc(Order.created_at)).limit(10).all()
        recent_orders_data = [{"id": o.id, "total": float(o.total), "status": o.status,
                               "createdAt": o.created_at.isoformat() if o.created_at else None} for o in recent_orders]

        return jsonify({
            "totalRevenue": float(total_revenue),
            "totalOrders": total_orders,
            "totalUsers": total_users,
            "totalProducts": total_products,
            "monthlySales": monthly,
            "categoryDistribution": category_dist,
            "topProducts": top_products_data,
            "recentOrders": recent_orders_data,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Revenue Summary ──────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/revenue", methods=["GET"])
@require_admin
def admin_revenue():
    """Revenue overview — last 30/90/365 days."""
    db = SessionLocal()
    try:
        days = int(request.args.get("days", 30))
        since = datetime.now(timezone.utc) - timedelta(days=days)
        if IS_SQLITE:
            since_str = since.strftime("%Y-%m-%d")
            orders = db.query(Order).filter(
                Order.status == "completed",
                func.strftime("%Y-%m-%d", Order.created_at) >= since_str,
            ).all()
        else:
            orders = db.query(Order).filter(
                Order.status == "completed",
                Order.created_at >= since,
            ).all()

        revenue = sum(float(o.total) for o in orders)
        count = len(orders)
        avg = round(revenue / count, 2) if count else 0

        return jsonify({
            "days": days,
            "revenue": round(revenue, 2),
            "orders": count,
            "avgOrderValue": avg,
        })
    finally:
        db.close()


# ─── Users ────────────────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/users", methods=["GET"])
@require_admin
def admin_get_users():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 20)), 100)
        offset = int(request.args.get("offset", 0))
        search = request.args.get("search", "")
        role = request.args.get("role", "")
        q = db.query(User)
        if search:
            q = q.filter(
                User.name.ilike("%{}%".format(search)) | User.email.ilike("%{}%".format(search))
            )
        if role:
            q = q.filter(User.role == role)
        total = q.count()
        users = q.order_by(desc(User.created_at)).offset(offset).limit(limit).all()
        result = [{
            "id": u.id, "name": u.name, "email": u.email, "role": u.role,
            "phone": u.phone, "loginMethod": u.login_method,
            "walletBalance": str(u.wallet_balance or 0),
            "createdAt": u.created_at.isoformat() if u.created_at else None,
            "lastSignedIn": u.last_signed_in.isoformat() if u.last_signed_in else None,
        } for u in users]
        return jsonify({"users": result, "total": total})
    finally:
        db.close()


@admin_bp.route("/api/admin/users/<int:user_id>", methods=["GET"])
@require_admin
def admin_get_user(user_id):
    db = SessionLocal()
    try:
        u = db.query(User).filter(User.id == user_id).first()
        if not u:
            return jsonify({"error": "Not found"}), 404
        order_count = db.query(Order).filter(Order.user_id == u.id).count()
        total_spent = db.query(func.sum(Order.total)).filter(Order.user_id == u.id, Order.status == "completed").scalar() or 0
        return jsonify({
            "id": u.id, "name": u.name, "email": u.email, "role": u.role,
            "phone": u.phone, "loginMethod": u.login_method,
            "walletBalance": float(u.wallet_balance or 0),
            "orderCount": order_count,
            "totalSpent": float(total_spent),
            "createdAt": u.created_at.isoformat() if u.created_at else None,
        })
    finally:
        db.close()


@admin_bp.route("/api/admin/users/<int:user_id>", methods=["PUT"])
@require_admin
def admin_update_user(user_id):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        if "role" in data and data["role"] in ["user", "admin"]:
            user.role = data["role"]
        if "name" in data and data["name"]:
            user.name = data["name"]
        if "walletBalance" in data:
            try:
                user.wallet_balance = max(0, float(data["walletBalance"]))
            except Exception:
                pass
        db.commit()
        return jsonify({"id": user.id, "name": user.name, "email": user.email, "role": user.role})
    finally:
        db.close()


@admin_bp.route("/api/admin/users/<int:user_id>/wallet", methods=["POST"])
@require_admin
def admin_top_up_wallet(user_id):
    """Add or subtract wallet balance for a user. Also records a WalletTransaction."""
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        amount = float(data.get("amount", 0))
        action = data.get("action", "add")
        description = data.get("description", "")
        if amount <= 0:
            return jsonify({"error": "Amount must be positive"}), 400
        old_balance = float(user.wallet_balance or 0)
        if action in ("subtract", "deduct"):
            if amount > old_balance:
                return jsonify({"error": "Insufficient balance", "balance": old_balance}), 400
            new_balance = round(old_balance - amount, 2)
            actual_amount = amount
            txn_type = "admin_subtract"
            txn_desc = description or "Admin deduction"
        else:
            new_balance = round(old_balance + amount, 2)
            actual_amount = amount
            txn_type = "admin_add"
            txn_desc = description or "Admin credit"
        user.wallet_balance = new_balance
        txn = WalletTransaction(
            user_id=user_id,
            type=txn_type,
            amount=actual_amount,
            balance_after=new_balance,
            description=txn_desc,
            reference_id="ADMIN-{}".format(g.user.id),
        )
        db.add(txn)
        db.commit()
        return jsonify({
            "userId": user.id,
            "userName": user.name,
            "walletBalance": float(user.wallet_balance),
            "action": action,
            "amount": actual_amount,
        })
    except ValueError:
        return jsonify({"error": "Invalid amount"}), 400
    finally:
        db.close()


@admin_bp.route("/api/admin/users/<int:user_id>", methods=["DELETE"])
@require_admin
def admin_delete_user(user_id):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({"error": "Not found"}), 404
        if user.role == "admin":
            return jsonify({"error": "Cannot delete admin users"}), 403
        db.delete(user)
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Orders ───────────────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/orders/<int:order_id>/refund", methods=["POST"])
@require_admin
def admin_refund_order(order_id):
    """Mark order as refunded and return balance to wallet."""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({"error": "Not found"}), 404
        if order.status == "refunded":
            return jsonify({"error": "Order already refunded"}), 400
        old_status = order.status
        order.status = "refunded"

        # Credit wallet and record transaction
        user = db.query(User).filter(User.id == order.user_id).first()
        if user:
            old_balance = float(user.wallet_balance or 0)
            new_balance = round(old_balance + float(order.total), 2)
            user.wallet_balance = new_balance
            txn = WalletTransaction(
                user_id=user.id,
                type="refund",
                amount=float(order.total),
                balance_after=new_balance,
                description="Refund for Order #{}".format(order_id),
                reference_id=str(order_id),
            )
            db.add(txn)

        # Deactivate licenses
        from database import License
        db.query(License).filter(License.order_id == order_id).update({"status": "revoked"})

        db.commit()
        return jsonify({
            "success": True,
            "orderId": order.id,
            "refundAmount": float(order.total),
            "previousStatus": old_status,
            "walletCredited": float(order.total),
        })
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Affiliates ───────────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/affiliates", methods=["GET"])
@require_admin
def admin_get_affiliates():
    db = SessionLocal()
    try:
        codes = db.query(AffiliateCode).order_by(desc(AffiliateCode.created_at)).all()
        result = [{
            "id": c.id, "code": c.code, "commissionRate": str(c.commission_rate),
            "totalClicks": c.total_clicks or 0, "totalConversions": c.total_conversions or 0,
            "totalEarnings": str(c.total_earnings or 0), "isActive": c.is_active,
            "userId": c.user_id,
        } for c in codes]
        return jsonify(result)
    finally:
        db.close()


@admin_bp.route("/api/admin/affiliates", methods=["POST"])
@require_admin
def admin_create_affiliate():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        user_id = data.get("userId")
        if not user_id:
            return jsonify({"error": "userId required"}), 400
        code_str = data.get("code") or "AFF-{}".format(uuid.uuid4().hex[:8].upper())
        existing = db.query(AffiliateCode).filter(AffiliateCode.code == code_str).first()
        if existing:
            return jsonify({"error": "Code already exists"}), 409
        aff = AffiliateCode(
            user_id=user_id,
            code=code_str,
            commission_rate=float(data.get("commissionRate", 10)),
            is_active=True,
        )
        db.add(aff)
        db.commit()
        db.refresh(aff)
        return jsonify({"id": aff.id, "code": aff.code, "commissionRate": str(aff.commission_rate)}), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/affiliates/<int:aff_id>", methods=["DELETE"])
@require_admin
def admin_delete_affiliate(aff_id):
    db = SessionLocal()
    try:
        aff = db.query(AffiliateCode).filter(AffiliateCode.id == aff_id).first()
        if not aff:
            return jsonify({"error": "Not found"}), 404
        db.delete(aff)
        db.commit()
        return jsonify({"success": True})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/affiliate/me", methods=["GET"])
@require_admin
def get_my_affiliate():
    db = SessionLocal()
    try:
        code = db.query(AffiliateCode).filter(AffiliateCode.user_id == g.user.id).first()
        if not code:
            return jsonify(None)
        return jsonify({
            "id": code.id, "code": code.code, "commissionRate": str(code.commission_rate),
            "totalClicks": code.total_clicks or 0, "totalEarnings": str(code.total_earnings or 0),
        })
    finally:
        db.close()


@admin_bp.route("/api/affiliate/track", methods=["POST"])
def track_affiliate():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        code_str = data.get("code", "")
        aff = db.query(AffiliateCode).filter(AffiliateCode.code == code_str, AffiliateCode.is_active == True).first()
        if not aff:
            return jsonify({"error": "Invalid code"}), 404
        aff.total_clicks = (aff.total_clicks or 0) + 1
        click = AffiliateClick(affiliate_code_id=aff.id, ip_address=request.remote_addr)
        db.add(click)
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Domains ──────────────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/domains", methods=["GET"])
@require_admin
def admin_get_domains():
    db = SessionLocal()
    try:
        domains = db.query(Domain).order_by(desc(Domain.created_at)).all()
        result = [{"id": d.id, "domain": d.domain, "hosting": d.hosting, "isPrimary": d.is_primary,
                   "status": d.status, "sslEnabled": d.ssl_enabled, "dnsVerified": d.dns_verified,
                   "createdAt": d.created_at.isoformat() if d.created_at else None} for d in domains]
        return jsonify(result)
    finally:
        db.close()


@admin_bp.route("/api/admin/domains", methods=["POST"])
@require_admin
def admin_create_domain():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        domain_name = data.get("domain", "").strip()
        if not domain_name:
            return jsonify({"error": "Domain name is required"}), 400
        existing = db.query(Domain).filter(Domain.domain == domain_name).first()
        if existing:
            return jsonify({"error": "Domain already registered"}), 409
        domain = Domain(
            domain=domain_name,
            hosting=data.get("hosting", "custom"),
            is_primary=data.get("isPrimary", False),
            status="active",
            ssl_enabled=data.get("sslEnabled", True),
            dns_verified=False,
        )
        db.add(domain)
        db.commit()
        db.refresh(domain)
        return jsonify({"id": domain.id, "domain": domain.domain, "hosting": domain.hosting,
                        "status": domain.status, "dnsVerified": domain.dns_verified}), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/domains/<int:domain_id>", methods=["PUT", "PATCH"])
@require_admin
def admin_update_domain(domain_id):
    db = SessionLocal()
    try:
        d = db.query(Domain).filter(Domain.id == domain_id).first()
        if not d:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        for field, col in {
            "domain": "domain", "hosting": "hosting",
            "isPrimary": "is_primary", "status": "status",
            "sslEnabled": "ssl_enabled", "dnsVerified": "dns_verified",
        }.items():
            if field in data:
                setattr(d, col, data[field])
        db.commit()
        return jsonify({"id": d.id, "domain": d.domain, "hosting": d.hosting,
                        "isPrimary": d.is_primary, "status": d.status,
                        "sslEnabled": d.ssl_enabled, "dnsVerified": d.dns_verified})
    finally:
        db.close()


@admin_bp.route("/api/admin/domains/<int:domain_id>", methods=["DELETE"])
@require_admin
def admin_delete_domain(domain_id):
    db = SessionLocal()
    try:
        d = db.query(Domain).filter(Domain.id == domain_id).first()
        if d:
            db.delete(d)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


@admin_bp.route("/api/admin/domains/<int:domain_id>/verify", methods=["POST"])
@require_admin
def admin_verify_domain(domain_id):
    db = SessionLocal()
    try:
        d = db.query(Domain).filter(Domain.id == domain_id).first()
        if not d:
            return jsonify({"error": "Not found"}), 404
        import socket
        verified = False
        try:
            socket.gethostbyname(d.domain)
            verified = True
        except Exception:
            verified = False
        d.dns_verified = verified
        d.status = "active" if verified else "pending"
        db.commit()
        return jsonify({
            "id": d.id, "domain": d.domain, "dnsVerified": d.dns_verified, "status": d.status,
            "message": "DNS verified successfully" if verified else "DNS not resolving yet — check your domain settings",
        })
    finally:
        db.close()


@admin_bp.route("/api/admin/domains/instructions", methods=["GET"])
@require_admin
def domain_setup_instructions():
    return jsonify({
        "steps": [
            {"step": 1, "title": "Buy a domain", "detail": "Purchase from Namecheap, GoDaddy, Google Domains, or similar registrar."},
            {"step": 2, "title": "Get hosting server IP", "detail": "From your hosting provider (VPS/server), note your public IP address."},
            {"step": 3, "title": "Set DNS A Record", "detail": "In your domain registrar DNS settings, create an A record pointing @ to your server IP."},
            {"step": 4, "title": "Set up SSL (HTTPS)", "detail": "Install Certbot: sudo apt install certbot python3-certbot-nginx && sudo certbot --nginx -d yourdomain.com"},
            {"step": 5, "title": "Configure Nginx reverse proxy", "detail": "Point Nginx to localhost:5000 so your Flask app is served on port 80/443."},
            {"step": 6, "title": "Update site URL", "detail": "In Admin > Settings > Site URL, set your domain (e.g. https://yourdomain.com)."},
            {"step": 7, "title": "Add domain here", "detail": "Click 'Add Domain' above and enter your domain. Click Verify DNS to confirm."},
        ],
        "nginxConfig": """server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name yourdomain.com;
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}""",
    })


# ─── Webhooks ─────────────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/webhooks", methods=["GET"])
@require_admin
def admin_get_webhooks():
    db = SessionLocal()
    try:
        webhooks = db.query(Webhook).order_by(desc(Webhook.created_at)).all()
        result = [{"id": w.id, "name": w.name, "url": w.url, "events": w.events or [],
                   "isActive": w.is_active, "lastStatus": w.last_status,
                   "lastFiredAt": w.last_fired_at.isoformat() if w.last_fired_at else None} for w in webhooks]
        return jsonify(result)
    finally:
        db.close()


@admin_bp.route("/api/admin/webhooks", methods=["POST"])
@require_admin
def admin_create_webhook():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        name = data.get("name", "").strip()
        url = data.get("url", "").strip()
        if not name:
            return jsonify({"error": "Webhook name is required"}), 400
        if not url:
            return jsonify({"error": "Endpoint URL is required"}), 400
        wh = Webhook(
            name=name,
            url=url,
            events=data.get("events", []),
            secret=data.get("secret", ""),
            is_active=True,
        )
        db.add(wh)
        db.commit()
        db.refresh(wh)
        return jsonify({"id": wh.id, "name": wh.name, "url": wh.url,
                        "events": wh.events, "isActive": wh.is_active}), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/webhooks/<int:wh_id>", methods=["PUT"])
@require_admin
def admin_update_webhook(wh_id):
    db = SessionLocal()
    try:
        wh = db.query(Webhook).filter(Webhook.id == wh_id).first()
        if not wh:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        for f, c in {"name": "name", "url": "url", "events": "events", "isActive": "is_active", "secret": "secret"}.items():
            if f in data:
                setattr(wh, c, data[f])
        db.commit()
        return jsonify({"id": wh.id, "name": wh.name, "isActive": wh.is_active})
    finally:
        db.close()


@admin_bp.route("/api/admin/webhooks/<int:wh_id>", methods=["DELETE"])
@require_admin
def admin_delete_webhook(wh_id):
    db = SessionLocal()
    try:
        wh = db.query(Webhook).filter(Webhook.id == wh_id).first()
        if wh:
            db.delete(wh)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


@admin_bp.route("/api/admin/webhooks/<int:wh_id>/test", methods=["POST"])
@require_admin
def admin_test_webhook(wh_id):
    db = SessionLocal()
    try:
        wh = db.query(Webhook).filter(Webhook.id == wh_id).first()
        if not wh:
            return jsonify({"error": "Not found"}), 404
        import urllib.request
        import urllib.error
        payload = json.dumps({"event": "test", "timestamp": datetime.now(timezone.utc).isoformat()}).encode()
        headers = {"Content-Type": "application/json"}
        if wh.secret:
            headers["X-WDC-Signature"] = wh.secret
        status = 0
        try:
            req = urllib.request.Request(wh.url, data=payload, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=5) as resp:
                status = resp.status
        except Exception:
            status = 0
        wh.last_status = "success" if status in (200, 201, 202, 204) else "failed"
        wh.last_fired_at = datetime.now(timezone.utc)
        db.commit()
        return jsonify({"success": status in (200, 201, 202, 204), "statusCode": status, "message": "Webhook test sent"})
    finally:
        db.close()


# ─── Apps ─────────────────────────────────────────────────────────────────────

DEFAULT_APPS = [
    {"appId": "google-analytics", "name": "Google Analytics", "category": "analytics"},
    {"appId": "facebook-pixel", "name": "Facebook Pixel", "category": "marketing"},
    {"appId": "mailchimp", "name": "Mailchimp Email Marketing", "category": "marketing"},
    {"appId": "stripe-payments", "name": "Stripe Payments", "category": "payments"},
    {"appId": "autods-dropship", "name": "AutoDS Dropshipping", "category": "dropshipping"},
    {"appId": "recaptcha", "name": "Google reCAPTCHA", "category": "security"},
    {"appId": "crisp-chat", "name": "Crisp Live Chat", "category": "support"},
    {"appId": "whatsapp-chat", "name": "WhatsApp Chat Button", "category": "support"},
    {"appId": "openai-ai", "name": "OpenAI AI Content", "category": "ai"},
    {"appId": "social-share", "name": "Social Share Buttons", "category": "marketing"},
    {"appId": "cookie-consent", "name": "Cookie Consent Banner", "category": "compliance"},
    {"appId": "pwa-support", "name": "Progressive Web App (PWA)", "category": "performance"},
]


@admin_bp.route("/api/admin/apps", methods=["GET"])
@require_admin
def admin_get_apps():
    db = SessionLocal()
    try:
        apps = db.query(InstalledApp).all()
        installed = {a.app_id: a for a in apps}
        result = []
        for app_def in DEFAULT_APPS:
            a = installed.get(app_def["appId"])
            result.append({
                "id": a.id if a else None,
                "appId": app_def["appId"],
                "name": app_def["name"],
                "category": app_def["category"],
                "isInstalled": a.is_installed if a else False,
            })
        return jsonify(result)
    finally:
        db.close()


@admin_bp.route("/api/admin/apps/<app_id>/toggle", methods=["POST"])
@require_admin
def admin_toggle_app(app_id):
    db = SessionLocal()
    try:
        app_def = next((a for a in DEFAULT_APPS if a["appId"] == app_id), None)
        if not app_def:
            return jsonify({"error": "Unknown app"}), 404
        app_obj = db.query(InstalledApp).filter(InstalledApp.app_id == app_id).first()
        if not app_obj:
            app_obj = InstalledApp(
                app_id=app_id,
                name=app_def["name"],
                category=app_def["category"],
                is_installed=True,
                installed_at=datetime.now(timezone.utc),
            )
            db.add(app_obj)
        else:
            app_obj.is_installed = not app_obj.is_installed
            if app_obj.is_installed:
                app_obj.installed_at = datetime.now(timezone.utc)
        db.commit()
        return jsonify({"appId": app_id, "isInstalled": app_obj.is_installed})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Marketing Campaigns ──────────────────────────────────────────────────────

@admin_bp.route("/api/admin/marketing/campaigns", methods=["GET"])
@require_admin
def admin_get_campaigns():
    db = SessionLocal()
    try:
        campaigns = db.query(MarketingCampaign).order_by(desc(MarketingCampaign.created_at)).all()
        return jsonify([{
            "id": c.id, "name": c.name, "type": c.type, "subject": c.subject,
            "status": c.status, "recipients": c.recipients or 0,
            "opens": c.opens or 0, "clicks": c.clicks or 0,
            "scheduledAt": c.scheduled_at.isoformat() if c.scheduled_at else None,
            "sentAt": c.sent_at.isoformat() if c.sent_at else None,
            "createdAt": c.created_at.isoformat() if c.created_at else None,
        } for c in campaigns])
    finally:
        db.close()


@admin_bp.route("/api/admin/marketing/campaigns", methods=["POST"])
@require_admin
def admin_create_campaign():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        campaign = MarketingCampaign(
            name=data.get("name", "New Campaign"),
            type=data.get("type", "email"),
            subject=data.get("subject", ""),
            content=data.get("content", ""),
            status="draft",
        )
        db.add(campaign)
        db.commit()
        db.refresh(campaign)
        return jsonify({"id": campaign.id, "name": campaign.name, "status": campaign.status}), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/marketing/campaigns/<int:campaign_id>", methods=["PUT"])
@require_admin
def admin_update_campaign(campaign_id):
    db = SessionLocal()
    try:
        c = db.query(MarketingCampaign).filter(MarketingCampaign.id == campaign_id).first()
        if not c:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        for f in ["name", "type", "subject", "content", "status"]:
            if f in data:
                setattr(c, f, data[f])
        db.commit()
        return jsonify({"id": c.id, "name": c.name, "status": c.status})
    finally:
        db.close()


@admin_bp.route("/api/admin/marketing/campaigns/<int:campaign_id>", methods=["DELETE"])
@require_admin
def admin_delete_campaign(campaign_id):
    db = SessionLocal()
    try:
        c = db.query(MarketingCampaign).filter(MarketingCampaign.id == campaign_id).first()
        if c:
            db.delete(c)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Email Sending (SMTP) ─────────────────────────────────────────────────────

@admin_bp.route("/api/admin/marketing/send-test-email", methods=["POST"])
@require_admin
def send_test_email():
    """Send a test email using configured SMTP settings."""
    db = SessionLocal()
    try:
        def get_setting(key, default=""):
            s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
            return s.value if s and s.value else default

        smtp_host = get_setting("marketing_smtp_host", "")
        smtp_port = int(get_setting("marketing_smtp_port", "587"))
        smtp_user = get_setting("marketing_smtp_user", "")
        smtp_pass = get_setting("marketing_smtp_pass", "")
        from_email = get_setting("marketing_from_email", smtp_user)
        from_name = get_setting("marketing_from_name", "Web Designs & Care")

        if not smtp_host:
            return jsonify({"error": "SMTP not configured. Go to Settings > Marketing > SMTP Settings."}), 400

        data = request.get_json() or {}
        to_email = data.get("to", g.user.email)
        if not to_email:
            return jsonify({"error": "Recipient email is required"}), 400

        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        msg = MIMEMultipart("alternative")
        msg["Subject"] = data.get("subject", "Test Email from Web Designs & Care")
        msg["From"] = "{} <{}>".format(from_name, from_email)
        msg["To"] = to_email

        html = data.get("html", "<h2>Test Email</h2><p>Your SMTP settings are working correctly!</p>")
        text = data.get("text", "Your SMTP settings are working correctly!")

        msg.attach(MIMEText(text, "plain"))
        msg.attach(MIMEText(html, "html"))

        with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:
            server.ehlo()
            server.starttls()
            if smtp_user and smtp_pass:
                server.login(smtp_user, smtp_pass)
            server.sendmail(from_email, [to_email], msg.as_string())

        return jsonify({"success": True, "sentTo": to_email, "message": "Test email sent successfully!"})
    except Exception as e:
        return jsonify({"error": "Failed to send email: {}".format(str(e))}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/newsletter/send", methods=["POST"])
@require_admin
def newsletter_send():
    """Send newsletter to all active subscribers via SMTP."""
    db = SessionLocal()
    try:
        def get_setting(key, default=""):
            s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
            return s.value if s and s.value else default

        smtp_host = get_setting("marketing_smtp_host", "")
        if not smtp_host:
            return jsonify({"error": "SMTP not configured. Go to Settings > Marketing > SMTP."}), 400

        data = request.get_json() or {}
        subject = data.get("subject", "Newsletter from Web Designs & Care")
        html_content = data.get("html", "")
        text_content = data.get("text", "")

        if not html_content and not text_content:
            return jsonify({"error": "Email content (html or text) is required"}), 400

        subscribers = db.query(NewsletterSubscriber).filter(
            NewsletterSubscriber.is_active == True
        ).all()

        if not subscribers:
            return jsonify({"error": "No active subscribers"}), 400

        smtp_port = int(get_setting("marketing_smtp_port", "587"))
        smtp_user = get_setting("marketing_smtp_user", "")
        smtp_pass = get_setting("marketing_smtp_pass", "")
        from_email = get_setting("marketing_from_email", smtp_user)
        from_name = get_setting("marketing_from_name", "Web Designs & Care")

        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        sent = 0
        errors = []

        with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:
            server.ehlo()
            server.starttls()
            if smtp_user and smtp_pass:
                server.login(smtp_user, smtp_pass)

            for sub in subscribers:
                try:
                    msg = MIMEMultipart("alternative")
                    msg["Subject"] = subject
                    msg["From"] = "{} <{}>".format(from_name, from_email)
                    msg["To"] = sub.email
                    msg.attach(MIMEText(text_content or "Newsletter", "plain"))
                    msg.attach(MIMEText(html_content or "<p>Newsletter</p>", "html"))
                    server.sendmail(from_email, [sub.email], msg.as_string())
                    sent += 1
                except Exception as e:
                    errors.append("{}: {}".format(sub.email, str(e)))

        return jsonify({
            "success": True,
            "sent": sent,
            "total": len(subscribers),
            "errors": errors[:5],
            "message": "Sent to {} of {} subscribers".format(sent, len(subscribers)),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Coupons (admin) ──────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/coupons", methods=["GET"])
@require_admin
def admin_get_coupons():
    db = SessionLocal()
    try:
        coupons = db.query(Coupon).order_by(desc(Coupon.created_at)).all()
        return jsonify([{
            "id": c.id, "code": c.code, "description": c.description,
            "type": c.type, "value": str(c.value),
            "minOrderAmount": str(c.min_order_amount or 0),
            "maxUses": c.max_uses, "usedCount": c.used_count or 0,
            "isActive": c.is_active,
            "expiresAt": c.expires_at.isoformat() if c.expires_at else None,
        } for c in coupons])
    finally:
        db.close()


@admin_bp.route("/api/admin/coupons", methods=["POST"])
@require_admin
def admin_create_coupon():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        code = data.get("code", "").strip().upper()
        if not code:
            return jsonify({"error": "Coupon code is required"}), 400
        existing = db.query(Coupon).filter(Coupon.code == code).first()
        if existing:
            return jsonify({"error": "Coupon code already exists"}), 409
        coupon = Coupon(
            code=code,
            description=data.get("description", ""),
            type=data.get("type", "percentage"),
            value=float(data.get("value", 10)),
            min_order_amount=float(data.get("minOrderAmount", 0)),
            max_uses=data.get("maxUses"),
            is_active=data.get("isActive", True),
        )
        db.add(coupon)
        db.commit()
        db.refresh(coupon)
        return jsonify({"id": coupon.id, "code": coupon.code, "type": coupon.type, "value": str(coupon.value)}), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/coupons/<int:coupon_id>", methods=["PUT", "PATCH"])
@require_admin
def admin_update_coupon(coupon_id):
    db = SessionLocal()
    try:
        coupon = db.query(Coupon).filter(Coupon.id == coupon_id).first()
        if not coupon:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        for f, c in {"description": "description", "type": "type", "isActive": "is_active"}.items():
            if f in data:
                setattr(coupon, c, data[f])
        if "value" in data:
            coupon.value = float(data["value"])
        if "minOrderAmount" in data:
            coupon.min_order_amount = float(data["minOrderAmount"])
        if "maxUses" in data:
            coupon.max_uses = data["maxUses"]
        db.commit()
        return jsonify({"id": coupon.id, "code": coupon.code, "isActive": coupon.is_active})
    finally:
        db.close()


@admin_bp.route("/api/admin/coupons/<int:coupon_id>", methods=["DELETE"])
@require_admin
def admin_delete_coupon(coupon_id):
    db = SessionLocal()
    try:
        coupon = db.query(Coupon).filter(Coupon.id == coupon_id).first()
        if coupon:
            db.delete(coupon)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Database Backup ──────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/backup/download", methods=["GET"])
@require_admin
def backup_download():
    """Download SQLite database as backup file."""
    import os
    import shutil
    import tempfile

    db_path = Config.DATABASE_URL.replace("sqlite:///", "")
    if not os.path.isabs(db_path):
        db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), db_path)

    if not os.path.exists(db_path):
        return jsonify({"error": "Database file not found. Only SQLite databases can be backed up this way."}), 404

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = "wdc_backup_{}.sqlite".format(timestamp)

    # Create temp copy
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".sqlite")
    tmp.close()
    shutil.copy2(db_path, tmp.name)

    try:
        with open(tmp.name, "rb") as f:
            data = f.read()
        os.unlink(tmp.name)
        return Response(
            data,
            mimetype="application/octet-stream",
            headers={"Content-Disposition": "attachment; filename={}".format(filename)},
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@admin_bp.route("/api/admin/backup/info", methods=["GET"])
@require_admin
def backup_info():
    """Get backup/database info."""
    import os
    db_path = Config.DATABASE_URL.replace("sqlite:///", "")
    if not os.path.isabs(db_path):
        db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), db_path)
    size = 0
    if os.path.exists(db_path):
        size = os.path.getsize(db_path)
    return jsonify({
        "type": "SQLite" if "sqlite" in Config.DATABASE_URL else "PostgreSQL",
        "path": db_path if IS_SQLITE else "Remote",
        "sizeBytes": size,
        "sizeMB": round(size / 1024 / 1024, 3),
        "downloadUrl": "/api/admin/backup/download",
        "note": "For MySQL/PostgreSQL, use mysqldump or pg_dump from the command line.",
    })


# ─── Global Transactions ──────────────────────────────────────────────────────

@admin_bp.route("/api/admin/transactions", methods=["GET"])
@require_admin
def admin_all_transactions():
    """All wallet transactions across all users with filters."""
    db = SessionLocal()
    try:
        from database import WalletTransaction
        q = db.query(WalletTransaction).join(User, WalletTransaction.user_id == User.id)
        txn_type = request.args.get("type")
        if txn_type:
            q = q.filter(WalletTransaction.type == txn_type)
        search = request.args.get("search", "").strip()
        if search:
            q = q.filter(User.name.ilike(f"%{search}%") | User.email.ilike(f"%{search}%"))
        total = q.count()
        page  = int(request.args.get("page", 1))
        limit = int(request.args.get("limit", 200))
        txns  = q.order_by(WalletTransaction.created_at.desc()).offset((page-1)*limit).limit(limit).all()
        # Build summary in Python (avoids SQLAlchemy conditional-aggregate syntax issues)
        all_txns_q = db.query(WalletTransaction)
        summ = {"topup": 0.0, "payment": 0.0, "refund": 0.0, "admin_add": 0.0, "count": 0}
        for t in all_txns_q.all():
            amt = float(t.amount or 0)
            summ["count"] += 1
            if t.type == "topup":       summ["topup"]     += amt
            elif t.type == "payment":   summ["payment"]   += amt
            elif t.type == "refund":    summ["refund"]    += amt
            elif t.type in ("admin_add", "admin_subtract"): summ["admin_add"] += amt
        return jsonify({
            "total": total,
            "page": page,
            "limit": limit,
            "transactions": [{
                "id": t.id,
                "userId": t.user_id,
                "userName": t.user.name if t.user else "",
                "userEmail": t.user.email if t.user else "",
                "type": t.type,
                "amount": float(t.amount),
                "balanceAfter": float(t.balance_after) if t.balance_after is not None else None,
                "description": t.description,
                "referenceId": t.reference_id,
                "createdAt": t.created_at.isoformat() if t.created_at else None,
            } for t in txns],
            "summary": {
                "totalTopup":    round(summ["topup"], 2),
                "totalPayments": round(summ["payment"], 2),
                "totalRefunds":  round(summ["refund"], 2),
                "totalAdminAdd": round(summ["admin_add"], 2),
                "totalCount":    summ["count"],
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Admin Notifications ──────────────────────────────────────────────────────

@admin_bp.route("/api/admin/notifications", methods=["GET"])
@require_admin
def admin_notifications():
    """Aggregated admin notification feed."""
    db = SessionLocal()
    try:
        from database import Order, Ticket, ContactMessage, License
        items = []

        # Pending orders
        pending_orders = db.query(Order).filter(Order.status == "pending")\
            .order_by(Order.created_at.desc()).limit(20).all()
        for o in pending_orders:
            u = db.query(User).filter(User.id == o.user_id).first()
            items.append({
                "type": "order", "priority": "high",
                "title": f"New Order #{o.id}",
                "body": f"${float(o.total):.2f} from {u.name if u else 'Unknown'} — awaiting fulfillment",
                "link": "#orders",
                "at": o.created_at.isoformat() if o.created_at else None,
                "read": o.status != "pending",
            })

        # Open tickets
        open_tickets = db.query(Ticket).filter(Ticket.status == "open")\
            .order_by(Ticket.created_at.desc()).limit(20).all()
        for t in open_tickets:
            u = db.query(User).filter(User.id == t.user_id).first()
            items.append({
                "type": "ticket", "priority": "medium",
                "title": f"Support Ticket #{t.id}: {t.subject}",
                "body": f"From {u.name if u else 'Unknown'} — priority {t.priority}",
                "link": "#tickets",
                "at": t.created_at.isoformat() if t.created_at else None,
                "read": False,
            })

        # Unread messages
        unread_msgs = db.query(ContactMessage).filter(ContactMessage.is_read == False)\
            .order_by(ContactMessage.created_at.desc()).limit(20).all()
        for m in unread_msgs:
            items.append({
                "type": "message", "priority": "low",
                "title": f"New Message: {m.subject}",
                "body": f"From {m.name} ({m.email})",
                "link": "#messages",
                "at": m.created_at.isoformat() if m.created_at else None,
                "read": False,
            })

        # Sort by date desc
        items.sort(key=lambda x: x.get("at") or "", reverse=True)

        unread = sum(1 for i in items if not i.get("read"))
        # Also include persisted Notification rows (from order/ticket/registration hooks)
        db_notifs = db.query(Notification)\
            .order_by(Notification.created_at.desc()).limit(50).all()
        for n in db_notifs:
            items.append({
                "id": n.id,
                "type": n.type or "info",
                "priority": "high" if n.type in ("order",) else "medium" if n.type in ("ticket",) else "low",
                "title": n.title,
                "body": n.message,
                "icon": n.icon or "🔔",
                "link": n.link or "#",
                "at": n.created_at.isoformat() if n.created_at else None,
                "read": n.is_read,
            })

        # Deduplicate & sort
        items.sort(key=lambda x: x.get("at") or "", reverse=True)
        unread = sum(1 for i in items if not i.get("read"))
        return jsonify({"total": len(items), "unread": unread, "notifications": items})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/notifications/unread-count", methods=["GET"])
@require_admin
def notifications_unread_count():
    """Lightweight endpoint — returns only counts for the live badge."""
    db = SessionLocal()
    try:
        from database import Order, Ticket, ContactMessage
        orders   = db.query(Order).filter(Order.status == "pending").count()
        tickets  = db.query(Ticket).filter(Ticket.status == "open").count()
        messages = db.query(ContactMessage).filter(ContactMessage.is_read == False).count()
        db_unread = db.query(Notification).filter(Notification.is_read == False).count()
        total = orders + tickets + messages + db_unread
        return jsonify({
            "total": total,
            "orders": orders,
            "tickets": tickets,
            "messages": messages,
            "dbNotifs": db_unread,
        })
    except Exception as e:
        return jsonify({"error": str(e), "total": 0}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/notifications/mark-read", methods=["POST"])
@require_admin
def notifications_mark_read():
    """Mark all Notification rows as read."""
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        notif_id = data.get("id")
        if notif_id:
            db.query(Notification).filter(Notification.id == int(notif_id))\
                .update({"is_read": True})
        else:
            db.query(Notification).filter(Notification.is_read == False)\
                .update({"is_read": True})
        db.commit()
        return jsonify({"success": True})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@admin_bp.route("/api/admin/notifications/stream", methods=["GET"])
@require_admin
def notifications_stream():
    """
    Server-Sent Events endpoint.
    Polls DB every 6 s and pushes a counts object to the client.
    """
    def generate():
        while True:
            db = SessionLocal()
            try:
                from database import Order, Ticket, ContactMessage
                orders   = db.query(Order).filter(Order.status == "pending").count()
                tickets  = db.query(Ticket).filter(Ticket.status == "open").count()
                messages = db.query(ContactMessage).filter(ContactMessage.is_read == False).count()
                db_unread = db.query(Notification).filter(Notification.is_read == False).count()
                total = orders + tickets + messages + db_unread
                payload = json.dumps({
                    "total": total,
                    "orders": orders,
                    "tickets": tickets,
                    "messages": messages,
                    "dbNotifs": db_unread,
                })
                yield f"data: {payload}\n\n"
            except Exception as e:
                yield f"data: {json.dumps({'error': str(e), 'total': 0})}\n\n"
            finally:
                db.close()
            time.sleep(6)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


# ─── Admin Reports ────────────────────────────────────────────────────────────

@admin_bp.route("/api/admin/reports/revenue", methods=["GET"])
@require_admin
def admin_report_revenue():
    """Detailed revenue report with daily breakdown."""
    db = SessionLocal()
    try:
        from database import Order, OrderItem
        days = int(request.args.get("days", 30))
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        orders = db.query(Order).filter(
            Order.status == "completed",
            Order.created_at >= cutoff
        ).order_by(Order.created_at.desc()).all()

        daily = {}
        for o in orders:
            day = o.created_at.strftime("%Y-%m-%d") if o.created_at else "unknown"
            if day not in daily:
                daily[day] = {"date": day, "revenue": 0.0, "orders": 0}
            daily[day]["revenue"] += float(o.total or 0)
            daily[day]["orders"] += 1

        daily_list = sorted(daily.values(), key=lambda x: x["date"])
        total_rev = sum(float(o.total or 0) for o in orders)
        avg_order = total_rev / len(orders) if orders else 0

        # Payment method breakdown
        pm_map = {}
        for o in orders:
            pm = o.payment_method or "unknown"
            pm_map[pm] = pm_map.get(pm, 0) + float(o.total or 0)

        return jsonify({
            "days": days,
            "totalRevenue": round(total_rev, 2),
            "totalOrders": len(orders),
            "avgOrderValue": round(avg_order, 2),
            "dailyBreakdown": daily_list,
            "paymentMethods": [{"method": k, "revenue": round(v, 2)} for k, v in pm_map.items()],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Advanced Analytics (chatbot leads + visitors + conversions) ──────────────

@admin_bp.route("/api/admin/analytics/advanced", methods=["GET"])
@require_admin
def get_advanced_analytics():
    """
    Returns enriched analytics:
    - Daily revenue last 30 days
    - Chatbot lead counts + trend
    - Page view counts + trend
    - Conversion funnel
    - Recent chatbot leads table
    """
    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        today = now.date()

        # ── Helpers ──
        def day_str(d):
            return d.strftime("%Y-%m-%d")

        def build_days(n):
            return [(today - timedelta(days=i)) for i in range(n - 1, -1, -1)]

        days_30 = build_days(30)
        days_14 = build_days(14)

        # ── Daily revenue (last 30 days) ──
        daily_rev = {}
        for d in days_30:
            daily_rev[day_str(d)] = {"date": day_str(d), "revenue": 0.0, "orders": 0}

        if IS_SQLITE:
            for row in db.execute(
                __import__('sqlalchemy').text(
                    "SELECT strftime('%Y-%m-%d', created_at) as d, "
                    "SUM(total) as rev, COUNT(*) as cnt "
                    "FROM orders WHERE status='completed' "
                    "AND created_at >= :cutoff GROUP BY d"
                ),
                {"cutoff": (now - timedelta(days=30)).strftime("%Y-%m-%d")}
            ):
                if row[0] in daily_rev:
                    daily_rev[row[0]]["revenue"] = round(float(row[1] or 0), 2)
                    daily_rev[row[0]]["orders"] = int(row[2] or 0)
        else:
            for row in db.execute(
                __import__('sqlalchemy').text(
                    "SELECT DATE(created_at) as d, SUM(total) as rev, COUNT(*) as cnt "
                    "FROM orders WHERE status='completed' "
                    "AND created_at >= :cutoff GROUP BY d"
                ),
                {"cutoff": now - timedelta(days=30)}
            ):
                k = str(row[0])
                if k in daily_rev:
                    daily_rev[k]["revenue"] = round(float(row[1] or 0), 2)
                    daily_rev[k]["orders"] = int(row[2] or 0)

        # ── Chatbot leads ──
        total_leads = 0
        leads_today = 0
        leads_week = 0
        leads_month = 0
        daily_leads = {day_str(d): {"date": day_str(d), "leads": 0} for d in days_14}

        try:
            total_leads = db.query(ChatbotLead).count()
            if IS_SQLITE:
                leads_today = db.query(ChatbotLead).filter(
                    func.strftime("%Y-%m-%d", ChatbotLead.created_at) == day_str(today)
                ).count()
                leads_week = db.query(ChatbotLead).filter(
                    ChatbotLead.created_at >= (now - timedelta(days=7)).strftime("%Y-%m-%d")
                ).count()
                leads_month = db.query(ChatbotLead).filter(
                    ChatbotLead.created_at >= (now - timedelta(days=30)).strftime("%Y-%m-%d")
                ).count()
                for row in db.execute(
                    __import__('sqlalchemy').text(
                        "SELECT strftime('%Y-%m-%d', created_at) as d, COUNT(*) as cnt "
                        "FROM chatbot_leads WHERE created_at >= :cutoff GROUP BY d"
                    ),
                    {"cutoff": (now - timedelta(days=14)).strftime("%Y-%m-%d")}
                ):
                    if row[0] in daily_leads:
                        daily_leads[row[0]]["leads"] = int(row[1] or 0)
            else:
                leads_today = db.query(ChatbotLead).filter(
                    func.date(ChatbotLead.created_at) == today
                ).count()
                leads_week = db.query(ChatbotLead).filter(
                    ChatbotLead.created_at >= now - timedelta(days=7)
                ).count()
                leads_month = db.query(ChatbotLead).filter(
                    ChatbotLead.created_at >= now - timedelta(days=30)
                ).count()
        except Exception:
            pass

        # ── Page views ──
        total_views = 0
        views_today = 0
        views_week = 0
        views_month = 0
        daily_views = {day_str(d): {"date": day_str(d), "views": 0} for d in days_14}

        try:
            total_views = db.query(PageView).count()
            if IS_SQLITE:
                views_today = db.query(PageView).filter(
                    func.strftime("%Y-%m-%d", PageView.created_at) == day_str(today)
                ).count()
                views_week = db.query(PageView).filter(
                    PageView.created_at >= (now - timedelta(days=7)).strftime("%Y-%m-%d")
                ).count()
                views_month = db.query(PageView).filter(
                    PageView.created_at >= (now - timedelta(days=30)).strftime("%Y-%m-%d")
                ).count()
                for row in db.execute(
                    __import__('sqlalchemy').text(
                        "SELECT strftime('%Y-%m-%d', created_at) as d, COUNT(*) as cnt "
                        "FROM page_views WHERE created_at >= :cutoff GROUP BY d"
                    ),
                    {"cutoff": (now - timedelta(days=14)).strftime("%Y-%m-%d")}
                ):
                    if row[0] in daily_views:
                        daily_views[row[0]]["views"] = int(row[1] or 0)
            else:
                views_today = db.query(PageView).filter(
                    func.date(PageView.created_at) == today
                ).count()
                views_week = db.query(PageView).filter(
                    PageView.created_at >= now - timedelta(days=7)
                ).count()
                views_month = db.query(PageView).filter(
                    PageView.created_at >= now - timedelta(days=30)
                ).count()
        except Exception:
            pass

        # ── Conversion funnel ──
        total_orders = db.query(Order).count()
        completed_orders = db.query(Order).filter(Order.status == "completed").count()
        total_users = db.query(User).count()

        lead_conversion_rate = round((total_leads / max(total_views, 1)) * 100, 2) if total_views > 0 else 0
        order_conversion_rate = round((total_orders / max(total_views, 1)) * 100, 2) if total_views > 0 else 0

        # ── Top products by sales ──
        top_products = db.query(Product).filter(
            Product.status == "published"
        ).order_by(desc(Product.sales)).limit(10).all()
        top_products_data = [
            {
                "id": p.id,
                "name": p.name,
                "sales": p.sales or 0,
                "revenue": round(float(p.price) * (p.sales or 0), 2),
                "price": float(p.price),
                "category": p.category or "",
            }
            for p in top_products
        ]

        # ── Recent chatbot leads ──
        recent_leads = []
        try:
            leads_list = db.query(ChatbotLead).order_by(
                desc(ChatbotLead.created_at)
            ).limit(20).all()
            recent_leads = [
                {
                    "id": l.id,
                    "name": l.name or "—",
                    "email": l.email,
                    "phone": l.phone or "—",
                    "source": l.source or "chatbot",
                    "converted": l.converted or False,
                    "createdAt": l.created_at.isoformat() if l.created_at else None,
                }
                for l in leads_list
            ]
        except Exception:
            pass

        return jsonify({
            "summary": {
                "totalPageViews": total_views,
                "todayPageViews": views_today,
                "weekPageViews": views_week,
                "monthPageViews": views_month,
                "totalLeads": total_leads,
                "leadsToday": leads_today,
                "leadsWeek": leads_week,
                "leadsMonth": leads_month,
                "totalOrders": total_orders,
                "completedOrders": completed_orders,
                "totalUsers": total_users,
                "leadConversionRate": lead_conversion_rate,
                "orderConversionRate": order_conversion_rate,
            },
            "dailyRevenue": list(daily_rev.values()),
            "dailyLeads": list(daily_leads.values()),
            "dailyViews": list(daily_views.values()),
            "topProducts": top_products_data,
            "recentLeads": recent_leads,
            "conversionFunnel": {
                "visitors": total_views,
                "leads": total_leads,
                "orders": total_orders,
                "completedOrders": completed_orders,
            },
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()
