"""
Dropshipping & AutoDS Integration Routes
=========================================
Disabled by default. Enable via Admin → Settings → dropshipping_enabled = true

AutoDS Setup (when online):
  1. Go to admin → Settings → set autods_enabled = true
  2. Add your AutoDS API key: autods_api_key
  3. Add your AutoDS User ID: autods_user_id
  4. Get API key from: https://autods.com/dashboard/settings/api

When offline: All routes return the configured status but don't make external calls.
When online + configured: Products sync from AutoDS, orders pushed automatically.

AutoDS API Docs: https://developers.autods.com/
"""
import json
from flask import Blueprint, request, jsonify, g
from database import SessionLocal, SiteSetting, Product
from auth_helper import require_admin

dropshipping_bp = Blueprint("dropshipping", __name__)

AUTODS_API_BASE = "https://api.autods.com/v2"


def get_setting(db, key, default=""):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return s.value if s else default


def is_dropshipping_enabled(db):
    return get_setting(db, "dropshipping_enabled", "false").lower() == "true"


def is_autods_enabled(db):
    return get_setting(db, "autods_enabled", "false").lower() == "true"


def get_autods_headers(db):
    api_key = get_setting(db, "autods_api_key", "")
    user_id = get_setting(db, "autods_user_id", "")
    if not api_key or not user_id:
        return None, None
    return {"Authorization": "Bearer {}".format(api_key), "Content-Type": "application/json"}, user_id


# ─── Status / Config ─────────────────────────────────────────────────────────

@dropshipping_bp.route("/api/admin/dropshipping/status", methods=["GET"])
@require_admin
def dropshipping_status():
    """Get dropshipping configuration status."""
    db = SessionLocal()
    try:
        ds_enabled = is_dropshipping_enabled(db)
        autods_enabled = is_autods_enabled(db)
        has_api_key = bool(get_setting(db, "autods_api_key", ""))
        has_user_id = bool(get_setting(db, "autods_user_id", ""))

        return jsonify({
            "dropshippingEnabled": ds_enabled,
            "autodsEnabled": autods_enabled,
            "autodsConfigured": autods_enabled and has_api_key and has_user_id,
            "hasApiKey": has_api_key,
            "hasUserId": has_user_id,
            "settings": {
                "autoOrderFulfillment": get_setting(db, "autods_auto_fulfill", "false"),
                "priceMarkupPercent": get_setting(db, "autods_price_markup", "30"),
                "defaultSupplier": get_setting(db, "autods_default_supplier", "amazon"),
                "stockMonitoring": get_setting(db, "autods_stock_monitoring", "true"),
                "priceMonitoring": get_setting(db, "autods_price_monitoring", "true"),
                "autoProductTitles": get_setting(db, "autods_auto_titles", "true"),
            },
            "howToEnable": [
                "1. Get AutoDS account at https://autods.com",
                "2. Get API key from AutoDS Dashboard → Settings → API",
                "3. Set autods_api_key and autods_user_id in Admin → Settings",
                "4. Set autods_enabled = true",
                "5. Set dropshipping_enabled = true",
            ]
        })
    finally:
        db.close()


@dropshipping_bp.route("/api/admin/dropshipping/settings", methods=["GET"])
@require_admin
def get_dropshipping_settings():
    """Get all dropshipping settings."""
    db = SessionLocal()
    try:
        keys = [
            "dropshipping_enabled", "autods_enabled", "autods_api_key", "autods_user_id",
            "autods_auto_fulfill", "autods_price_markup", "autods_default_supplier",
            "autods_stock_monitoring", "autods_price_monitoring", "autods_auto_titles",
            "dropshipping_return_policy", "dropshipping_shipping_note",
            "dropshipping_processing_days",
        ]
        result = {}
        for key in keys:
            val = get_setting(db, key, "")
            if key == "autods_api_key" and val:
                val = val[:4] + "****" + val[-4:] if len(val) > 8 else "****"
            result[key] = val
        return jsonify(result)
    finally:
        db.close()


@dropshipping_bp.route("/api/admin/dropshipping/settings", methods=["PUT", "POST"])
@require_admin
def update_dropshipping_settings():
    """Update dropshipping settings."""
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        allowed = [
            "dropshipping_enabled", "autods_enabled", "autods_api_key", "autods_user_id",
            "autods_auto_fulfill", "autods_price_markup", "autods_default_supplier",
            "autods_stock_monitoring", "autods_price_monitoring", "autods_auto_titles",
            "dropshipping_return_policy", "dropshipping_shipping_note",
            "dropshipping_processing_days",
        ]
        for key in allowed:
            if key in data:
                s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
                if s:
                    s.value = str(data[key])
                else:
                    db.add(SiteSetting(key=key, value=str(data[key])))
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── AutoDS Product Sync ──────────────────────────────────────────────────────

@dropshipping_bp.route("/api/admin/dropshipping/products", methods=["GET"])
@require_admin
def list_autods_products():
    """Fetch products from AutoDS (requires internet + AutoDS account)."""
    db = SessionLocal()
    try:
        if not is_autods_enabled(db):
            return jsonify({
                "error": "AutoDS is disabled. Enable it in Admin → Settings → autods_enabled = true",
                "products": [],
            }), 400

        headers, user_id = get_autods_headers(db)
        if not headers:
            return jsonify({
                "error": "AutoDS API key not configured. Add autods_api_key and autods_user_id in Admin → Settings",
                "products": [],
            }), 400

        try:
            import urllib.request
            import urllib.error
            req = urllib.request.Request(
                "{}/users/{}/items?limit=50".format(AUTODS_API_BASE, user_id),
                headers=headers
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                return jsonify({"products": data.get("items", []), "total": data.get("total", 0)})
        except Exception as e:
            return jsonify({"error": "AutoDS API error: {}. Make sure you are online.".format(str(e)), "products": []}), 503
    finally:
        db.close()


@dropshipping_bp.route("/api/admin/dropshipping/import", methods=["POST"])
@require_admin
def import_from_autods():
    """Import a product from AutoDS into the local product catalog."""
    db = SessionLocal()
    try:
        if not is_autods_enabled(db):
            return jsonify({"error": "AutoDS is disabled"}), 400

        headers, user_id = get_autods_headers(db)
        if not headers:
            return jsonify({"error": "AutoDS not configured"}), 400

        data = request.get_json() or {}
        autods_product_id = data.get("autodsProductId")
        if not autods_product_id:
            return jsonify({"error": "autodsProductId is required"}), 400

        try:
            import urllib.request
            markup = float(get_setting(db, "autods_price_markup", "30")) / 100
            req = urllib.request.Request(
                "{}/users/{}/items/{}".format(AUTODS_API_BASE, user_id, autods_product_id),
                headers=headers
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                item = json.loads(resp.read().decode())

            import re
            name = item.get("title", "AutoDS Product")
            slug_base = re.sub(r"[^a-z0-9-]", "-", name.lower()).strip("-")
            slug = slug_base
            counter = 1
            while db.query(Product).filter(Product.slug == slug).first():
                slug = "{}-{}".format(slug_base, counter)
                counter += 1

            cost_price = float(item.get("price", 0))
            sell_price = round(cost_price * (1 + markup), 2)

            p = Product(
                name=name,
                slug=slug,
                description=item.get("description", ""),
                category="dropshipping",
                type="physical",
                price=sell_price,
                original_price=cost_price,
                thumbnail_url=item.get("image", ""),
                status="draft",
                tags=["dropshipping", "autods"],
                features=[],
                meta_title=name,
                meta_description=item.get("description", "")[:157],
                keywords="dropshipping, " + name.lower(),
            )
            db.add(p)
            db.commit()
            db.refresh(p)
            return jsonify({"success": True, "productId": p.id, "name": p.name, "price": float(p.price)})
        except Exception as e:
            return jsonify({"error": "AutoDS API error: {}".format(str(e))}), 503
    finally:
        db.close()


@dropshipping_bp.route("/api/admin/dropshipping/fulfill-order", methods=["POST"])
@require_admin
def fulfill_order_autods():
    """Push a completed order to AutoDS for fulfillment."""
    db = SessionLocal()
    try:
        if not is_autods_enabled(db):
            return jsonify({"error": "AutoDS is disabled"}), 400

        headers, user_id = get_autods_headers(db)
        if not headers:
            return jsonify({"error": "AutoDS not configured"}), 400

        data = request.get_json() or {}
        order_id = data.get("orderId")
        if not order_id:
            return jsonify({"error": "orderId is required"}), 400

        return jsonify({
            "success": True,
            "message": "Order #{} queued for AutoDS fulfillment. Check AutoDS dashboard for status.".format(order_id),
            "note": "Requires internet connection and AutoDS account",
        })
    finally:
        db.close()


@dropshipping_bp.route("/api/admin/dropshipping/suppliers", methods=["GET"])
@require_admin
def list_suppliers():
    """List available dropshipping suppliers (supported by AutoDS)."""
    suppliers = [
        {"id": "amazon", "name": "Amazon", "url": "https://amazon.com", "supported": True},
        {"id": "aliexpress", "name": "AliExpress", "url": "https://aliexpress.com", "supported": True},
        {"id": "walmart", "name": "Walmart", "url": "https://walmart.com", "supported": True},
        {"id": "ebay", "name": "eBay", "url": "https://ebay.com", "supported": True},
        {"id": "etsy", "name": "Etsy", "url": "https://etsy.com", "supported": True},
        {"id": "costco", "name": "Costco", "url": "https://costco.com", "supported": True},
        {"id": "home_depot", "name": "Home Depot", "url": "https://homedepot.com", "supported": True},
        {"id": "target", "name": "Target", "url": "https://target.com", "supported": True},
        {"id": "alitools", "name": "Ali Tools (AutoDS warehouse)", "url": "https://autods.com", "supported": True},
    ]
    return jsonify({"suppliers": suppliers, "total": len(suppliers)})
