"""
Export & Import Routes
======================
CSV export for products, orders, users.
Sample CSV template download for product import.
All work offline — no external dependencies needed.
"""
import csv
import io
import json
from flask import Blueprint, request, jsonify, Response
from sqlalchemy import desc
from database import SessionLocal, Product, Order, OrderItem, User, License
from auth_helper import require_admin

export_bp = Blueprint("export", __name__)

PRODUCT_CSV_HEADERS = [
    "name", "slug", "description", "category", "type",
    "price", "originalPrice", "discount",
    "thumbnailUrl", "demoUrl", "previewUrl",
    "status", "tags", "features",
    "metaTitle", "metaDescription", "keywords",
]

PRODUCT_CSV_SAMPLE_ROWS = [
    {
        "name": "My Awesome Template",
        "slug": "my-awesome-template",
        "description": "A beautiful and responsive website template for modern businesses.",
        "category": "templates",
        "type": "template",
        "price": "29.00",
        "originalPrice": "59.00",
        "discount": "51",
        "thumbnailUrl": "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800",
        "demoUrl": "https://demo.example.com",
        "previewUrl": "",
        "status": "published",
        "tags": "react,tailwind,landing-page",
        "features": "Responsive,Dark Mode,SEO Optimized",
        "metaTitle": "My Awesome Template | Web Designs & Care",
        "metaDescription": "A beautiful and responsive website template for modern businesses. Download instantly.",
        "keywords": "react template, tailwind css, landing page, web design",
    },
    {
        "name": "Portfolio Pro Theme",
        "slug": "portfolio-pro-theme",
        "description": "Stunning portfolio theme for designers and developers with smooth animations.",
        "category": "themes",
        "type": "theme",
        "price": "19.00",
        "originalPrice": "39.00",
        "discount": "51",
        "thumbnailUrl": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
        "demoUrl": "",
        "previewUrl": "",
        "status": "draft",
        "tags": "portfolio,designer,animation",
        "features": "Smooth Animations,Project Gallery,Contact Form",
        "metaTitle": "Portfolio Pro Theme | Web Designs & Care",
        "metaDescription": "Stunning portfolio theme with smooth animations and project galleries.",
        "keywords": "portfolio theme, designer portfolio, animation",
    },
]


# ─── Sample CSV Template ──────────────────────────────────────────────────────

@export_bp.route("/api/admin/import/sample-csv", methods=["GET"])
@require_admin
def download_sample_csv():
    """Download a sample CSV file for product import."""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=PRODUCT_CSV_HEADERS)
    writer.writeheader()
    for row in PRODUCT_CSV_SAMPLE_ROWS:
        writer.writerow(row)

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={
            "Content-Disposition": "attachment; filename=product_import_template.csv",
            "Content-Type": "text/csv; charset=utf-8",
        },
    )


@export_bp.route("/api/admin/import/instructions", methods=["GET"])
@require_admin
def import_instructions():
    """Get CSV import instructions and field descriptions."""
    return jsonify({
        "endpoint": "/api/admin/products/import",
        "method": "POST",
        "contentType": "multipart/form-data",
        "field": "file",
        "supportedFormats": ["CSV", "XLSX", "XLS"],
        "requiredFields": ["name"],
        "optionalFields": [
            "slug (auto-generated if empty)",
            "description",
            "category (templates/themes/plugins/bundles/ui-kits/mobile/dropshipping)",
            "type (template/theme/plugin/bundle/ui-kit)",
            "price (default: 0)",
            "originalPrice",
            "discount (percentage, e.g. 50)",
            "thumbnailUrl",
            "demoUrl",
            "status (published/draft — default: draft)",
            "tags (comma-separated, e.g. react,tailwind,landing-page)",
            "features (comma-separated, e.g. Responsive,Dark Mode,SEO)",
            "metaTitle",
            "metaDescription",
            "keywords",
        ],
        "notes": [
            "Tags and Features: use comma-separated values",
            "Duplicate slugs get a number suffix automatically",
            "Excel support requires: pip install openpyxl",
            "Download sample CSV at: /api/admin/import/sample-csv",
        ],
    })


# ─── Product Export ───────────────────────────────────────────────────────────

@export_bp.route("/api/admin/export/products", methods=["GET"])
@require_admin
def export_products():
    """Export all products as CSV."""
    db = SessionLocal()
    try:
        fmt = request.args.get("format", "csv")
        status_filter = request.args.get("status")

        q = db.query(Product)
        if status_filter:
            q = q.filter(Product.status == status_filter)
        products = q.order_by(desc(Product.created_at)).all()

        output = io.StringIO()
        headers = [
            "id", "name", "slug", "category", "type", "price", "originalPrice",
            "discount", "status", "rating", "ratingCount", "sales", "downloads",
            "thumbnailUrl", "demoUrl", "description", "tags", "features",
            "metaTitle", "metaDescription", "keywords", "createdAt",
        ]
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()

        for p in products:
            writer.writerow({
                "id": p.id,
                "name": p.name,
                "slug": p.slug,
                "category": p.category,
                "type": p.type,
                "price": float(p.price),
                "originalPrice": float(p.original_price) if p.original_price else "",
                "discount": p.discount or 0,
                "status": p.status,
                "rating": float(p.rating or 0),
                "ratingCount": p.rating_count or 0,
                "sales": p.sales or 0,
                "downloads": p.downloads or 0,
                "thumbnailUrl": p.thumbnail_url or "",
                "demoUrl": p.demo_url or "",
                "description": (p.description or "")[:200],
                "tags": ",".join(p.tags) if isinstance(p.tags, list) else (p.tags or ""),
                "features": ",".join(p.features) if isinstance(p.features, list) else (p.features or ""),
                "metaTitle": p.meta_title or "",
                "metaDescription": p.meta_description or "",
                "keywords": p.keywords or "",
                "createdAt": p.created_at.strftime("%Y-%m-%d") if p.created_at else "",
            })

        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": "attachment; filename=products_export.csv",
                "Content-Type": "text/csv; charset=utf-8",
            },
        )
    finally:
        db.close()


# ─── Order Export ─────────────────────────────────────────────────────────────

@export_bp.route("/api/admin/export/orders", methods=["GET"])
@require_admin
def export_orders():
    """Export all orders as CSV."""
    db = SessionLocal()
    try:
        status_filter = request.args.get("status")
        q = db.query(Order, User).join(User, Order.user_id == User.id)
        if status_filter:
            q = q.filter(Order.status == status_filter)
        rows = q.order_by(desc(Order.created_at)).all()

        output = io.StringIO()
        headers = [
            "orderId", "userName", "userEmail", "status", "total",
            "couponCode", "discountAmount", "itemCount", "products", "createdAt",
        ]
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()

        for order, user in rows:
            items = db.query(OrderItem).filter(OrderItem.order_id == order.id).all()
            product_names = [i.product.name if i.product else "N/A" for i in items]
            writer.writerow({
                "orderId": order.id,
                "userName": user.name or "",
                "userEmail": user.email or "",
                "status": order.status,
                "total": float(order.total),
                "couponCode": order.coupon_code or "",
                "discountAmount": float(order.discount_amount or 0),
                "itemCount": len(items),
                "products": " | ".join(product_names),
                "createdAt": order.created_at.strftime("%Y-%m-%d %H:%M") if order.created_at else "",
            })

        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": "attachment; filename=orders_export.csv",
                "Content-Type": "text/csv; charset=utf-8",
            },
        )
    finally:
        db.close()


# ─── User Export ──────────────────────────────────────────────────────────────

@export_bp.route("/api/admin/export/users", methods=["GET"])
@require_admin
def export_users():
    """Export all users as CSV."""
    db = SessionLocal()
    try:
        users = db.query(User).order_by(desc(User.created_at)).all()

        output = io.StringIO()
        headers = [
            "id", "name", "email", "phone", "role", "walletBalance",
            "loginMethod", "ordersCount", "createdAt",
        ]
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()

        for u in users:
            order_count = db.query(Order).filter(Order.user_id == u.id).count()
            writer.writerow({
                "id": u.id,
                "name": u.name or "",
                "email": u.email or "",
                "phone": u.phone or "",
                "role": u.role,
                "walletBalance": float(u.wallet_balance or 0),
                "loginMethod": u.login_method or "demo",
                "ordersCount": order_count,
                "createdAt": u.created_at.strftime("%Y-%m-%d") if u.created_at else "",
            })

        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": "attachment; filename=users_export.csv",
                "Content-Type": "text/csv; charset=utf-8",
            },
        )
    finally:
        db.close()


# ─── Revenue Export ───────────────────────────────────────────────────────────

@export_bp.route("/api/admin/export/revenue", methods=["GET"])
@require_admin
def export_revenue():
    """Export monthly revenue summary as CSV."""
    from sqlalchemy import func, extract
    from datetime import datetime, timedelta, timezone

    db = SessionLocal()
    try:
        now = datetime.now(timezone.utc)
        output = io.StringIO()
        headers = ["month", "year", "orders", "revenue", "avgOrderValue"]
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()

        MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

        for i in range(11, -1, -1):
            target = now - timedelta(days=30 * i)
            m = target.month
            y = target.year

            month_orders = db.query(Order).filter(
                Order.status == "completed",
                func.strftime("%Y", Order.created_at) == str(y),
                func.strftime("%m", Order.created_at) == "{:02d}".format(m),
            ).all()

            total = sum(float(o.total) for o in month_orders)
            count = len(month_orders)
            avg = round(total / count, 2) if count else 0

            writer.writerow({
                "month": MONTHS[m - 1],
                "year": y,
                "orders": count,
                "revenue": round(total, 2),
                "avgOrderValue": avg,
            })

        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": "attachment; filename=revenue_export.csv",
                "Content-Type": "text/csv; charset=utf-8",
            },
        )
    finally:
        db.close()


# ─── Licenses Export ──────────────────────────────────────────────────────────

@export_bp.route("/api/admin/export/licenses", methods=["GET"])
@require_admin
def export_licenses():
    """Export all license keys as CSV."""
    db = SessionLocal()
    try:
        licenses = db.query(License).order_by(desc(License.created_at)).all()

        output = io.StringIO()
        headers = [
            "id", "licenseKey", "status", "userEmail", "productName",
            "orderId", "createdAt", "expiresAt",
        ]
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()

        for lic in licenses:
            user = db.query(User).filter(User.id == lic.user_id).first()
            writer.writerow({
                "id": lic.id,
                "licenseKey": lic.license_key,
                "status": lic.status,
                "userEmail": user.email if user else "",
                "productName": lic.product.name if lic.product else "",
                "orderId": lic.order_id or "",
                "createdAt": lic.created_at.strftime("%Y-%m-%d") if lic.created_at else "",
                "expiresAt": lic.expires_at.strftime("%Y-%m-%d") if lic.expires_at else "Never",
            })

        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={
                "Content-Disposition": "attachment; filename=licenses_export.csv",
                "Content-Type": "text/csv; charset=utf-8",
            },
        )
    finally:
        db.close()
