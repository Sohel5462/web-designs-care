"""
Authentication Routes
=====================
Real email/password login + registration.
Demo-login kept for React frontend compatibility.
"""
import hashlib
import os
from flask import Blueprint, request, jsonify, make_response, g
from sqlalchemy import desc
from database import SessionLocal, User, Order, License, WishlistItem, CartItem
from auth_helper import create_token, get_current_user, require_auth
from datetime import datetime, timezone

auth_bp = Blueprint("auth", __name__)


def _hash_password(password: str) -> str:
    """SHA-256 hash with salt stored inline: salt:hash"""
    salt = os.urandom(16).hex()
    h = hashlib.sha256((salt + password).encode()).hexdigest()
    return "{}:{}".format(salt, h)


def _check_password(password: str, stored: str) -> bool:
    """Verify a password against stored salt:hash"""
    try:
        salt, h = stored.split(":", 1)
        return hashlib.sha256((salt + password).encode()).hexdigest() == h
    except Exception:
        return False


def user_to_dict(user: User) -> dict:
    return {
        "id": user.id,
        "openId": user.open_id,
        "name": user.name,
        "email": user.email,
        "phone": user.phone,
        "role": user.role,
        "walletBalance": str(user.wallet_balance or "0.00"),
        "loginMethod": user.login_method,
        "createdAt": user.created_at.isoformat() if user.created_at else None,
    }


def _make_auth_response(user: User):
    """Create a JSON response with auth cookie set. Includes token in body for JS clients."""
    token = create_token(user.id, user.role)
    resp = make_response(jsonify({"token": token, "user": user_to_dict(user)}))
    resp.set_cookie(
        "auth_token", token,
        httponly=True, samesite="Lax",
        max_age=60 * 60 * 24 * 30,
    )
    return resp


# ─── GET current user ─────────────────────────────────────────────────────────

@auth_bp.route("/api/auth/me", methods=["GET"])
def me():
    user = get_current_user()
    if not user:
        return jsonify(None)
    return jsonify(user_to_dict(user))


# ─── Real Registration ─────────────────────────────────────────────────────────

@auth_bp.route("/api/auth/register", methods=["POST"])
def register():
    """Register a new user with real email + password."""
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = (data.get("password") or "").strip()

    if not email:
        return jsonify({"error": "Email is required"}), 400
    if not password or len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters"}), 400
    if not name:
        name = email.split("@")[0].title()

    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.email == email).first()
        if existing:
            return jsonify({"error": "An account with this email already exists"}), 409

        user = User(
            open_id="reg-{}".format(email.replace("@", "-").replace(".", "-")),
            name=name,
            email=email,
            role="user",
            login_method="password",
            password_hash=_hash_password(password),
        )
        db.add(user)
        db.flush()

        # ── Admin notification ──
        try:
            from routes.notif_utils import push_notification
            push_notification(
                db,
                title=f"👤 New Registration: {name}",
                message=f"{email} just signed up",
                notif_type="registration",
                link="#users",
                icon="👤",
            )
        except Exception:
            pass

        db.commit()
        db.refresh(user)
        return _make_auth_response(user), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Real Login (email + password) ────────────────────────────────────────────

@auth_bp.route("/api/auth/login", methods=["POST"])
def login():
    """
    Real login. Supports two modes:
    - email + password → looks up user and verifies password
    - role only (no password) → demo mode (for React frontend compatibility)
    """
    data = request.get_json() or {}
    email = (data.get("email") or "").strip().lower()
    password = (data.get("password") or "").strip()
    role = (data.get("role") or "user").strip()

    # ── Real login ──
    if email and password:
        db = SessionLocal()
        try:
            user = db.query(User).filter(User.email == email).first()
            if not user:
                return jsonify({"error": "No account found with this email"}), 401
            if user.password_hash and not _check_password(password, user.password_hash):
                return jsonify({"error": "Incorrect password"}), 401
            if not user.password_hash:
                # Demo user — allow login without password check
                pass
            user.last_signed_in = datetime.now(timezone.utc)
            db.commit()
            return _make_auth_response(user)
        except Exception as e:
            db.rollback()
            return jsonify({"error": str(e)}), 500
        finally:
            db.close()

    # ── Demo login fallback (React frontend compatibility) ──
    return demo_login()


# ─── Demo Login ───────────────────────────────────────────────────────────────

@auth_bp.route("/api/auth/demo-login", methods=["POST"])
def demo_login():
    """Demo login — auto-creates user. Used by React frontend."""
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    role = (data.get("role") or "user").strip()

    if role not in ("user", "admin"):
        role = "user"
    if not name:
        name = "Admin User" if role == "admin" else "Customer"
    if not email:
        email = "demo-{}@webdesignscare.com".format(role)

    db = SessionLocal()
    try:
        open_id = "demo-{}".format(email.replace("@", "-").replace(".", "-"))
        user = db.query(User).filter(User.open_id == open_id).first()
        if not user:
            user = User(
                open_id=open_id,
                name=name,
                email=email,
                role=role,
                login_method="demo",
            )
            db.add(user)
            db.commit()
            db.refresh(user)
        else:
            user.name = name
            user.role = role
            user.last_signed_in = datetime.now(timezone.utc)
            db.commit()
        return _make_auth_response(user)
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Logout ───────────────────────────────────────────────────────────────────

@auth_bp.route("/api/auth/logout", methods=["POST"])
def logout():
    resp = make_response(jsonify({"success": True}))
    resp.delete_cookie("auth_token")
    return resp


# ─── Update Profile ───────────────────────────────────────────────────────────

@auth_bp.route("/api/auth/update-profile", methods=["PUT", "PATCH"])
@require_auth
def update_profile():
    data = request.get_json() or {}
    db = SessionLocal()
    try:
        u = db.query(User).filter(User.id == g.user.id).first()
        if not u:
            return jsonify({"error": "User not found"}), 404
        if "name" in data and data["name"].strip():
            u.name = data["name"].strip()
        if "phone" in data:
            u.phone = (data["phone"] or "").strip()
        # Allow password change
        if "newPassword" in data and data["newPassword"]:
            new_pwd = data["newPassword"].strip()
            if len(new_pwd) < 6:
                return jsonify({"error": "Password must be at least 6 characters"}), 400
            current = data.get("currentPassword", "")
            if u.password_hash and not _check_password(current, u.password_hash):
                return jsonify({"error": "Current password is incorrect"}), 401
            u.password_hash = _hash_password(new_pwd)
            u.login_method = "password"
        db.commit()
        return jsonify(user_to_dict(u))
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Customer Dashboard ───────────────────────────────────────────────────────

@auth_bp.route("/api/auth/dashboard", methods=["GET"])
@require_auth
def dashboard():
    """Customer dashboard — orders, licenses, wishlist summary."""
    db = SessionLocal()
    try:
        orders = db.query(Order).filter(Order.user_id == g.user.id).order_by(desc(Order.created_at)).limit(5).all()
        licenses = db.query(License).filter(License.user_id == g.user.id, License.status == "active").count()
        wishlist = db.query(WishlistItem).filter(WishlistItem.user_id == g.user.id).count()
        cart = db.query(CartItem).filter(CartItem.user_id == g.user.id).count()

        recent_orders = [{
            "id": o.id,
            "status": o.status,
            "total": str(o.total),
            "createdAt": o.created_at.isoformat() if o.created_at else None,
            "itemCount": len(o.items) if o.items else 0,
        } for o in orders]

        return jsonify({
            "user": user_to_dict(g.user),
            "recentOrders": recent_orders,
            "stats": {
                "totalOrders": db.query(Order).filter(Order.user_id == g.user.id).count(),
                "activeLicenses": licenses,
                "wishlistItems": wishlist,
                "cartItems": cart,
            },
        })
    finally:
        db.close()
