from flask import Blueprint, request, jsonify, g, send_from_directory
from sqlalchemy import desc
from database import SessionLocal, Order, OrderItem, CartItem, Product, License, Coupon, User, WalletTransaction
from auth_helper import require_auth, require_admin
import uuid
import os
from datetime import datetime, timezone

order_bp = Blueprint("orders", __name__)


def order_to_dict(order: Order, include_items=True) -> dict:
    result = {
        "id": order.id,
        "userId": order.user_id,
        "userName": order.user.name if order.user else None,
        "userEmail": order.user.email if order.user else None,
        "status": order.status,
        "total": str(order.total),
        "couponCode": order.coupon_code,
        "discountAmount": str(order.discount_amount or "0.00"),
        "paymentMethod": getattr(order, "payment_method", "demo") or "demo",
        "stripePaymentIntentId": order.stripe_payment_intent_id,
        "createdAt": order.created_at.isoformat() if order.created_at else None,
    }
    if include_items and order.items:
        result["items"] = [
            {
                "id": item.id,
                "productId": item.product_id,
                "price": str(item.price),
                "product": {
                    "id": item.product.id,
                    "name": item.product.name,
                    "slug": item.product.slug,
                    "thumbnailUrl": item.product.thumbnail_url,
                    "category": item.product.category,
                    "fileKey": item.product.file_key,
                    "fileName": item.product.file_name,
                    "fileSize": item.product.file_size,
                } if item.product else None,
            }
            for item in order.items
        ]
    return result


@order_bp.route("/api/orders", methods=["GET"])
@require_auth
def get_orders():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 50)), 200)
        offset = int(request.args.get("offset", 0))
        status = request.args.get("status")
        q = db.query(Order).filter(Order.user_id == g.user.id)
        if status:
            q = q.filter(Order.status == status)
        total = q.count()
        orders = q.order_by(desc(Order.created_at)).offset(offset).limit(limit).all()
        return jsonify({"orders": [order_to_dict(o) for o in orders], "total": total})
    finally:
        db.close()


@order_bp.route("/api/orders", methods=["POST"])
@require_auth
def create_order():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        coupon_code = data.get("couponCode")
        payment_method = data.get("paymentMethod", "demo")

        cart_items = db.query(CartItem).filter(CartItem.user_id == g.user.id).all()
        if not cart_items:
            return jsonify({"error": "Cart is empty"}), 400

        subtotal = sum(float(item.product.price) for item in cart_items if item.product)
        discount_amount = 0.0

        if coupon_code:
            coupon = db.query(Coupon).filter(Coupon.code == coupon_code.upper(), Coupon.is_active == True).first()
            if coupon:
                if coupon.type == "percentage":
                    discount_amount = subtotal * float(coupon.value) / 100
                else:
                    discount_amount = float(coupon.value)
                coupon.used_count = (coupon.used_count or 0) + 1

        total = max(0, subtotal - discount_amount)

        # ── Wallet payment ──
        if payment_method == "wallet":
            user = db.query(User).filter(User.id == g.user.id).first()
            wallet_balance = float(user.wallet_balance or 0)
            if wallet_balance < total:
                return jsonify({
                    "error": "Insufficient wallet balance. Balance: ${:.2f}, Required: ${:.2f}".format(
                        wallet_balance, total)
                }), 400
            user.wallet_balance = round(wallet_balance - total, 2)

        order = Order(
            user_id=g.user.id,
            status="completed",
            total=total,
            coupon_code=coupon_code,
            discount_amount=discount_amount,
            payment_method=payment_method,
            stripe_payment_intent_id="demo_{}".format(uuid.uuid4().hex[:16]) if payment_method == "demo" else None,
        )
        db.add(order)
        db.flush()

        for cart_item in cart_items:
            if not cart_item.product:
                continue
            oi = OrderItem(order_id=order.id, product_id=cart_item.product_id, price=cart_item.product.price)
            db.add(oi)
            license = License(
                user_id=g.user.id,
                product_id=cart_item.product_id,
                order_id=order.id,
                license_key="WDC-{}-{}".format(uuid.uuid4().hex[:8].upper(), uuid.uuid4().hex[:8].upper()),
                status="active",
            )
            db.add(license)
            p = cart_item.product
            p.sales = (p.sales or 0) + 1
            p.downloads = (p.downloads or 0) + 1

        # Record wallet transaction if paid by wallet
        if payment_method == "wallet" and total > 0:
            user = db.query(User).filter(User.id == g.user.id).first()
            txn = WalletTransaction(
                user_id=g.user.id,
                type="payment",
                amount=total,
                balance_after=float(user.wallet_balance or 0),
                description="Purchase — Order #{}".format(order.id),
                reference_id=str(order.id),
            )
            db.add(txn)

        for ci in cart_items:
            db.delete(ci)

        # ── Admin notification ──
        try:
            from routes.notif_utils import push_notification
            user = db.query(User).filter(User.id == g.user.id).first()
            uname = user.name if user else "Customer"
            product_names = ", ".join(
                ci.product.name for ci in cart_items if ci.product
            )[:80]
            push_notification(
                db,
                title=f"🛒 New Order #{order.id}",
                message=f"${float(total):.2f} from {uname} — {product_names}",
                notif_type="order",
                link="#orders",
                icon="🛒",
            )
        except Exception:
            pass

        db.commit()
        db.refresh(order)

        return jsonify({"orderId": order.id, "order": order_to_dict(order)})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@order_bp.route("/api/orders/downloads", methods=["GET"])
@require_auth
def get_my_downloads():
    """Return all completed orders with items for the logged-in user."""
    db = SessionLocal()
    try:
        orders = (
            db.query(Order)
            .filter(Order.user_id == g.user.id, Order.status == "completed")
            .order_by(desc(Order.created_at))
            .all()
        )
        result = []
        for order in orders:
            items_data = []
            for item in (order.items or []):
                p = item.product
                if not p:
                    continue
                items_data.append({
                    "id": item.id,
                    "productId": p.id,
                    "name": p.name,
                    "slug": p.slug,
                    "thumbnailUrl": p.thumbnail_url,
                    "category": p.category,
                    "price": str(item.price),
                    "hasFile": bool(p.file_key),
                    "fileName": p.file_name or p.file_key,
                    "fileSize": p.file_size,
                    "downloadUrl": "/api/orders/{}/download/{}".format(order.id, p.id) if p.file_key else None,
                })
            result.append({
                "id": order.id,
                "createdAt": order.created_at.isoformat() if order.created_at else None,
                "status": order.status,
                "total": str(order.total),
                "items": items_data,
            })
        return jsonify({"orders": result, "total": len(result)})
    finally:
        db.close()


@order_bp.route("/api/orders/<int:order_id>/download/<int:product_id>", methods=["GET"])
@require_auth
def download_product_file(order_id, product_id):
    """Download the file for a purchased product. Validates ownership."""
    db = SessionLocal()
    try:
        order = db.query(Order).filter(
            Order.id == order_id,
            Order.user_id == g.user.id,
            Order.status == "completed"
        ).first()
        if not order:
            return jsonify({"error": "Order not found or not completed"}), 404

        item = next((i for i in order.items if i.product_id == product_id), None)
        if not item:
            return jsonify({"error": "Product not in this order"}), 404

        product = item.product
        if not product or not product.file_key:
            return jsonify({"error": "No file available for this product yet"}), 404

        uploads_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")
        file_path = os.path.join(uploads_dir, product.file_key)
        if not os.path.exists(file_path):
            return jsonify({"error": "File not found on server. Please contact support."}), 404

        product.downloads = (product.downloads or 0) + 1
        db.commit()

        return send_from_directory(
            uploads_dir,
            product.file_key,
            as_attachment=True,
            download_name=product.file_name or product.file_key,
        )
    finally:
        db.close()


@order_bp.route("/api/admin/orders", methods=["GET"])
@require_admin
def admin_get_orders():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 20)), 100)
        offset = int(request.args.get("offset", 0))
        q = db.query(Order)
        status = request.args.get("status")
        if status:
            q = q.filter(Order.status == status)
        total = q.count()
        orders = q.order_by(desc(Order.created_at)).offset(offset).limit(limit).all()
        return jsonify({"orders": [order_to_dict(o) for o in orders], "total": total})
    finally:
        db.close()


@order_bp.route("/api/admin/orders/<int:order_id>", methods=["PUT"])
@require_admin
def admin_update_order(order_id):
    db = SessionLocal()
    try:
        order = db.query(Order).filter(Order.id == order_id).first()
        if not order:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        if "status" in data:
            order.status = data["status"]
        db.commit()
        return jsonify(order_to_dict(order))
    finally:
        db.close()
