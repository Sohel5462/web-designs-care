"""
Miscellaneous Routes
====================
Notifications • Contact form • Newsletter • Search • Download
Bulk product ops • System status • Activity log • Social media settings
Static pages • Image upload for products
"""
import os
import re
import json
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, g, send_file, Response
from sqlalchemy import or_, desc
from database import (
    SessionLocal, Product, User, Order, OrderItem, License,
    Notification, NewsletterSubscriber, ContactMessage, ActivityLog,
    SiteSetting, Ticket, Coupon, ChatbotLead, PageView,
)
from auth_helper import require_auth, require_admin, get_current_user

misc_bp = Blueprint("misc", __name__)


def _get_setting(db, key, default=""):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return s.value if s and s.value is not None else default


def _set_setting(db, key, value):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    if s:
        s.value = str(value) if not isinstance(value, str) else value
    else:
        db.add(SiteSetting(key=key, value=str(value) if not isinstance(value, str) else value))


# ─── System Health / Status ───────────────────────────────────────────────────

@misc_bp.route("/api/system/status", methods=["GET"])
def system_status():
    import sys, platform
    db = SessionLocal()
    try:
        product_count = db.query(Product).filter(Product.status == "published").count()
        user_count = db.query(User).count()
        order_count = db.query(Order).count()
        site_name = _get_setting(db, "site_name", "Web Designs & Care")
        return jsonify({
            "status": "ok",
            "version": "2.0.0",
            "siteName": site_name,
            "python": sys.version.split()[0],
            "platform": platform.system(),
            "stats": {
                "publishedProducts": product_count,
                "totalUsers": user_count,
                "totalOrders": order_count,
            },
        })
    finally:
        db.close()


@misc_bp.route("/api/admin/system/info", methods=["GET"])
@require_admin
def system_info():
    import sys, platform
    from config import Config
    db = SessionLocal()
    try:
        db_size = 0
        db_path = Config.DATABASE_URL.replace("sqlite:///", "")
        if not os.path.isabs(db_path):
            db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), db_path)
        if os.path.exists(db_path):
            db_size = os.path.getsize(db_path)

        stats = {
            "products": db.query(Product).count(),
            "publishedProducts": db.query(Product).filter(Product.status == "published").count(),
            "users": db.query(User).count(),
            "orders": db.query(Order).count(),
            "openTickets": db.query(Ticket).filter(Ticket.status == "open").count(),
            "unreadMessages": db.query(ContactMessage).filter(ContactMessage.is_read == False).count(),
            "newsletterSubscribers": db.query(NewsletterSubscriber).filter(NewsletterSubscriber.is_active == True).count(),
        }

        installed = []
        for pkg_name, label in [("flask", "Flask"), ("sqlalchemy", "SQLAlchemy"),
                                  ("jwt", "PyJWT"), ("openpyxl", "openpyxl (Excel import)"),
                                  ("stripe", "stripe (payments)")]:
            try:
                mod = __import__(pkg_name)
                ver = getattr(mod, "__version__", "")
                installed.append("{} {}".format(label, ver).strip())
            except ImportError:
                installed.append("{} NOT installed".format(label))

        return jsonify({
            "version": "2.0.0",
            "python": sys.version,
            "platform": "{} {}".format(platform.system(), platform.release()),
            "dbSizeBytes": db_size,
            "dbSizeMB": round(db_size / 1024 / 1024, 3),
            "installedPackages": installed,
            "stats": stats,
        })
    finally:
        db.close()


# ─── Global Search ────────────────────────────────────────────────────────────

@misc_bp.route("/api/search", methods=["GET"])
def global_search():
    db = SessionLocal()
    try:
        q = request.args.get("q", "").strip()
        limit = min(int(request.args.get("limit", 10)), 50)
        if not q or len(q) < 2:
            return jsonify({"products": [], "query": q, "total": 0})
        products = db.query(Product).filter(
            Product.status == "published",
            or_(
                Product.name.ilike("%{}%".format(q)),
                Product.description.ilike("%{}%".format(q)),
                Product.category.ilike("%{}%".format(q)),
                Product.keywords.ilike("%{}%".format(q)),
            )
        ).order_by(desc(Product.sales)).limit(limit).all()
        return jsonify({
            "query": q,
            "total": len(products),
            "products": [{
                "id": p.id, "name": p.name, "slug": p.slug,
                "category": p.category, "price": float(p.price),
                "thumbnailUrl": p.thumbnail_url,
                "rating": float(p.rating or 0),
            } for p in products],
        })
    finally:
        db.close()


@misc_bp.route("/api/admin/search", methods=["GET"])
@require_admin
def admin_global_search():
    db = SessionLocal()
    try:
        q = request.args.get("q", "").strip()
        if not q or len(q) < 2:
            return jsonify({"results": {}, "query": q})

        products = db.query(Product).filter(
            or_(Product.name.ilike("%{}%".format(q)), Product.slug.ilike("%{}%".format(q)))
        ).limit(5).all()

        users = db.query(User).filter(
            or_(User.name.ilike("%{}%".format(q)), User.email.ilike("%{}%".format(q)))
        ).limit(5).all()

        if q.isdigit():
            orders = db.query(Order).filter(Order.id == int(q)).limit(5).all()
        else:
            orders = db.query(Order).filter(Order.status == q).limit(5).all()

        tickets = db.query(Ticket).filter(
            or_(Ticket.subject.ilike("%{}%".format(q)), Ticket.message.ilike("%{}%".format(q)))
        ).limit(5).all()

        return jsonify({
            "query": q,
            "results": {
                "products": [{"id": p.id, "name": p.name, "status": p.status} for p in products],
                "users": [{"id": u.id, "name": u.name, "email": u.email, "role": u.role} for u in users],
                "orders": [{"id": o.id, "status": o.status, "total": float(o.total)} for o in orders],
                "tickets": [{"id": t.id, "subject": t.subject, "status": t.status} for t in tickets],
            },
        })
    finally:
        db.close()


# ─── Notifications ────────────────────────────────────────────────────────────

@misc_bp.route("/api/notifications", methods=["GET"])
@require_auth
def get_notifications():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 20)), 50)
        notifs = db.query(Notification).filter(
            or_(Notification.user_id == g.user.id, Notification.user_id == None)
        ).order_by(desc(Notification.created_at)).limit(limit).all()
        unread_count = db.query(Notification).filter(
            or_(Notification.user_id == g.user.id, Notification.user_id == None),
            Notification.is_read == False,
        ).count()
        return jsonify({
            "notifications": [{
                "id": n.id, "title": n.title, "message": n.message,
                "type": n.type, "icon": n.icon, "link": n.link,
                "isRead": n.is_read,
                "createdAt": n.created_at.isoformat() if n.created_at else None,
            } for n in notifs],
            "unreadCount": unread_count,
        })
    finally:
        db.close()


@misc_bp.route("/api/notifications/mark-read", methods=["POST"])
@require_auth
def mark_notifications_read():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        notif_ids = data.get("ids")
        q = db.query(Notification).filter(
            or_(Notification.user_id == g.user.id, Notification.user_id == None)
        )
        if notif_ids:
            q = q.filter(Notification.id.in_(notif_ids))
        q.update({"is_read": True}, synchronize_session="fetch")
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


@misc_bp.route("/api/admin/notifications", methods=["POST"])
@require_admin
def admin_create_notification():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        notif = Notification(
            user_id=data.get("userId"),
            title=data.get("title", "Notification"),
            message=data.get("message", ""),
            type=data.get("type", "info"),
            icon=data.get("icon", "bell"),
            link=data.get("link"),
        )
        db.add(notif)
        db.commit()
        return jsonify({"id": notif.id, "title": notif.title}), 201
    finally:
        db.close()


@misc_bp.route("/api/admin/notifications/mark-all-read", methods=["POST"])
@require_admin
def admin_mark_all_notifications_read():
    db = SessionLocal()
    try:
        db.query(Notification).update({"is_read": True}, synchronize_session="fetch")
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


@misc_bp.route("/api/admin/notifications/<int:notif_id>", methods=["DELETE"])
@require_admin
def admin_delete_notification(notif_id):
    db = SessionLocal()
    try:
        n = db.query(Notification).filter(Notification.id == notif_id).first()
        if n:
            db.delete(n)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Contact Form ─────────────────────────────────────────────────────────────

@misc_bp.route("/api/contact", methods=["POST"])
def submit_contact():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        name = data.get("name", "").strip()
        email = data.get("email", "").strip()
        message = data.get("message", "").strip()
        if not name or not email or not message:
            return jsonify({"error": "Name, email, and message are required"}), 400
        if not re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email):
            return jsonify({"error": "Invalid email address"}), 400
        msg = ContactMessage(
            name=name,
            email=email,
            subject=data.get("subject", "Website Inquiry"),
            message=message,
        )
        db.add(msg)
        db.add(Notification(
            user_id=None,
            title="New Contact Message",
            message="From {}: {}".format(name, message[:80]),
            type="info",
            icon="mail",
            link="/admin/messages",
        ))
        db.commit()
        return jsonify({"success": True, "message": "Your message has been sent. We'll get back to you soon!"})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@misc_bp.route("/api/admin/messages", methods=["GET"])
@require_admin
def admin_get_messages():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 20)), 100)
        offset = int(request.args.get("offset", 0))
        msgs = db.query(ContactMessage).order_by(desc(ContactMessage.created_at)).offset(offset).limit(limit).all()
        total = db.query(ContactMessage).count()
        unread = db.query(ContactMessage).filter(ContactMessage.is_read == False).count()
        return jsonify({
            "messages": [{
                "id": m.id, "name": m.name, "email": m.email, "subject": m.subject,
                "message": m.message, "isRead": m.is_read, "adminReply": m.admin_reply,
                "createdAt": m.created_at.isoformat() if m.created_at else None,
            } for m in msgs],
            "total": total,
            "unread": unread,
        })
    finally:
        db.close()


@misc_bp.route("/api/admin/messages/<int:msg_id>", methods=["PUT"])
@require_admin
def admin_update_message(msg_id):
    db = SessionLocal()
    try:
        msg = db.query(ContactMessage).filter(ContactMessage.id == msg_id).first()
        if not msg:
            return jsonify({"error": "Not found"}), 404
        data = request.get_json() or {}
        if "isRead" in data:
            msg.is_read = bool(data["isRead"])
        if "adminReply" in data:
            msg.admin_reply = data["adminReply"]
            msg.is_read = True
        db.commit()
        return jsonify({"id": msg.id, "isRead": msg.is_read})
    finally:
        db.close()


@misc_bp.route("/api/admin/messages/<int:msg_id>", methods=["DELETE"])
@require_admin
def admin_delete_message(msg_id):
    db = SessionLocal()
    try:
        msg = db.query(ContactMessage).filter(ContactMessage.id == msg_id).first()
        if msg:
            db.delete(msg)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Newsletter ───────────────────────────────────────────────────────────────

@misc_bp.route("/api/newsletter/subscribe", methods=["POST"])
def newsletter_subscribe():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        email = data.get("email", "").strip().lower()
        name = data.get("name", "").strip()
        if not email or not re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email):
            return jsonify({"error": "Valid email is required"}), 400
        existing = db.query(NewsletterSubscriber).filter(NewsletterSubscriber.email == email).first()
        if existing:
            if not existing.is_active:
                existing.is_active = True
                existing.unsubscribed_at = None
                if name:
                    existing.name = name
                db.commit()
                return jsonify({"success": True, "message": "Welcome back! You've been re-subscribed."})
            return jsonify({"success": True, "message": "You're already subscribed!"})
        sub = NewsletterSubscriber(email=email, name=name, is_active=True)
        db.add(sub)
        db.commit()
        return jsonify({"success": True, "message": "Successfully subscribed to our newsletter!"})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@misc_bp.route("/api/newsletter/unsubscribe", methods=["POST"])
def newsletter_unsubscribe():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        email = data.get("email", "").strip().lower()
        if not email:
            return jsonify({"error": "Email is required"}), 400
        sub = db.query(NewsletterSubscriber).filter(NewsletterSubscriber.email == email).first()
        if sub:
            sub.is_active = False
            sub.unsubscribed_at = datetime.now(timezone.utc)
            db.commit()
        return jsonify({"success": True, "message": "You've been unsubscribed."})
    finally:
        db.close()


@misc_bp.route("/api/admin/newsletter/subscribers", methods=["GET"])
@require_admin
def admin_get_subscribers():
    db = SessionLocal()
    try:
        subs = db.query(NewsletterSubscriber).order_by(desc(NewsletterSubscriber.subscribed_at)).all()
        active = sum(1 for s in subs if s.is_active)
        return jsonify({
            "subscribers": [{
                "id": s.id, "email": s.email, "name": s.name, "isActive": s.is_active,
                "subscribedAt": s.subscribed_at.isoformat() if s.subscribed_at else None,
            } for s in subs],
            "total": len(subs),
            "active": active,
        })
    finally:
        db.close()


@misc_bp.route("/api/admin/newsletter/subscribers/<int:sub_id>", methods=["DELETE"])
@require_admin
def admin_delete_subscriber(sub_id):
    db = SessionLocal()
    try:
        sub = db.query(NewsletterSubscriber).filter(NewsletterSubscriber.id == sub_id).first()
        if sub:
            db.delete(sub)
            db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Product Download ─────────────────────────────────────────────────────────

@misc_bp.route("/api/products/<int:product_id>/download", methods=["GET"])
@require_auth
def download_product(product_id):
    """Download product file — requires active license."""
    db = SessionLocal()
    try:
        product = db.query(Product).filter(Product.id == product_id).first()
        if not product:
            return jsonify({"error": "Product not found"}), 404

        license_obj = db.query(License).filter(
            License.user_id == g.user.id,
            License.product_id == product_id,
            License.status == "active",
        ).first()

        if not license_obj and g.user.role != "admin":
            return jsonify({
                "error": "You don't have a license for this product.",
                "hint": "Purchase the product first to get a download license.",
            }), 403

        if not product.file_key:
            return jsonify({
                "error": "No file uploaded for this product yet.",
                "productName": product.name,
                "licenseKey": license_obj.license_key if license_obj else "ADMIN",
                "note": "Contact admin or wait for the file to be uploaded.",
            }), 404

        uploads_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")
        file_path = os.path.join(uploads_dir, product.file_key)

        if not os.path.exists(file_path):
            return jsonify({"error": "File not found on server. Please contact support."}), 404

        product.downloads = (product.downloads or 0) + 1
        db.commit()

        return send_file(
            file_path,
            as_attachment=True,
            download_name=product.file_name or product.file_key,
        )
    finally:
        db.close()


# ─── Product Image Upload ─────────────────────────────────────────────────────

@misc_bp.route("/api/admin/products/<int:product_id>/upload-image", methods=["POST"])
@require_admin
def admin_upload_product_image(product_id):
    """Upload a thumbnail image for a product."""
    db = SessionLocal()
    try:
        p = db.query(Product).filter(Product.id == product_id).first()
        if not p:
            return jsonify({"error": "Product not found"}), 404

        if "file" not in request.files:
            return jsonify({"error": "No file provided"}), 400

        file = request.files["file"]
        if not file.filename:
            return jsonify({"error": "Empty filename"}), 400

        # Only allow image types
        allowed = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"}
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in allowed:
            return jsonify({"error": "Only image files are allowed (jpg, png, gif, webp, svg)"}), 400

        uploads_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads", "images")
        os.makedirs(uploads_dir, exist_ok=True)

        import uuid as _uuid
        stored_name = "product_{}_thumb_{}{}".format(product_id, _uuid.uuid4().hex[:8], ext)
        file_path = os.path.join(uploads_dir, stored_name)
        file.save(file_path)

        image_url = "/uploads/images/{}".format(stored_name)
        p.thumbnail_url = image_url
        db.commit()

        return jsonify({
            "success": True,
            "url": image_url,
            "fileName": stored_name,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Static File Serving for Uploads ─────────────────────────────────────────

@misc_bp.route("/uploads/images/<filename>", methods=["GET"])
def serve_upload_image(filename):
    """Serve uploaded product images."""
    from flask import send_from_directory
    safe_filename = re.sub(r"[^\w\.\-]", "_", filename)
    uploads_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads", "images")
    return send_from_directory(uploads_dir, safe_filename)


# ─── Bulk Product Operations ──────────────────────────────────────────────────

@misc_bp.route("/api/admin/products/bulk", methods=["POST"])
@require_admin
def bulk_product_operation():
    """Bulk: publish, draft, delete, archive."""
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        action = data.get("action", "")
        product_ids = data.get("ids", [])
        if not product_ids:
            return jsonify({"error": "No product IDs provided"}), 400
        if action not in ("publish", "draft", "delete", "archive"):
            return jsonify({"error": "Invalid action. Use: publish, draft, delete, archive"}), 400

        products = db.query(Product).filter(Product.id.in_(product_ids)).all()
        affected = 0
        for p in products:
            if action == "delete":
                db.delete(p)
            elif action == "publish":
                p.status = "published"
            elif action == "draft":
                p.status = "draft"
            elif action == "archive":
                p.status = "archived"
            affected += 1
        db.commit()
        return jsonify({"success": True, "action": action, "affected": affected})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Activity Log ─────────────────────────────────────────────────────────────

@misc_bp.route("/api/admin/activity-log", methods=["GET"])
@require_admin
def admin_activity_log():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 50)), 200)
        logs = db.query(ActivityLog).order_by(desc(ActivityLog.created_at)).limit(limit).all()
        return jsonify([{
            "id": l.id, "userId": l.user_id, "action": l.action,
            "entity": l.entity, "entityId": l.entity_id, "detail": l.detail,
            "ipAddress": l.ip_address,
            "createdAt": l.created_at.isoformat() if l.created_at else None,
        } for l in logs])
    finally:
        db.close()


# ─── Social Media Settings ────────────────────────────────────────────────────

SOCIAL_PAIRS = [
    ("social_facebook",  "socialFacebook"),
    ("social_twitter",   "socialTwitter"),
    ("social_instagram", "socialInstagram"),
    ("social_youtube",   "socialYoutube"),
    ("social_linkedin",  "socialLinkedin"),
    ("social_tiktok",    "socialTiktok"),
    ("social_github",    "socialGithub"),
    ("social_discord",   "socialDiscord"),
    ("social_telegram",  "socialTelegram"),
]


@misc_bp.route("/api/settings/social", methods=["GET"])
def get_social_settings():
    db = SessionLocal()
    try:
        result = {}
        for snake_key, camel_key in SOCIAL_PAIRS:
            result[camel_key] = _get_setting(db, snake_key, "")
        return jsonify(result)
    finally:
        db.close()


@misc_bp.route("/api/admin/settings/social", methods=["PUT", "POST"])
@require_admin
def update_social_settings():
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        for snake_key, camel_key in SOCIAL_PAIRS:
            # Accept both camelCase (socialFacebook) and snake_case (social_facebook)
            val = data.get(camel_key) if camel_key in data else data.get(snake_key, "")
            _set_setting(db, snake_key, val or "")
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()


# ─── Static Pages ─────────────────────────────────────────────────────────────

PAGE_DEFAULTS = {
    "about": "## About Us\n\nWe provide premium digital assets for modern developers and businesses.",
    "faq": "## Frequently Asked Questions\n\n**Q: How do I download my purchase?**\nA: Go to Dashboard > Licenses to find your download link.\n\n**Q: Can I get a refund?**\nA: Yes, within 7 days if the file has issues.",
    "terms": "## Terms of Service\n\nBy purchasing, you agree to our license terms. All sales are final unless the file is defective.",
    "privacy": "## Privacy Policy\n\nWe collect only the minimum data needed to process your order. We never sell your data.",
    "refund": "## Refund Policy\n\n7-day money-back guarantee if the product doesn't work as described.",
}


@misc_bp.route("/api/pages/<page_slug>", methods=["GET"])
def get_page(page_slug):
    db = SessionLocal()
    try:
        if page_slug not in PAGE_DEFAULTS:
            return jsonify({"error": "Page not found"}), 404
        content = _get_setting(db, "page_{}".format(page_slug), "")
        return jsonify({"slug": page_slug, "content": content or PAGE_DEFAULTS[page_slug]})
    finally:
        db.close()


@misc_bp.route("/api/admin/pages/<page_slug>", methods=["PUT", "POST"])
@require_admin
def update_page(page_slug):
    db = SessionLocal()
    try:
        if page_slug not in PAGE_DEFAULTS:
            return jsonify({"error": "Page not found"}), 404
        data = request.get_json() or {}
        _set_setting(db, "page_{}".format(page_slug), data.get("content", ""))
        db.commit()
        return jsonify({"success": True, "slug": page_slug})
    finally:
        db.close()


# ─── Chatbot ──────────────────────────────────────────────────────────────────

# ─── Chatbot AI helpers ───────────────────────────────────────────────────────

def _chatbot_ai_call(provider, api_key, model, system_ctx, user_msg):
    """Call external AI provider. Returns (reply_text, error_or_None)."""
    import urllib.request as _req
    import json as _json
    try:
        if provider == "gemini":
            model = model or "gemini-1.5-flash"
            url = "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}".format(model, api_key)
            payload = {
                "contents": [{"parts": [{"text": system_ctx + "\n\nUser: " + user_msg}]}],
                "generationConfig": {"maxOutputTokens": 600, "temperature": 0.7}
            }
            r = _req.Request(url, data=_json.dumps(payload).encode(), headers={"Content-Type": "application/json"}, method="POST")
            with _req.urlopen(r, timeout=10) as resp:
                d = _json.loads(resp.read())
                return d["candidates"][0]["content"]["parts"][0]["text"], None
        elif provider == "openai":
            model = model or "gpt-4o-mini"
            url = "https://api.openai.com/v1/chat/completions"
            payload = {
                "model": model,
                "messages": [{"role": "system", "content": system_ctx}, {"role": "user", "content": user_msg}],
                "max_tokens": 600, "temperature": 0.7,
            }
            r = _req.Request(url, data=_json.dumps(payload).encode(),
                headers={"Content-Type": "application/json", "Authorization": "Bearer " + api_key}, method="POST")
            with _req.urlopen(r, timeout=10) as resp:
                d = _json.loads(resp.read())
                return d["choices"][0]["message"]["content"], None
    except Exception as ex:
        return None, str(ex)
    return None, "Unknown provider"


@misc_bp.route("/api/chatbot/status", methods=["GET"])
def chatbot_status():
    """Public endpoint: is the chatbot enabled?"""
    db = SessionLocal()
    try:
        enabled = _get_setting(db, "chatbot_enabled", "true") == "true"
        greeting = _get_setting(db, "chatbot_greeting", "\U0001f44b Hi! How can I help you today?")
        color = _get_setting(db, "chatbot_color", "#3b82f6")
        site_name = _get_setting(db, "site_name", "Web Designs & Care")
        ai_provider = _get_setting(db, "chatbot_ai_provider", "local")
        return jsonify({
            "enabled": enabled, "greeting": greeting, "color": color,
            "siteName": site_name, "aiProvider": ai_provider,
        })
    finally:
        db.close()


@misc_bp.route("/api/chatbot", methods=["POST"])
def chatbot_reply():
    """
    Smart chatbot: AI provider (Gemini/OpenAI) OR keyword matching fallback.
    Works fully offline. Includes site error analysis capability.
    """
    db = SessionLocal()
    try:
        enabled = _get_setting(db, "chatbot_enabled", "true") == "true"
        if not enabled:
            return jsonify({"error": "Chatbot is disabled"}), 403

        data = request.get_json() or {}
        message = (data.get("message") or "").strip()
        errors_ctx = data.get("errors", [])   # JS errors from frontend
        msg_lower = message.lower()

        # ── AI provider check ────────────────────────────────────────────────
        ai_provider = _get_setting(db, "chatbot_ai_provider", "local")
        api_key     = _get_setting(db, "chatbot_api_key", "")
        ai_model    = _get_setting(db, "chatbot_ai_model", "gemini-1.5-flash")
        site_name   = _get_setting(db, "site_name", "Web Designs & Care")

        if not msg_lower:
            return jsonify({"reply": "\U0001f44b Hi! Ask me about templates, themes, plugins, prices, or discounts!", "products": []})

        products_out = []
        reply = ""

        # ── Build site context for AI providers ──────────────────────────────
        product_names = [p.name for p in db.query(Product).filter(Product.status == "published").limit(8).all()]
        site_system_ctx = (
            "You are a smart customer support chatbot for {}, a digital marketplace selling "
            "website templates, themes, plugins, UI kits, and bundles.\n"
            "Available products (sample): {}\n"
            "Key facts: 7-day money-back guarantee, lifetime access, license key per product, "
            "coupon SAVE10 (10% off), WELCOME (15% off first order), downloads at My Downloads page.\n"
            "Be helpful, concise, friendly. If user reports errors, analyze and suggest solutions."
        ).format(site_name, ", ".join(product_names) or "various products")

        # ── Error context from frontend ───────────────────────────────────────
        err_context = ""
        if errors_ctx and isinstance(errors_ctx, list):
            err_lines = []
            for e in errors_ctx[-5:]:
                err_lines.append("- {}: {} (line {})".format(e.get("type", "JS Error"), e.get("message", ""), e.get("line", "?")))
            if err_lines:
                err_context = "\n\n[Recent browser errors detected:]\n" + "\n".join(err_lines)

        # ── Error analysis (keyword: error/bug/problem) ────────────────────
        is_error_query = any(w in msg_lower for w in ["error", "bug", "problem", "not working", "broken", "fix", "issue", "crash", "fail", "white screen", "blank"])

        if is_error_query and err_context:
            # Augment user message with actual error context
            augmented_msg = message + err_context
        else:
            augmented_msg = message

        # ── Try AI provider first ─────────────────────────────────────────
        if ai_provider in ("gemini", "openai") and api_key:
            ai_reply, ai_err = _chatbot_ai_call(ai_provider, api_key, ai_model, site_system_ctx, augmented_msg)
            if ai_reply:
                return jsonify({"reply": ai_reply, "products": [], "aiProvider": ai_provider})
            # If AI fails, fall through to keyword matching
            reply = ""

        # ── Local error analysis (no AI needed) ───────────────────────────
        if is_error_query:
            if "white screen" in msg_lower or "blank" in msg_lower:
                reply = ("\U0001f6a8 **White/blank screen** issues are usually caused by:\n"
                         "1. **Flask server not running** — run `python app.py`\n"
                         "2. **JavaScript error** — press F12 → Console tab to see errors\n"
                         "3. **Port mismatch** — check server is on port 5000\n"
                         "4. **Browser cache** — try Ctrl+Shift+R (hard refresh)\n\n"
                         "Open the browser Console (F12) and share the error message for specific help!")
            elif err_context:
                reply = ("\U0001f50d I detected **browser errors** on your site:\n"
                         + err_context.replace("[Recent browser errors detected:]\n", "") +
                         "\n\n**Common fixes:**\n"
                         "• Check the browser Console (F12) for full error details\n"
                         "• Ensure all scripts are loading correctly\n"
                         "• Try a hard refresh: Ctrl+Shift+R\n"
                         "• Check your internet connection\n"
                         "• Contact support with the exact error message")
            elif "login" in msg_lower or "auth" in msg_lower or "password" in msg_lower:
                reply = ("\U0001f512 **Login issues?** Try:\n"
                         "1. Default admin: admin@webdesignscare.com / admin123\n"
                         "2. Clear browser cookies and try again\n"
                         "3. Check if Flask server is running (`python app.py`)\n"
                         "4. Submit a support ticket if problem persists")
            elif "upload" in msg_lower:
                reply = ("\U0001f4c2 **Upload issues?** Check:\n"
                         "1. File size — maximum 50MB per upload\n"
                         "2. The `static/uploads/` folder exists on the server\n"
                         "3. Server disk space is not full\n"
                         "4. Try a different browser or incognito mode")
            elif "payment" in msg_lower or "stripe" in msg_lower or "checkout" in msg_lower:
                reply = ("\U0001f4b3 **Payment issues?** Try:\n"
                         "1. Check Stripe keys in Admin → Settings → Payments\n"
                         "2. Use demo mode for testing (Settings → Demo Mode ON)\n"
                         "3. Ensure HTTPS is enabled for live payments\n"
                         "4. Check Stripe dashboard for declined charge details")
            elif "database" in msg_lower or "db" in msg_lower or "sql" in msg_lower:
                reply = ("\U0001f4ca **Database issues?** Try:\n"
                         "1. Delete `wdc.sqlite` and restart — fresh DB will be created\n"
                         "2. Run `python app.py` — it auto-creates all tables\n"
                         "3. Check disk space and file permissions\n"
                         "4. For MySQL: check connection string in `config.py`")
            else:
                reply = ("\U0001f6a8 I detected a **site issue**. Here's how to debug:\n"
                         "1. Press **F12** → Console tab to see JavaScript errors\n"
                         "2. Press **F12** → Network tab to see failed API calls\n"
                         "3. Check Flask server terminal for Python error messages\n"
                         "4. Try hard refresh: **Ctrl+Shift+R**\n\n"
                         "Copy the exact error message and submit a **Support Ticket** for help!")

        def get_products(category=None, order_by=None, limit=3):
            q = db.query(Product).filter(Product.status == "published")
            if category:
                q = q.filter(Product.category == category)
            if order_by == "price_asc":
                q = q.order_by(Product.price.asc())
            elif order_by == "rating":
                q = q.order_by(desc(Product.rating))
            else:
                q = q.order_by(desc(Product.sales))
            return [{
                "id": p.id, "name": p.name, "price": float(p.price),
                "slug": p.slug, "thumbnailUrl": p.thumbnail_url,
                "category": p.category, "rating": float(p.rating or 0),
            } for p in q.limit(limit).all()]

        def has(*words):
            return any(w in msg_lower for w in words)

        # Greeting
        if has("hello", "hi", "hey", "start", "begin", "good morning", "good evening"):
            reply = "\U0001f44b Hello! Welcome to our store! I can help you find the perfect template, theme, or plugin. What are you looking for today?"

        # Gratitude / farewell
        elif has("thank", "thanks", "bye", "goodbye", "see you"):
            reply = "\U0001f60a You're welcome! Happy building! Don't forget: use coupon **SAVE10** for 10% off! \U0001f381"

        # Category: templates
        elif has("template", "templates", "html template", "react template", "website template"):
            products_out = get_products("templates")
            reply = "\U0001f3a8 Great choice! Here are our top website templates:"

        # Category: themes
        elif has("theme", "themes", "wordpress theme", "shopify theme"):
            products_out = get_products("themes")
            reply = "\U0001f5bc\ufe0f Stunning themes for your next project:"

        # Category: plugins
        elif has("plugin", "plugins", "addon", "extension", "widget"):
            products_out = get_products("plugins")
            reply = "\U0001f50c Our most popular plugins:"

        # Category: bundles
        elif has("bundle", "bundles", "pack", "package", "full site", "complete"):
            products_out = get_products("bundles")
            reply = "\U0001f4e6 Save more with our value bundles:"

        # Category: ui kits
        elif has("ui kit", "ui-kit", "component", "dashboard", "design system"):
            products_out = get_products("ui-kits")
            reply = "\U0001f9e9 Beautiful UI kits for your project:"

        # Price / cheap
        elif has("price", "cost", "how much", "cheap", "budget", "affordable", "expensive"):
            products_out = get_products(order_by="price_asc")
            reply = "\U0001f4b0 Our products start from just $14! Here are the most affordable options:"

        # Discount / coupon
        elif has("discount", "coupon", "promo", "offer", "sale", "code", "voucher"):
            coupons = db.query(Coupon).filter(Coupon.is_active == True).limit(5).all()
            if coupons:
                code_list = "\n".join([
                    "• **{}** — {} {}{}".format(
                        c.code,
                        c.description or "",
                        ("" if c.type == "percentage" else "$"),
                        ("{}%".format(int(c.value)) if c.type == "percentage" else "{:.0f}".format(c.value)),
                    ) for c in coupons
                ])
                reply = "\U0001f3ab Here are your active coupon codes! Copy and use at checkout:\n\n" + code_list
            else:
                reply = "\u23f0 No active coupons right now, but check back soon! Subscribe to our newsletter to get exclusive deals."

        # Download / access
        elif has("download", "how to download", "where is", "access", "my file"):
            reply = ("\U0001f4e5 To download your purchase:\n"
                     "1. Go to **My Downloads** page\n"
                     "2. Find your order and click **Download**\n"
                     "3. Your license key is in the **My Licenses** tab\n\n"
                     "Need help? Submit a support ticket!")

        # License
        elif has("license", "key", "activate", "serial"):
            reply = ("\U0001f511 Each product comes with a **unique license key**!\n"
                     "• Find it in **My Downloads → My Licenses** tab\n"
                     "• One license = one project (personal or commercial)\n"
                     "• Lifetime access included")

        # Support / contact
        elif has("support", "help", "contact", "problem", "issue", "bug", "error", "not working"):
            reply = ("\U0001f91d We're here to help! You can:\n"
                     "1. Submit a **Support Ticket** from your account\n"
                     "2. Use the **Contact Form** on our homepage\n"
                     "3. Email: support@webdesignscare.com\n\n"
                     "We respond within 24 hours!")

        # Best sellers / popular
        elif has("best", "popular", "top", "trending", "recommend", "bestseller"):
            products_out = get_products(order_by=None)
            reply = "\U0001f3c6 Our bestsellers right now:"

        # Highest rated
        elif has("rated", "rating", "review", "quality"):
            products_out = get_products(order_by="rating")
            reply = "\u2b50 Highest-rated products:"

        # Refund
        elif has("refund", "money back", "return", "cancel"):
            reply = ("\U0001f4b3 **Refund Policy:**\n"
                     "We offer a **7-day money-back guarantee** if the product doesn't work as described.\n"
                     "Contact support to start the process — it's quick and hassle-free!")

        # About
        elif has("about", "who are you", "what is this", "what do you sell"):
            reply = ("\U0001f3ea **Web Designs & Care** is your one-stop shop for premium digital assets!\n"
                     "We sell:\n"
                     "• \U0001f3a8 Website Templates\n"
                     "• \U0001f5bc\ufe0f Themes\n"
                     "• \U0001f50c Plugins\n"
                     "• \U0001f4e6 Full-site Bundles\n\n"
                     "All products come with lifetime access and a license key. What can I help you find?")

        # Free
        elif has("free", "freebie", "no cost", "gratis"):
            reply = ("\U0001f381 We don't have free products, but we have great value!\n"
                     "• Use code **SAVE10** for 10% off any order\n"
                     "• Use **WELCOME** for 15% off your first purchase\n"
                     "• Check out our bundles for the best value!")

        # Default: show bestsellers
        else:
            products_out = get_products()
            reply = ("\U0001f6cd\ufe0f I can help you find templates, themes, plugins, bundles, or answer questions about pricing, downloads, and licenses.\n\n"
                     "Here are some of our top picks for you:")

        return jsonify({"reply": reply, "products": products_out})

    except Exception as e:
        return jsonify({"reply": "Oops! Something went wrong on my end. Please try again.", "products": [], "error": str(e)}), 200
    finally:
        db.close()


# ─── Chatbot Lead Capture ─────────────────────────────────────────────────────

@misc_bp.route("/api/chatbot/lead", methods=["POST"])
def chatbot_capture_lead():
    """Save a lead (name + email) collected by the chatbot widget."""
    import hashlib
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        name = (data.get("name") or "").strip()
        email = (data.get("email") or "").strip()
        phone = (data.get("phone") or "").strip()
        source = (data.get("source") or "chatbot").strip()
        message = (data.get("message") or "").strip()

        if not email or "@" not in email:
            return jsonify({"error": "Valid email required"}), 400

        ip = request.remote_addr or ""
        ip_hash = hashlib.sha256(ip.encode()).hexdigest()[:16] if ip else ""

        # Save dedicated chatbot lead record
        lead = ChatbotLead(
            name=name or None,
            email=email,
            phone=phone or None,
            source=source,
            message=message or None,
            ip_hash=ip_hash,
        )
        db.add(lead)

        # Also save as newsletter subscriber (opt-in)
        try:
            existing = db.query(NewsletterSubscriber).filter(
                NewsletterSubscriber.email == email
            ).first()
            if not existing:
                db.add(NewsletterSubscriber(
                    email=email,
                    name=name or email.split("@")[0],
                    is_active=True,
                ))
        except Exception:
            pass

        # Also save as contact message for inbox visibility
        try:
            db.add(ContactMessage(
                name=name or "Chatbot Lead",
                email=email,
                subject="Chatbot Lead — {}".format(source),
                message="Lead captured via chatbot.\nName: {}\nEmail: {}\nPhone: {}".format(
                    name or "—", email, phone or "—"
                ),
            ))
        except Exception:
            pass

        db.commit()
        return jsonify({"success": True, "message": "Lead saved!"})
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@misc_bp.route("/api/track/pageview", methods=["POST"])
def track_pageview():
    """Lightweight visitor page-view tracking (no auth required)."""
    import hashlib
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        page = (data.get("page") or "/")[:500]
        referrer = (data.get("referrer") or "")[:500]
        ip = request.remote_addr or ""
        ip_hash = hashlib.sha256(ip.encode()).hexdigest()[:16] if ip else ""
        db.add(PageView(page=page, referrer=referrer or None, ip_hash=ip_hash))
        db.commit()
        return jsonify({"ok": True})
    except Exception:
        db.rollback()
        return jsonify({"ok": True})  # always succeed silently
    finally:
        db.close()
