"""
Wallet Routes
=============
Customer wallet top-up, balance check, and transaction history.
"""
from flask import Blueprint, request, jsonify, g
from sqlalchemy import desc
from database import SessionLocal, User, WalletTransaction
from auth_helper import require_auth, require_admin
from datetime import datetime, timezone

wallet_bp = Blueprint("wallet", __name__)


def txn_to_dict(t):
    type_labels = {
        "topup": "Wallet Top-up",
        "payment": "Purchase Payment",
        "refund": "Order Refund",
        "admin_add": "Admin Credit",
        "admin_subtract": "Admin Deduction",
    }
    return {
        "id": t.id,
        "type": t.type,
        "label": type_labels.get(t.type, t.type.replace("_", " ").title()),
        "amount": float(t.amount),
        "balanceAfter": float(t.balance_after),
        "description": t.description or "",
        "referenceId": t.reference_id or "",
        "createdAt": t.created_at.isoformat() if t.created_at else None,
        "isCredit": t.type in ("topup", "refund", "admin_add"),
    }


# ─── Customer: Get balance ─────────────────────────────────────────────────────

@wallet_bp.route("/api/wallet/balance", methods=["GET"])
@require_auth
def get_wallet_balance():
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == g.user.id).first()
        return jsonify({
            "balance": float(user.wallet_balance or 0),
            "userId": user.id,
        })
    finally:
        db.close()


# ─── Customer: Transaction history ────────────────────────────────────────────

@wallet_bp.route("/api/wallet/transactions", methods=["GET"])
@require_auth
def get_wallet_transactions():
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 50)), 200)
        offset = int(request.args.get("offset", 0))
        txns = (
            db.query(WalletTransaction)
            .filter(WalletTransaction.user_id == g.user.id)
            .order_by(desc(WalletTransaction.created_at))
            .offset(offset)
            .limit(limit)
            .all()
        )
        total = db.query(WalletTransaction).filter(WalletTransaction.user_id == g.user.id).count()
        total_topped = sum(
            float(t.amount) for t in
            db.query(WalletTransaction).filter(
                WalletTransaction.user_id == g.user.id,
                WalletTransaction.type.in_(["topup", "admin_add"])
            ).all()
        )
        total_spent = sum(
            float(t.amount) for t in
            db.query(WalletTransaction).filter(
                WalletTransaction.user_id == g.user.id,
                WalletTransaction.type == "payment"
            ).all()
        )
        return jsonify({
            "transactions": [txn_to_dict(t) for t in txns],
            "total": total,
            "summary": {
                "totalTopup": round(total_topped, 2),
                "totalSpent": round(total_spent, 2),
            }
        })
    finally:
        db.close()


# ─── Customer: Top-up wallet ──────────────────────────────────────────────────

@wallet_bp.route("/api/wallet/topup", methods=["POST"])
@require_auth
def topup_wallet():
    """
    Demo top-up (no real payment gateway).
    Accepts amount and adds it to wallet balance.
    In production, connect Stripe here before crediting.
    """
    db = SessionLocal()
    try:
        from database import SiteSetting
        def _get_s(key, default):
            s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
            return float(s.value) if s and s.value else default
        min_topup = _get_s("wallet_min_topup", 1.0)
        max_topup = _get_s("wallet_max_topup", 500.0)

        data = request.get_json() or {}
        amount = float(data.get("amount", 0))
        if amount < min_topup:
            return jsonify({"error": "Minimum top-up amount is ${:.2f}".format(min_topup)}), 400
        if amount > max_topup:
            return jsonify({"error": "Maximum single top-up is ${:.2f}".format(max_topup)}), 400

        user = db.query(User).filter(User.id == g.user.id).first()
        old_balance = float(user.wallet_balance or 0)
        new_balance = round(old_balance + amount, 2)
        user.wallet_balance = new_balance

        txn = WalletTransaction(
            user_id=user.id,
            type="topup",
            amount=amount,
            balance_after=new_balance,
            description="Wallet top-up via demo payment",
            reference_id="TOPUP-{}".format(int(datetime.now(timezone.utc).timestamp())),
        )
        db.add(txn)
        db.commit()
        db.refresh(txn)

        return jsonify({
            "success": True,
            "amount": amount,
            "previousBalance": old_balance,
            "newBalance": new_balance,
            "transaction": txn_to_dict(txn),
            "message": "Wallet topped up by ${:.2f}. New balance: ${:.2f}".format(amount, new_balance),
        })
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid amount"}), 400
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Admin: Get any user's wallet transactions ─────────────────────────────────

@wallet_bp.route("/api/admin/users/<int:user_id>/wallet/transactions", methods=["GET"])
@require_admin
def admin_get_user_wallet_transactions(user_id):
    db = SessionLocal()
    try:
        txns = (
            db.query(WalletTransaction)
            .filter(WalletTransaction.user_id == user_id)
            .order_by(desc(WalletTransaction.created_at))
            .limit(100)
            .all()
        )
        return jsonify([txn_to_dict(t) for t in txns])
    finally:
        db.close()


# ─── Admin: Top up or subtract from any user's wallet (with transaction record) ─

@wallet_bp.route("/api/admin/wallet/adjust", methods=["POST"])
@require_admin
def admin_adjust_wallet():
    """Admin adjusts a user's wallet balance and records transaction."""
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        user_id = data.get("userId")
        amount = float(data.get("amount", 0))
        action = data.get("action", "add")
        description = data.get("description", "")

        if not user_id:
            return jsonify({"error": "userId required"}), 400
        if amount <= 0:
            return jsonify({"error": "Amount must be positive"}), 400

        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return jsonify({"error": "User not found"}), 404

        old_balance = float(user.wallet_balance or 0)
        if action == "subtract":
            new_balance = max(0, old_balance - amount)
            txn_type = "admin_subtract"
            actual_amount = old_balance - new_balance
            txn_desc = description or "Admin deduction"
        else:
            new_balance = round(old_balance + amount, 2)
            txn_type = "admin_add"
            actual_amount = amount
            txn_desc = description or "Admin credit"

        user.wallet_balance = new_balance

        txn = WalletTransaction(
            user_id=user_id,
            type=txn_type,
            amount=actual_amount,
            balance_after=new_balance,
            description=txn_desc,
            reference_id="ADMIN-{}".format(g.user.id),
        )
        db.add(txn)
        db.commit()

        return jsonify({
            "success": True,
            "userId": user_id,
            "userName": user.name,
            "action": action,
            "amount": actual_amount,
            "previousBalance": old_balance,
            "newBalance": new_balance,
        })
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid amount"}), 400
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ─── Admin: All wallet transactions (cross-user) ───────────────────────────────

@wallet_bp.route("/api/admin/wallet/transactions", methods=["GET"])
@require_admin
def admin_all_wallet_transactions():
    """All wallet transactions across all users, with optional type filter."""
    db = SessionLocal()
    try:
        limit = min(int(request.args.get("limit", 50)), 200)
        offset = int(request.args.get("offset", 0))
        txn_type = request.args.get("type")
        user_id = request.args.get("userId")
        q = db.query(WalletTransaction)
        if txn_type:
            q = q.filter(WalletTransaction.type == txn_type)
        if user_id:
            q = q.filter(WalletTransaction.user_id == int(user_id))
        total = q.count()
        txns = q.order_by(desc(WalletTransaction.created_at)).offset(offset).limit(limit).all()
        return jsonify({
            "transactions": [txn_to_dict(t) for t in txns],
            "total": total,
        })
    finally:
        db.close()
