"""
Stripe Payment Routes
======================
Disabled by default. Enable via Admin → Settings → stripe_enabled = true
and add your Stripe keys (stripe_publishable_key, stripe_secret_key).

When online and configured, this handles real payments.
When disabled (offline/demo), checkout runs in demo mode.
"""
from flask import Blueprint, request, jsonify, g
from database import SessionLocal, Order, OrderItem, Product, CartItem, SiteSetting, Coupon
from auth_helper import require_auth

stripe_bp = Blueprint("stripe", __name__)


def get_setting(db, key, default=""):
    s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
    return s.value if s else default


def is_stripe_enabled(db):
    return get_setting(db, "stripe_enabled", "false").lower() == "true"


def get_stripe_client(db):
    """Initialize Stripe with secret key from settings. Returns None if disabled."""
    if not is_stripe_enabled(db):
        return None
    secret_key = get_setting(db, "stripe_secret_key", "")
    if not secret_key or not secret_key.startswith("sk_"):
        return None
    try:
        import stripe
        stripe.api_key = secret_key
        return stripe
    except ImportError:
        return None


@stripe_bp.route("/api/stripe/status", methods=["GET"])
def stripe_status():
    """Check if Stripe is enabled and configured."""
    db = SessionLocal()
    try:
        enabled = is_stripe_enabled(db)
        pub_key = get_setting(db, "stripe_publishable_key", "")
        has_secret = bool(get_setting(db, "stripe_secret_key", ""))
        configured = enabled and bool(pub_key) and has_secret
        return jsonify({
            "enabled": enabled,
            "configured": configured,
            "publishableKey": pub_key if enabled else "",
            "mode": "live" if (pub_key.startswith("pk_live_")) else "test",
        })
    finally:
        db.close()


@stripe_bp.route("/api/stripe/create-checkout-session", methods=["POST"])
@require_auth
def create_checkout_session():
    """Create a Stripe checkout session for the user's cart."""
    db = SessionLocal()
    try:
        if not is_stripe_enabled(db):
            return jsonify({"error": "Stripe is not enabled. Enable it in Admin → Settings."}), 400

        stripe = get_stripe_client(db)
        if not stripe:
            return jsonify({"error": "Stripe is not configured. Add your Stripe keys in Admin → Settings."}), 400

        data = request.get_json() or {}
        items = data.get("items", [])
        site_url = get_setting(db, "site_url", "http://localhost:5000")

        if not items:
            cart_items = db.query(CartItem).filter(CartItem.user_id == g.user.id).all()
            items = []
            for ci in cart_items:
                p = db.query(Product).filter(Product.id == ci.product_id).first()
                if p:
                    items.append({"productId": p.id, "name": p.name, "price": float(p.price), "quantity": ci.quantity or 1})

        if not items:
            return jsonify({"error": "No items in cart"}), 400

        line_items = []
        for item in items:
            line_items.append({
                "price_data": {
                    "currency": get_setting(db, "currency", "usd").lower(),
                    "product_data": {"name": item["name"]},
                    "unit_amount": int(float(item["price"]) * 100),
                },
                "quantity": item.get("quantity", 1),
            })

        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=line_items,
            mode="payment",
            success_url=site_url + "/dashboard?payment=success&session_id={CHECKOUT_SESSION_ID}",
            cancel_url=site_url + "/cart?payment=cancelled",
            customer_email=g.user.email,
            metadata={"user_id": str(g.user.id)},
        )

        return jsonify({"sessionId": session.id, "url": session.url})

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@stripe_bp.route("/api/stripe/webhook", methods=["POST"])
def stripe_webhook():
    """Handle Stripe webhook events (payment confirmation, refunds, etc.)"""
    db = SessionLocal()
    try:
        if not is_stripe_enabled(db):
            return jsonify({"error": "Stripe disabled"}), 400

        stripe = get_stripe_client(db)
        if not stripe:
            return jsonify({"error": "Stripe not configured"}), 400

        webhook_secret = get_setting(db, "stripe_webhook_secret", "")
        payload = request.get_data(as_text=True)
        sig_header = request.headers.get("Stripe-Signature", "")

        try:
            if webhook_secret:
                event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
            else:
                import json
                event = json.loads(payload)
        except Exception as e:
            return jsonify({"error": str(e)}), 400

        if event["type"] == "checkout.session.completed":
            session = event["data"]["object"]
            user_id = int(session.get("metadata", {}).get("user_id", 0))
            if user_id:
                import uuid as uuid_mod
                from database import Order, OrderItem, License, CartItem
                from datetime import datetime, timezone
                total = session.get("amount_total", 0) / 100
                order = Order(
                    user_id=user_id,
                    status="completed",
                    total=total,
                    payment_method="stripe",
                    payment_id=session.get("id"),
                )
                db.add(order)
                db.flush()

                cart_items = db.query(CartItem).filter(CartItem.user_id == user_id).all()
                for ci in cart_items:
                    p = db.query(Product).filter(Product.id == ci.product_id).first()
                    if p:
                        item = OrderItem(order_id=order.id, product_id=p.id, price=p.price, quantity=ci.quantity or 1)
                        db.add(item)
                        lic = License(
                            user_id=user_id,
                            product_id=p.id,
                            order_id=order.id,
                            license_key=str(uuid_mod.uuid4()).upper(),
                            license_type="standard",
                        )
                        db.add(lic)
                        p.sales = (p.sales or 0) + 1
                        p.downloads = (p.downloads or 0) + 1

                db.query(CartItem).filter(CartItem.user_id == user_id).delete()
                db.commit()

        return jsonify({"received": True})

    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@stripe_bp.route("/api/admin/stripe/settings", methods=["GET"])
def get_stripe_settings():
    """Get Stripe configuration (admin)."""
    db = SessionLocal()
    try:
        return jsonify({
            "enabled": is_stripe_enabled(db),
            "publishableKey": get_setting(db, "stripe_publishable_key", ""),
            "hasSecretKey": bool(get_setting(db, "stripe_secret_key", "")),
            "webhookSecret": get_setting(db, "stripe_webhook_secret", ""),
            "note": "Add Stripe keys from https://dashboard.stripe.com/apikeys",
        })
    finally:
        db.close()


@stripe_bp.route("/api/admin/stripe/settings", methods=["PUT", "POST"])
def update_stripe_settings():
    """Update Stripe configuration (admin)."""
    db = SessionLocal()
    try:
        data = request.get_json() or {}
        allowed = ["stripe_enabled", "stripe_publishable_key", "stripe_secret_key", "stripe_webhook_secret"]
        for key in allowed:
            if key in data:
                s = db.query(SiteSetting).filter(SiteSetting.key == key).first()
                if s:
                    s.value = str(data[key])
                else:
                    db.add(SiteSetting(key=key, value=str(data[key])))
        db.commit()
        return jsonify({"success": True})
    finally:
        db.close()
