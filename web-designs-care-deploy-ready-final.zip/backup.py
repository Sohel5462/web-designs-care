"""
Web Designs & Care - Backup & Restore Tool
===========================================
Backup your database to a JSON file and restore it later.
Works with both SQLite and MySQL.

Usage:
  python backup.py backup                    # Backup to backup_YYYY-MM-DD.json
  python backup.py backup --output my.json   # Backup to specific file
  python backup.py restore my.json           # Restore from JSON file
  python backup.py list                      # List available backups
"""

import sys
import os
import json
import argparse
from datetime import datetime


def serialize(obj):
    """Convert SQLAlchemy model to dict."""
    if hasattr(obj, "__table__"):
        result = {}
        for col in obj.__table__.columns:
            val = getattr(obj, col.name)
            if isinstance(val, datetime):
                val = val.isoformat()
            elif hasattr(val, "__float__"):
                val = float(val)
            result[col.name] = val
        return result
    return str(obj)


def do_backup(output_file=None):
    from database import SessionLocal, User, Product, Order, OrderItem, CartItem, License, Review, WishlistItem, Ticket, Coupon, AffiliateCode, AffiliateClick, SiteSetting, Webhook, Domain, InstalledApp
    from config import Config

    if not output_file:
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        output_file = "backup_{}.json".format(timestamp)

    print("")
    print("Web Designs & Care - Backup")
    print("=" * 40)
    print("Database: {}".format(Config.DATABASE_URL.split("///")[-1].split("@")[-1]))
    print("Output:   {}".format(output_file))
    print("")

    db = SessionLocal()
    data = {}
    models = [
        ("users", User),
        ("products", Product),
        ("orders", Order),
        ("order_items", OrderItem),
        ("cart_items", CartItem),
        ("licenses", License),
        ("reviews", Review),
        ("wishlist", WishlistItem),
        ("tickets", Ticket),
        ("coupons", Coupon),
        ("affiliate_codes", AffiliateCode),
        ("affiliate_clicks", AffiliateClick),
        ("site_settings", SiteSetting),
        ("webhooks", Webhook),
        ("domains", Domain),
        ("installed_apps", InstalledApp),
    ]

    total = 0
    for name, Model in models:
        try:
            rows = db.query(Model).all()
            data[name] = [serialize(r) for r in rows]
            print("  [OK] {}: {} records".format(name, len(rows)))
            total += len(rows)
        except Exception as e:
            data[name] = []
            print("  [SKIP] {}: {}".format(name, e))

    db.close()

    backup_data = {
        "version": "1.0",
        "created_at": datetime.now().isoformat(),
        "total_records": total,
        "tables": data,
    }

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(backup_data, f, ensure_ascii=False, indent=2, default=str)

    size = os.path.getsize(output_file)
    print("")
    print("=" * 40)
    print("Backup complete!")
    print("  File: {}".format(output_file))
    print("  Size: {:.1f} KB".format(size / 1024))
    print("  Records: {}".format(total))
    print("=" * 40)
    print("")


def do_restore(input_file):
    from database import SessionLocal, init_db, User, Product, Order, OrderItem, CartItem, License, Review, WishlistItem, Ticket, Coupon, AffiliateCode, AffiliateClick, SiteSetting, Webhook, Domain, InstalledApp
    from sqlalchemy import text

    if not os.path.exists(input_file):
        print("[ERROR] File not found: {}".format(input_file))
        sys.exit(1)

    print("")
    print("Web Designs & Care - Restore")
    print("=" * 40)
    print("Input: {}".format(input_file))
    print("")

    with open(input_file, "r", encoding="utf-8") as f:
        backup_data = json.load(f)

    print("Backup created: {}".format(backup_data.get("created_at", "unknown")))
    print("Total records: {}".format(backup_data.get("total_records", "?")))
    print("")

    confirm = input("This will REPLACE all current data. Continue? [y/N]: ").strip().lower()
    if confirm != "y":
        print("Restore cancelled.")
        return

    init_db()
    db = SessionLocal()

    model_map = {
        "users": User, "products": Product, "orders": Order,
        "order_items": OrderItem, "cart_items": CartItem, "licenses": License,
        "reviews": Review, "wishlist": WishlistItem, "tickets": Ticket,
        "coupons": Coupon, "affiliate_codes": AffiliateCode,
        "affiliate_clicks": AffiliateClick, "site_settings": SiteSetting,
        "webhooks": Webhook, "domains": Domain, "installed_apps": InstalledApp,
    }

    # Clear tables in reverse order
    order = ["affiliate_clicks", "affiliate_codes", "order_items", "cart_items",
             "licenses", "reviews", "wishlist", "tickets", "orders",
             "coupons", "site_settings", "webhooks", "domains", "installed_apps",
             "products", "users"]
    for table in order:
        Model = model_map.get(table)
        if Model:
            try:
                db.query(Model).delete()
                db.commit()
            except Exception:
                db.rollback()

    # Restore
    tables_data = backup_data.get("tables", {})
    total = 0
    for table_name, rows in tables_data.items():
        Model = model_map.get(table_name)
        if not Model or not rows:
            continue
        try:
            for row_data in rows:
                obj = Model()
                for key, val in row_data.items():
                    if hasattr(obj, key):
                        setattr(obj, key, val)
                db.add(obj)
            db.commit()
            print("  [OK] Restored {}: {} records".format(table_name, len(rows)))
            total += len(rows)
        except Exception as e:
            db.rollback()
            print("  [FAIL] {}: {}".format(table_name, e))

    db.close()
    print("")
    print("=" * 40)
    print("Restore complete! {} records restored.".format(total))
    print("=" * 40)
    print("")


def do_list():
    import glob
    backups = sorted(glob.glob("backup_*.json"), reverse=True)
    if not backups:
        print("No backup files found in current directory.")
        return
    print("")
    print("Available backups:")
    for f in backups:
        size = os.path.getsize(f)
        print("  {} ({:.1f} KB)".format(f, size / 1024))
    print("")


def main():
    parser = argparse.ArgumentParser(description="Web Designs & Care - Backup & Restore")
    subparsers = parser.add_subparsers(dest="command")

    backup_parser = subparsers.add_parser("backup", help="Backup database to JSON")
    backup_parser.add_argument("--output", "-o", help="Output file name")

    restore_parser = subparsers.add_parser("restore", help="Restore database from JSON")
    restore_parser.add_argument("file", help="JSON backup file to restore")

    subparsers.add_parser("list", help="List available backup files")

    args = parser.parse_args()

    if args.command == "backup":
        do_backup(args.output)
    elif args.command == "restore":
        do_restore(args.file)
    elif args.command == "list":
        do_list()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
