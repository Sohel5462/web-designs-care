"""
Web Designs & Care - MySQL Migration Tool
==========================================
Switches from SQLite to MySQL with ONE command.

Usage:
  python migrate_to_mysql.py
  python migrate_to_mysql.py --host localhost --port 3306 --user root --password mypass --database web_designs_care
  python migrate_to_mysql.py --migrate-data    (also copies existing SQLite data)

What this script does:
  1. Creates the MySQL database (if not exists)
  2. Creates all tables in MySQL
  3. Seeds demo data
  4. Optionally migrates existing SQLite data
  5. Updates config.py to use MySQL automatically
"""

import sys
import os
import argparse
from datetime import datetime, timezone

def check_pymysql():
    try:
        import pymysql
        return True
    except ImportError:
        print("")
        print("[ERROR] PyMySQL is not installed!")
        print("")
        print("Install it with:")
        print("  pip install PyMySQL")
        print("")
        print("Or uncomment the PyMySQL line in requirements.txt and run:")
        print("  pip install -r requirements.txt")
        print("")
        return False


def create_mysql_database(host, port, user, password, database):
    """Create MySQL database if it doesn't exist."""
    import pymysql
    print("\n[1/5] Connecting to MySQL server...")
    try:
        conn = pymysql.connect(host=host, port=port, user=user, password=password, charset="utf8mb4")
        cursor = conn.cursor()
        cursor.execute(
            "CREATE DATABASE IF NOT EXISTS `{}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci".format(database)
        )
        conn.commit()
        print("  [OK] Database '{}' ready".format(database))
        cursor.close()
        conn.close()
        return True
    except pymysql.Error as e:
        print("  [ERROR] Cannot connect to MySQL: {}".format(e))
        print("")
        print("  Check that:")
        print("  - MySQL server is running")
        print("  - Host, port, username, and password are correct")
        print("  - The user has CREATE DATABASE permission")
        return False


def create_tables(mysql_url):
    """Create all tables in MySQL."""
    print("[2/5] Creating tables...")
    from sqlalchemy import create_engine
    from database import Base
    try:
        engine = create_engine(mysql_url)
        Base.metadata.create_all(bind=engine)
        print("  [OK] All tables created")
        return engine
    except Exception as e:
        print("  [ERROR] Failed to create tables: {}".format(e))
        return None


def seed_mysql_data(engine):
    """Seed demo data into MySQL."""
    print("[3/5] Seeding demo data...")
    from sqlalchemy.orm import sessionmaker
    from database import User, Product, Coupon, SiteSetting

    Session = sessionmaker(bind=engine)
    db = Session()
    try:
        seeded = []

        if db.query(User).count() == 0:
            db.add(User(open_id="demo-admin-001", name="Admin User", email="admin@webdesignscare.com", role="admin", login_method="demo"))
            db.add(User(open_id="demo-user-001", name="John Doe", email="john@example.com", role="user", login_method="demo"))
            db.commit()
            seeded.append("2 demo users")

        if db.query(Product).count() == 0:
            products = [
                Product(name="SaaSify Pro Template", slug="saasify-pro-template",
                    description="A complete SaaS landing page template with pricing, features, and testimonials. Built with React and Tailwind CSS.",
                    category="templates", type="template", price=29.00, original_price=59.00, discount=51,
                    status="published", rating=4.80, rating_count=124, downloads=890, sales=412,
                    thumbnail_url="https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&h=500&fit=crop",
                    tags=["react", "tailwind", "saas", "landing-page"],
                    features=["Responsive Design", "Dark Mode", "SEO Optimized", "Easy Customization", "12 Sections"]),
                Product(name="Ecommerce Starter Bundle", slug="ecommerce-starter-bundle",
                    description="Full ecommerce solution with product listing, cart, checkout, and admin dashboard.",
                    category="bundles", type="bundle", price=79.00, original_price=149.00, discount=47,
                    status="published", rating=4.90, rating_count=89, downloads=456, sales=178,
                    thumbnail_url="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=500&fit=crop",
                    tags=["ecommerce", "react", "stripe", "admin"],
                    features=["Shopping Cart", "Payment Integration", "Admin Dashboard", "Inventory Management", "Order Tracking"]),
                Product(name="Portfolio Plus Theme", slug="portfolio-plus-theme",
                    description="Stunning portfolio theme for designers and developers.",
                    category="themes", type="theme", price=19.00, original_price=39.00, discount=51,
                    status="published", rating=4.70, rating_count=203, downloads=1250, sales=412,
                    thumbnail_url="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&h=500&fit=crop",
                    tags=["portfolio", "designer", "developer", "animation"],
                    features=["Smooth Animations", "Project Gallery", "Contact Form", "Blog Section", "Multi-Color"]),
                Product(name="Blog Master Plugin", slug="blog-master-plugin",
                    description="Advanced blogging plugin with markdown support, SEO tools, and social sharing.",
                    category="plugins", type="plugin", price=14.00, original_price=24.00, discount=42,
                    status="published", rating=4.60, rating_count=156, downloads=678, sales=289,
                    thumbnail_url="https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&h=500&fit=crop",
                    tags=["blog", "markdown", "seo", "plugin"],
                    features=["Markdown Editor", "SEO Tools", "Social Sharing", "Comments System", "Categories & Tags"]),
                Product(name="Dashboard Pro UI Kit", slug="dashboard-pro-ui-kit",
                    description="Complete admin dashboard UI kit with 50+ components, charts, tables, and forms.",
                    category="templates", type="template", price=49.00, original_price=99.00, discount=51,
                    status="published", rating=4.85, rating_count=67, downloads=324, sales=156,
                    thumbnail_url="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=500&fit=crop",
                    tags=["dashboard", "admin", "ui-kit", "charts"],
                    features=["50+ Components", "Chart Library", "Data Tables", "Form Elements", "Light & Dark Mode"]),
                Product(name="Agency Website Template", slug="agency-website-template",
                    description="Professional agency website template with services, portfolio, team, and blog sections.",
                    category="templates", type="template", price=24.00, original_price=49.00, discount=51,
                    status="published", rating=4.75, rating_count=98, downloads=567, sales=213,
                    thumbnail_url="https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=500&fit=crop",
                    tags=["agency", "business", "professional", "website"],
                    features=["Services Section", "Portfolio Grid", "Team Profiles", "Blog", "Contact Form", "Testimonials"]),
            ]
            for p in products:
                db.add(p)
            db.commit()
            seeded.append("6 demo products")

        if db.query(Coupon).count() == 0:
            now = datetime.now(timezone.utc)
            from datetime import timedelta
            coupons = [
                Coupon(code="SAVE10", description="10% off any order", type="percentage", value=10, min_order_amount=0, max_uses=1000, is_active=True, expires_at=now + timedelta(days=365)),
                Coupon(code="SAVE20", description="20% off orders over $50", type="percentage", value=20, min_order_amount=50, max_uses=500, is_active=True, expires_at=now + timedelta(days=180)),
                Coupon(code="FLAT5", description="$5 off any order", type="fixed", value=5, min_order_amount=0, max_uses=2000, is_active=True, expires_at=now + timedelta(days=365)),
                Coupon(code="WELCOME", description="15% welcome discount", type="percentage", value=15, min_order_amount=0, max_uses=100, is_active=True, expires_at=now + timedelta(days=90)),
            ]
            for c in coupons:
                db.add(c)
            db.commit()
            seeded.append("4 coupons (SAVE10, SAVE20, FLAT5, WELCOME)")

        settings_defaults = [
            ("site_name", "Web Designs & Care"),
            ("site_tagline", "Premium Digital Assets for Modern Developers"),
            ("site_description", "Premium website templates, themes, plugins, and full-site bundles"),
            ("contact_email", "support@webdesignscare.com"),
            ("currency", "USD"),
            ("maintenance_mode", "false"),
            ("demo_mode", "true"),
        ]
        for key, val in settings_defaults:
            if not db.query(SiteSetting).filter(SiteSetting.key == key).first():
                db.add(SiteSetting(key=key, value=val))
        db.commit()

        if seeded:
            for s in seeded:
                print("  [OK] Seeded: {}".format(s))
        else:
            print("  [OK] Data already exists, skipping seed")

    except Exception as e:
        db.rollback()
        print("  [WARN] Seed error: {}".format(e))
    finally:
        db.close()


def migrate_sqlite_data(sqlite_url, mysql_engine):
    """Copy existing SQLite data to MySQL."""
    print("[4/5] Migrating existing SQLite data...")
    from sqlalchemy import create_engine as ce
    from sqlalchemy.orm import sessionmaker
    from database import User, Product, Order, OrderItem, CartItem, License, Review, WishlistItem, Ticket, Coupon, AffiliateCode, SiteSetting

    try:
        sqlite_engine = ce(sqlite_url)
        SQLiteSession = sessionmaker(bind=sqlite_engine)
        MySQLSession = sessionmaker(bind=mysql_engine)
        src = SQLiteSession()
        dst = MySQLSession()

        models = [User, Product, Coupon, SiteSetting, Order, OrderItem, CartItem, License, Review, WishlistItem, Ticket, AffiliateCode]
        total = 0
        for Model in models:
            try:
                rows = src.query(Model).all()
                for row in rows:
                    src.expunge(row)
                    from sqlalchemy.orm.session import make_transient
                    make_transient(row)
                    dst.merge(row)
                dst.commit()
                if rows:
                    print("  [OK] Migrated {} {} records".format(len(rows), Model.__tablename__))
                    total += len(rows)
            except Exception as e:
                dst.rollback()
                print("  [SKIP] {} - {}".format(Model.__tablename__, e))
        print("  [OK] Total records migrated: {}".format(total))
        src.close()
        dst.close()
    except Exception as e:
        print("  [ERROR] Migration failed: {}".format(e))


def update_config(mysql_url):
    """Update config.py to use MySQL."""
    print("[5/5] Updating config.py...")
    config_path = os.path.join(os.path.dirname(__file__), "config.py")
    try:
        with open(config_path, "r") as f:
            content = f.read()

        # Replace the DATABASE_URL line
        lines = content.split("\n")
        new_lines = []
        for line in lines:
            if 'DATABASE_URL = os.environ.get("DATABASE_URL"' in line:
                new_lines.append('    DATABASE_URL = os.environ.get("DATABASE_URL", "{}")'.format(mysql_url))
            else:
                new_lines.append(line)

        with open(config_path, "w") as f:
            f.write("\n".join(new_lines))
        print("  [OK] config.py updated to use MySQL")
        print("  [OK] You can now run: python app.py")
    except Exception as e:
        print("  [WARN] Could not update config.py: {}".format(e))
        print("  Manually set DATABASE_URL in config.py to: {}".format(mysql_url))


def main():
    parser = argparse.ArgumentParser(
        description="Web Designs & Care - MySQL Migration Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python migrate_to_mysql.py
  python migrate_to_mysql.py --host localhost --user root --password secret
  python migrate_to_mysql.py --database mydb --migrate-data
  python migrate_to_mysql.py --host 192.168.1.10 --port 3306 --user admin --password pass123
        """
    )
    parser.add_argument("--host", default="localhost", help="MySQL server host (default: localhost)")
    parser.add_argument("--port", type=int, default=3306, help="MySQL server port (default: 3306)")
    parser.add_argument("--user", default="root", help="MySQL username (default: root)")
    parser.add_argument("--password", default="", help="MySQL password (default: empty)")
    parser.add_argument("--database", default="web_designs_care", help="Database name (default: web_designs_care)")
    parser.add_argument("--migrate-data", action="store_true", help="Also copy existing SQLite data to MySQL")
    parser.add_argument("--no-update-config", action="store_true", help="Don't update config.py automatically")

    args = parser.parse_args()

    # Interactive mode if no password provided
    if not args.password and len(sys.argv) == 1:
        print("")
        print("=" * 52)
        print("   Web Designs & Care - MySQL Migration")
        print("=" * 52)
        print("")
        print("This will switch your app from SQLite to MySQL.")
        print("")
        args.host = input("MySQL Host [localhost]: ").strip() or "localhost"
        args.port = int(input("MySQL Port [3306]: ").strip() or "3306")
        args.user = input("MySQL Username [root]: ").strip() or "root"
        import getpass
        args.password = getpass.getpass("MySQL Password: ")
        args.database = input("Database Name [web_designs_care]: ").strip() or "web_designs_care"
        migrate = input("Migrate existing SQLite data? [y/N]: ").strip().lower()
        args.migrate_data = migrate == "y"

    print("")
    print("=" * 52)
    print("   MySQL Migration Starting...")
    print("=" * 52)
    print("  Host:     {}:{}".format(args.host, args.port))
    print("  User:     {}".format(args.user))
    print("  Database: {}".format(args.database))
    print("=" * 52)

    if not check_pymysql():
        sys.exit(1)

    # Step 1: Create database
    if not create_mysql_database(args.host, args.port, args.user, args.password, args.database):
        sys.exit(1)

    # Build MySQL URL
    mysql_url = "mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8mb4".format(
        args.user, args.password, args.host, args.port, args.database
    )

    # Step 2: Create tables
    engine = create_tables(mysql_url)
    if not engine:
        sys.exit(1)

    # Step 3: Seed data
    seed_mysql_data(engine)

    # Step 4: Migrate SQLite data (optional)
    if args.migrate_data:
        sqlite_path = os.path.join(os.path.dirname(__file__), "web_designs_care.db")
        if os.path.exists(sqlite_path):
            migrate_sqlite_data("sqlite:///{}".format(sqlite_path), engine)
        else:
            print("[4/5] No SQLite database found, skipping migration")
    else:
        print("[4/5] Skipping SQLite data migration (use --migrate-data to copy existing data)")

    # Step 5: Update config
    if not args.no_update_config:
        update_config(mysql_url)
    else:
        print("[5/5] Skipping config update (--no-update-config)")
        print("  Manually set in config.py:")
        print("  DATABASE_URL = \"{}\"".format(mysql_url))

    print("")
    print("=" * 52)
    print("  MIGRATION COMPLETE!")
    print("  Run the app: python app.py")
    print("=" * 52)
    print("")


if __name__ == "__main__":
    main()
