"""
Web Designs & Care - Setup Checker
Run this to verify your installation is correct before starting the app.
Usage: python check_setup.py
"""
import sys

print("")
print("=" * 50)
print("  Web Designs & Care - Setup Check")
print("=" * 50)

errors = []
warnings = []

# Check Python version
major, minor = sys.version_info[:2]
print("\n[1] Python version: {}.{}".format(major, minor))
if major < 3 or (major == 3 and minor < 9):
    errors.append("Python 3.9+ is required. Current: {}.{}".format(major, minor))
    print("    [FAIL] Need Python 3.9 or newer")
else:
    print("    [OK]")

# Check required packages
packages = {
    "flask": "Flask",
    "flask_cors": "Flask-Cors",
    "sqlalchemy": "SQLAlchemy",
    "jwt": "PyJWT",
    "werkzeug": "Werkzeug",
}

print("\n[2] Required packages:")
for module, name in packages.items():
    try:
        __import__(module)
        print("    [OK] {}".format(name))
    except ImportError:
        errors.append("{} is not installed. Run: pip install {}".format(name, name))
        print("    [FAIL] {} - NOT INSTALLED".format(name))

# Check optional packages
optional = {
    "pymysql": "PyMySQL (for MySQL)",
    "stripe": "stripe (for Stripe payments)",
}
print("\n[3] Optional packages:")
for module, name in optional.items():
    try:
        __import__(module)
        print("    [OK] {}".format(name))
    except ImportError:
        warnings.append("{} not installed (optional)".format(name))
        print("    [--] {} - not installed (optional)".format(name))

# Check static files
import os
print("\n[4] Frontend files:")
static_dir = os.path.join(os.path.dirname(__file__), "static")
index_file = os.path.join(static_dir, "index.html")
if os.path.exists(index_file):
    print("    [OK] static/index.html found")
else:
    warnings.append("static/index.html not found - the web UI may not load")
    print("    [WARN] static/index.html not found")

# Check config
print("\n[5] Configuration:")
try:
    from config import Config
    print("    [OK] Port: {}".format(Config.PORT))
    print("    [OK] Database: {}".format(Config.DATABASE_URL))
    if "sqlite" in Config.DATABASE_URL.lower():
        print("    [OK] Using SQLite (works offline, no setup needed)")
    elif "mysql" in Config.DATABASE_URL.lower():
        print("    [INFO] Using MySQL - make sure MySQL server is running")
except Exception as e:
    errors.append("Config error: {}".format(e))
    print("    [FAIL] Config error: {}".format(e))

# Summary
print("\n" + "=" * 50)
if errors:
    print("RESULT: FAILED - Fix these errors:")
    for err in errors:
        print("  * {}".format(err))
    print("\nInstall missing packages with:")
    print("  pip install -r requirements.txt")
elif warnings:
    print("RESULT: OK (with warnings)")
    for w in warnings:
        print("  * {}".format(w))
    print("\nYou can run the app with: python app.py")
else:
    print("RESULT: ALL CHECKS PASSED!")
    print("\nStart the app with: python app.py")
print("=" * 50)
print("")
