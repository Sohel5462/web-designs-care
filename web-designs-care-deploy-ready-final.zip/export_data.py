"""
Web Designs & Care - Data Export Tool
======================================
Export your data to CSV files for Excel, Google Sheets, etc.

Usage:
  python export_data.py                # Export all tables to CSV
  python export_data.py --table orders # Export only orders
  python export_data.py --output exports/  # Export to specific folder

Available tables:
  orders, products, users, licenses, reviews, tickets, coupons, affiliate_codes
"""

import os
import csv
import sys
import argparse
from datetime import datetime


def export_table(db, model_class, table_name, output_dir):
    rows = db.query(model_class).all()
    if not rows:
        print("  [--] {}: empty".format(table_name))
        return 0

    filename = os.path.join(output_dir, "{}.csv".format(table_name))
    columns = [col.name for col in model_class.__table__.columns]

    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            row_dict = {}
            for col in columns:
                val = getattr(row, col)
                if isinstance(val, datetime):
                    val = val.isoformat()
                elif hasattr(val, "__float__"):
                    val = float(val)
                elif isinstance(val, (list, dict)):
                    import json
                    val = json.dumps(val, ensure_ascii=False)
                row_dict[col] = val
            writer.writerow(row_dict)

    print("  [OK] {}: {} records -> {}".format(table_name, len(rows), filename))
    return len(rows)


def main():
    parser = argparse.ArgumentParser(description="Web Designs & Care - Export to CSV")
    parser.add_argument("--table", "-t", help="Export specific table only")
    parser.add_argument("--output", "-o", default="exports", help="Output directory (default: exports/)")
    args = parser.parse_args()

    from database import init_db, SessionLocal, User, Product, Order, OrderItem, License, Review, Ticket, Coupon, AffiliateCode, WishlistItem, CartItem, SiteSetting

    init_db()
    db = SessionLocal()

    os.makedirs(args.output, exist_ok=True)

    all_models = {
        "users": User,
        "products": Product,
        "orders": Order,
        "order_items": OrderItem,
        "licenses": License,
        "reviews": Review,
        "tickets": Ticket,
        "coupons": Coupon,
        "affiliate_codes": AffiliateCode,
        "wishlist": WishlistItem,
        "cart_items": CartItem,
        "site_settings": SiteSetting,
    }

    print("")
    print("Web Designs & Care - Export to CSV")
    print("=" * 40)
    print("Output folder: {}".format(os.path.abspath(args.output)))
    print("")

    total = 0
    if args.table:
        if args.table not in all_models:
            print("[ERROR] Unknown table '{}'. Available: {}".format(args.table, ", ".join(all_models.keys())))
            sys.exit(1)
        total = export_table(db, all_models[args.table], args.table, args.output)
    else:
        for name, model in all_models.items():
            total += export_table(db, model, name, args.output)

    db.close()
    print("")
    print("=" * 40)
    print("Export complete! {} records total.".format(total))
    print("Files saved to: {}".format(os.path.abspath(args.output)))
    print("=" * 40)
    print("")


if __name__ == "__main__":
    main()
