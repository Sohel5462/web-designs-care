"""
Web Designs & Care - Admin User Manager
========================================
Create, list, or update admin users from the command line.

Usage:
  python create_admin.py                       # Interactive mode
  python create_admin.py --name "Admin" --email admin@example.com
  python create_admin.py --list                # List all users
  python create_admin.py --promote admin@example.com   # Make user admin
  python create_admin.py --demote admin@example.com    # Remove admin role
"""

import sys
import os
import argparse


def list_users(db):
    from database import User
    users = db.query(User).order_by(User.id).all()
    if not users:
        print("No users found.")
        return
    print("")
    print("{:<5} {:<25} {:<35} {:<10} {}".format("ID", "Name", "Email", "Role", "Created"))
    print("-" * 90)
    for u in users:
        created = u.created_at.strftime("%Y-%m-%d") if u.created_at else "N/A"
        print("{:<5} {:<25} {:<35} {:<10} {}".format(
            u.id,
            (u.name or "")[:24],
            (u.email or "")[:34],
            u.role,
            created
        ))
    print("")
    print("Total: {} user(s)".format(len(users)))
    print("")


def create_user(db, name, email, role="admin"):
    from database import User
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        print("[INFO] User with email '{}' already exists (role: {})".format(email, existing.role))
        if existing.role != role:
            existing.role = role
            db.commit()
            print("[OK] Role updated to '{}'".format(role))
        return existing

    open_id = "cli-{}-{}".format(role, email.lower().replace("@", "-").replace(".", "-"))
    user = User(open_id=open_id, name=name, email=email, role=role, login_method="demo")
    db.add(user)
    db.commit()
    db.refresh(user)
    print("[OK] User created: {} <{}> (role: {})".format(name, email, role))
    return user


def change_role(db, email, new_role):
    from database import User
    user = db.query(User).filter(User.email == email).first()
    if not user:
        print("[ERROR] User not found: {}".format(email))
        return False
    old_role = user.role
    user.role = new_role
    db.commit()
    print("[OK] {} <{}> role changed: {} -> {}".format(user.name, email, old_role, new_role))
    return True


def main():
    parser = argparse.ArgumentParser(description="Web Designs & Care - Admin User Manager")
    parser.add_argument("--name", help="User full name")
    parser.add_argument("--email", help="User email address")
    parser.add_argument("--role", default="admin", choices=["admin", "user"], help="User role (default: admin)")
    parser.add_argument("--list", "-l", action="store_true", help="List all users")
    parser.add_argument("--promote", metavar="EMAIL", help="Promote user to admin role")
    parser.add_argument("--demote", metavar="EMAIL", help="Demote user to customer role")

    args = parser.parse_args()

    from database import init_db, SessionLocal
    init_db()
    db = SessionLocal()

    try:
        if args.list:
            list_users(db)

        elif args.promote:
            change_role(db, args.promote, "admin")

        elif args.demote:
            change_role(db, args.demote, "user")

        elif args.email:
            name = args.name or args.email.split("@")[0].title()
            create_user(db, name, args.email, args.role)

        else:
            # Interactive mode
            print("")
            print("=" * 45)
            print("  Web Designs & Care - User Manager")
            print("=" * 45)
            print("")
            print("Options:")
            print("  1. Create new admin user")
            print("  2. Create new customer user")
            print("  3. List all users")
            print("  4. Promote user to admin")
            print("  5. Exit")
            print("")
            choice = input("Choose [1-5]: ").strip()

            if choice == "1" or choice == "2":
                role = "admin" if choice == "1" else "user"
                name = input("Full name: ").strip()
                email = input("Email: ").strip()
                if not name or not email:
                    print("[ERROR] Name and email are required")
                else:
                    create_user(db, name, email, role)

            elif choice == "3":
                list_users(db)

            elif choice == "4":
                list_users(db)
                email = input("Email to promote: ").strip()
                if email:
                    change_role(db, email, "admin")

            else:
                print("Exiting.")

    finally:
        db.close()


if __name__ == "__main__":
    main()
