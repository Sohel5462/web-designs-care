"""
Web Designs & Care — PowerPoint Presentation Generator
=======================================================
Generates a professional PowerPoint presentation summarizing the platform.

Usage:
  python generate_presentation.py
  python generate_presentation.py --output my_presentation.pptx

Requirements:
  pip install python-pptx

Output: web_designs_care_presentation.pptx
"""
import argparse
import sys
import os


def check_pptx():
    try:
        from pptx import Presentation
        return True
    except ImportError:
        print("[ERROR] python-pptx is not installed.")
        print("Install it with:  pip install python-pptx")
        return False


def rgb(r, g, b):
    from pptx.util import Pt
    from pptx.dml.color import RGBColor
    return RGBColor(r, g, b)


def add_slide(prs, layout_index=6):
    layout = prs.slide_layouts[layout_index]
    return prs.slides.add_slide(layout)


def set_bg(slide, r, g, b):
    from pptx.util import Pt
    from pptx.dml.color import RGBColor
    from pptx.oxml.ns import qn
    from lxml import etree
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(r, g, b)


def add_textbox(slide, text, left, top, width, height,
                font_size=18, bold=False, color=(255, 255, 255),
                align="left", italic=False, font_name="Calibri"):
    from pptx.util import Inches, Pt, Emu
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN

    txBox = slide.shapes.add_textbox(
        Inches(left), Inches(top), Inches(width), Inches(height)
    )
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    run = p.runs[0]
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.name = font_name
    run.font.color.rgb = RGBColor(*color)
    if align == "center":
        p.alignment = PP_ALIGN.CENTER
    elif align == "right":
        p.alignment = PP_ALIGN.RIGHT
    else:
        p.alignment = PP_ALIGN.LEFT
    return txBox


def add_rect(slide, left, top, width, height, fill_rgb, line_rgb=None):
    from pptx.util import Inches
    from pptx.dml.color import RGBColor
    shape = slide.shapes.add_shape(
        1,  # MSO_SHAPE_TYPE.RECTANGLE
        Inches(left), Inches(top), Inches(width), Inches(height)
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = RGBColor(*fill_rgb)
    if line_rgb:
        shape.line.color.rgb = RGBColor(*line_rgb)
    else:
        shape.line.fill.background()
    return shape


def create_presentation(output_file="web_designs_care_presentation.pptx"):
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor

    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    # Color palette
    DARK_BG = (15, 23, 42)          # Deep navy
    ACCENT = (99, 102, 241)         # Indigo
    ACCENT2 = (139, 92, 246)        # Purple
    WHITE = (255, 255, 255)
    LIGHT_GRAY = (226, 232, 240)
    CARD_BG = (30, 41, 59)          # Slate dark
    GREEN = (52, 211, 153)          # Emerald
    YELLOW = (251, 191, 36)         # Amber
    RED = (248, 113, 113)           # Rose

    # ─── SLIDE 1: Title ──────────────────────────────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)

    # Accent bar top
    add_rect(slide, 0, 0, 13.33, 0.08, ACCENT)
    # Gradient overlay rectangle
    add_rect(slide, 0, 0, 13.33, 7.5, (20, 30, 60))
    add_rect(slide, 0, 0, 13.33, 0.08, ACCENT)
    add_rect(slide, 0, 7.42, 13.33, 0.08, ACCENT2)

    # Decorative circles
    add_rect(slide, 9.5, 1.0, 3.5, 3.5, (30, 40, 80))
    add_rect(slide, 10.5, 2.5, 2.0, 2.0, (50, 60, 120))

    add_textbox(slide, "Web Designs & Care", 0.8, 1.8, 9, 1.2, 52, True, ACCENT, "left", font_name="Calibri")
    add_textbox(slide, "Premium Digital Asset Marketplace", 0.8, 3.0, 9, 0.7, 26, False, LIGHT_GRAY, "left")
    add_textbox(slide, "Templates · Themes · Plugins · Bundles", 0.8, 3.7, 9, 0.5, 18, False, (148, 163, 184), "left")

    # Feature pills
    pills = ["100% Offline", "Python + Flask", "SQLite / MySQL", "Admin Panel", "SEO Tools"]
    for i, pill in enumerate(pills):
        add_rect(slide, 0.8 + i * 2.45, 4.6, 2.2, 0.45, ACCENT)
        add_textbox(slide, pill, 0.85 + i * 2.45, 4.62, 2.1, 0.4, 13, True, WHITE, "center")

    add_textbox(slide, "Run offline on PC (Windows/Linux/Mac) or Android (Pydroid3)", 0.8, 5.3, 11, 0.4, 14, False, (148, 163, 184), "left")
    add_textbox(slide, "© 2025 Web Designs & Care", 0.8, 6.9, 12, 0.3, 11, False, (71, 85, 105), "left")

    # ─── SLIDE 2: Platform Overview ──────────────────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)
    add_rect(slide, 0, 0, 13.33, 0.08, ACCENT)

    add_textbox(slide, "Platform Overview", 0.5, 0.3, 12, 0.7, 36, True, WHITE, "left")
    add_textbox(slide, "Everything you need to sell digital products — offline, out of the box", 0.5, 1.0, 12, 0.4, 16, False, (148, 163, 184), "left")
    add_rect(slide, 0.5, 1.45, 4, 0.04, ACCENT)

    # Feature cards in 2x3 grid
    features = [
        ("🛍️", "Product Catalog", "Search, filter, sort by\ncategory, type & price"),
        ("🛒", "Shopping Cart", "Coupon codes, quantity\nmanagement, real-time totals"),
        ("📦", "Order Management", "Full order tracking,\nstatus updates, history"),
        ("🔑", "License Keys", "Auto-generated on purchase,\ndownload file delivery"),
        ("⭐", "Reviews & Ratings", "Customer reviews, ratings,\nproduct credibility"),
        ("🎫", "Support Tickets", "Built-in helpdesk,\nstatus tracking"),
    ]
    cols = [(0.4, 2.0), (4.6, 2.0), (8.8, 2.0)]
    rows = [1.7, 4.3]
    for idx, (icon, title, desc) in enumerate(features):
        col = idx % 3
        row = idx // 3
        x, _ = cols[col]
        y = rows[row]
        add_rect(slide, x, y, 3.8, 2.2, CARD_BG)
        add_textbox(slide, icon + "  " + title, x + 0.2, y + 0.15, 3.4, 0.45, 15, True, ACCENT, "left")
        add_textbox(slide, desc, x + 0.2, y + 0.6, 3.4, 1.3, 12, False, LIGHT_GRAY, "left")

    # ─── SLIDE 3: Admin Panel ────────────────────────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)
    add_rect(slide, 0, 0, 13.33, 0.08, ACCENT2)

    add_textbox(slide, "Admin Panel — 10 Full-Featured Tabs", 0.5, 0.3, 12, 0.7, 32, True, WHITE, "left")
    add_textbox(slide, "Complete store management with dropdown controls on every section", 0.5, 1.0, 12, 0.4, 15, False, (148, 163, 184), "left")
    add_rect(slide, 0.5, 1.45, 5, 0.04, ACCENT2)

    tabs = [
        ("Analytics", "Revenue, orders, users, category breakdown", GREEN),
        ("Products", "Add/edit/delete, file upload, CSV import, SEO fields", ACCENT),
        ("Orders", "Status dropdown: Pending/Completed/Cancelled/Refunded", YELLOW),
        ("Users", "Role management: Customer/Admin toggle", ACCENT2),
        ("Coupons", "% and fixed discounts, expiry, usage limits", GREEN),
        ("Affiliates", "Commission tracking, click analytics", ACCENT),
        ("Domains", "Add/Edit/Delete domains, hosting type, SSL", YELLOW),
        ("Apps", "Enable/disable integrations, dropshipping, marketing", ACCENT2),
        ("Webhooks", "HTTP callbacks for order events, test button", GREEN),
        ("Settings", "Site name, SEO, Stripe, AutoDS, maintenance mode", RED),
    ]
    for i, (tab, desc, color) in enumerate(tabs):
        col = i % 2
        row = i // 2
        x = 0.4 + col * 6.4
        y = 1.7 + row * 1.0
        add_rect(slide, x, y, 0.25, 0.5, color)
        add_textbox(slide, tab, x + 0.4, y + 0.03, 2.5, 0.3, 13, True, color, "left")
        add_textbox(slide, desc, x + 0.4, y + 0.27, 5.5, 0.3, 11, False, LIGHT_GRAY, "left")

    # ─── SLIDE 4: SEO Tools ──────────────────────────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)
    add_rect(slide, 0, 0, 13.33, 0.08, GREEN)

    add_textbox(slide, "Advanced SEO Tools", 0.5, 0.3, 12, 0.7, 36, True, WHITE, "left")
    add_textbox(slide, "Built-in SEO management — no plugins, no cloud required", 0.5, 1.0, 12, 0.4, 16, False, (148, 163, 184), "left")
    add_rect(slide, 0.5, 1.45, 3, 0.04, GREEN)

    seo_items = [
        ("🗺️ Sitemap.xml", "Auto-generated XML sitemap for all published products. Accessible at /sitemap.xml"),
        ("🤖 Robots.txt", "Fully configurable robots.txt via Admin → Settings. Block/allow any paths"),
        ("📊 SEO Analyzer", "Health check for all products — scores each product 0-100, lists missing fields"),
        ("✨ Auto Meta Generator", "1-click generate meta titles, descriptions & keywords for all products"),
        ("🏷️ Per-Product SEO", "Meta title, meta description, keywords per product in the editor"),
        ("📱 Open Graph / Twitter", "OG image URL, Twitter handle, card type — for social media sharing"),
        ("🔍 Structured Data", "JSON-LD schema markup for all products — Google rich results support"),
        ("📈 Google Analytics", "Add GA tracking ID in Settings — works when online"),
        ("✅ Google Verify", "Google & Bing site verification meta tags via Settings"),
        ("🔗 Canonical URLs", "Set canonical URL in Settings to prevent duplicate content"),
    ]
    for i, (title, desc) in enumerate(seo_items):
        col = i % 2
        row = i // 2
        x = 0.4 + col * 6.4
        y = 1.7 + row * 1.0
        add_rect(slide, x, y, 6.0, 0.85, CARD_BG)
        add_textbox(slide, title, x + 0.15, y + 0.05, 5.7, 0.3, 13, True, GREEN, "left")
        add_textbox(slide, desc, x + 0.15, y + 0.38, 5.7, 0.42, 11, False, LIGHT_GRAY, "left")

    # ─── SLIDE 5: Stripe + AutoDS + Dropshipping ─────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)
    add_rect(slide, 0, 0, 13.33, 0.08, YELLOW)

    add_textbox(slide, "Payments · AutoDS · Dropshipping", 0.5, 0.3, 12, 0.7, 32, True, WHITE, "left")
    add_textbox(slide, "Pre-built integrations — disabled by default, enable when ready via Admin → Settings", 0.5, 1.0, 12, 0.4, 15, False, (148, 163, 184), "left")
    add_rect(slide, 0.5, 1.45, 6, 0.04, YELLOW)

    # Stripe card
    add_rect(slide, 0.4, 1.7, 3.9, 5.5, CARD_BG)
    add_rect(slide, 0.4, 1.7, 3.9, 0.5, (99, 102, 241))
    add_textbox(slide, "💳 Stripe Payments", 0.6, 1.75, 3.5, 0.4, 15, True, WHITE, "left")
    stripe_points = [
        "Status: DISABLED (default)",
        "Enable: Admin → Settings → stripe_enabled = true",
        "Add Stripe Publishable Key",
        "Add Stripe Secret Key",
        "Add Webhook Secret (optional)",
        "Real checkout sessions via Stripe",
        "Webhook handles payment confirmation",
        "Auto-creates orders + licenses",
        "Works in test or live mode",
        "No internet = demo checkout",
    ]
    for i, pt in enumerate(stripe_points):
        clr = (52, 211, 153) if "DISABLED" in pt else LIGHT_GRAY
        add_textbox(slide, "• " + pt, 0.6, 2.35 + i * 0.45, 3.6, 0.4, 11, "DISABLED" in pt or "true" in pt, clr, "left")

    # AutoDS card
    add_rect(slide, 4.7, 1.7, 3.9, 5.5, CARD_BG)
    add_rect(slide, 4.7, 1.7, 3.9, 0.5, (139, 92, 246))
    add_textbox(slide, "🤖 AutoDS Integration", 4.9, 1.75, 3.5, 0.4, 15, True, WHITE, "left")
    autods_points = [
        "Status: DISABLED (default)",
        "Enable: autods_enabled = true",
        "Add API key from autods.com",
        "Add your AutoDS User ID",
        "Browse 9+ supplier sources",
        "Amazon, AliExpress, Walmart...",
        "Import products to catalog",
        "Auto price markup (default 30%)",
        "Stock & price monitoring",
        "Requires internet to sync",
    ]
    for i, pt in enumerate(autods_points):
        clr = (52, 211, 153) if "DISABLED" in pt else LIGHT_GRAY
        add_textbox(slide, "• " + pt, 4.9, 2.35 + i * 0.45, 3.6, 0.4, 11, "DISABLED" in pt, clr, "left")

    # Dropshipping card
    add_rect(slide, 9.0, 1.7, 3.9, 5.5, CARD_BG)
    add_rect(slide, 9.0, 1.7, 3.9, 0.5, (251, 191, 36))
    add_textbox(slide, "📦 Dropshipping", 9.2, 1.75, 3.5, 0.4, 15, True, WHITE, "left")
    ds_points = [
        "Status: DISABLED (default)",
        "Enable: dropshipping_enabled = true",
        "Works with AutoDS",
        "Price markup % setting",
        "Auto-fulfillment option",
        "Custom return policy",
        "Shipping note per order",
        "9+ suppliers supported",
        "Processing days setting",
        "Requires AutoDS account",
    ]
    for i, pt in enumerate(ds_points):
        clr = (52, 211, 153) if "DISABLED" in pt else LIGHT_GRAY
        add_textbox(slide, "• " + pt, 9.2, 2.35 + i * 0.45, 3.6, 0.4, 11, "DISABLED" in pt, clr, "left")

    # ─── SLIDE 6: Developer Tools ─────────────────────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)
    add_rect(slide, 0, 0, 13.33, 0.08, ACCENT2)

    add_textbox(slide, "Developer & Management Tools", 0.5, 0.3, 12, 0.7, 32, True, WHITE, "left")
    add_textbox(slide, "Command-line utilities included in the ZIP — run directly from terminal or Pydroid3", 0.5, 1.0, 12, 0.4, 15, False, (148, 163, 184), "left")
    add_rect(slide, 0.5, 1.45, 5, 0.04, ACCENT2)

    tools = [
        ("app.py", "python app.py", "Start server, auto-seed data, init DB", ACCENT),
        ("check_setup.py", "python check_setup.py", "Verify all packages + config before running", GREEN),
        ("migrate_to_mysql.py", "python migrate_to_mysql.py", "Switch from SQLite to MySQL with one command", YELLOW),
        ("backup.py backup", "python backup.py backup", "Backup all data to timestamped JSON file", ACCENT2),
        ("backup.py restore", "python backup.py restore file.json", "Restore database from JSON backup", ACCENT2),
        ("create_admin.py", "python create_admin.py", "Create/promote/demote admin users from CLI", GREEN),
        ("export_data.py", "python export_data.py", "Export all tables to CSV (Excel-compatible)", YELLOW),
        ("generate_presentation.py", "python generate_presentation.py", "Generate this PowerPoint presentation", ACCENT),
    ]
    for i, (name, cmd, desc, color) in enumerate(tools):
        col = i % 2
        row = i // 2
        x = 0.4 + col * 6.4
        y = 1.7 + row * 1.3
        add_rect(slide, x, y, 6.0, 1.1, CARD_BG)
        add_rect(slide, x, y, 0.15, 1.1, color)
        add_textbox(slide, name, x + 0.3, y + 0.05, 5.5, 0.35, 13, True, color, "left")
        add_textbox(slide, cmd, x + 0.3, y + 0.38, 5.5, 0.3, 11, False, (148, 163, 184), "left", font_name="Courier New")
        add_textbox(slide, desc, x + 0.3, y + 0.65, 5.5, 0.35, 11, False, LIGHT_GRAY, "left")

    # ─── SLIDE 7: Tech Stack & Architecture ──────────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)
    add_rect(slide, 0, 0, 13.33, 0.08, GREEN)

    add_textbox(slide, "Tech Stack & Architecture", 0.5, 0.3, 12, 0.7, 32, True, WHITE, "left")
    add_textbox(slide, "Modern Python backend with pre-built React frontend — zero cloud dependency", 0.5, 1.0, 12, 0.4, 15, False, (148, 163, 184), "left")
    add_rect(slide, 0.5, 1.45, 4, 0.04, GREEN)

    # Architecture diagram
    add_rect(slide, 0.4, 1.7, 12.5, 5.5, CARD_BG)

    # Frontend box
    add_rect(slide, 0.7, 2.0, 3.5, 2.0, (30, 60, 90))
    add_textbox(slide, "Frontend (React)", 0.9, 2.1, 3.1, 0.4, 13, True, (96, 165, 250), "center")
    add_textbox(slide, "Pre-built static files\nHTML + CSS + JavaScript\nServed by Flask\nReact Query hooks\nTailwind CSS + shadcn/ui", 0.9, 2.5, 3.1, 1.3, 11, False, LIGHT_GRAY, "center")

    # Arrow
    add_textbox(slide, "→", 4.3, 2.75, 0.5, 0.4, 20, True, ACCENT, "center")

    # Backend box
    add_rect(slide, 4.9, 2.0, 3.5, 2.0, (30, 60, 30))
    add_textbox(slide, "Backend (Flask)", 5.1, 2.1, 3.1, 0.4, 13, True, GREEN, "center")
    add_textbox(slide, "Python 3.9+\nFlask 3.0 + Flask-CORS\n14 route blueprints\nJWT authentication\nSQLAlchemy ORM", 5.1, 2.5, 3.1, 1.3, 11, False, LIGHT_GRAY, "center")

    # Arrow
    add_textbox(slide, "→", 8.5, 2.75, 0.5, 0.4, 20, True, ACCENT, "center")

    # Database box
    add_rect(slide, 9.1, 2.0, 3.5, 2.0, (60, 30, 30))
    add_textbox(slide, "Database", 9.3, 2.1, 3.1, 0.4, 13, True, YELLOW, "center")
    add_textbox(slide, "SQLite (default offline)\nMySQL (optional)\nDrizzle ORM compatible\n16 tables\nAuto-migrate on startup", 9.3, 2.5, 3.1, 1.3, 11, False, LIGHT_GRAY, "center")

    # Stack items
    stack = [
        "Python 3.9+  ·  Flask 3.0  ·  SQLAlchemy 2.0  ·  PyJWT",
        "React 18  ·  TypeScript  ·  Tailwind CSS v4  ·  shadcn/ui",
        "SQLite (offline)  ·  MySQL (optional)  ·  Stripe (optional)  ·  AutoDS (optional)",
        "Works on: Windows · Linux · macOS · Android (Pydroid3)",
    ]
    for i, line in enumerate(stack):
        clr = [ACCENT, (96, 165, 250), YELLOW, GREEN][i]
        add_rect(slide, 0.7, 4.2 + i * 0.65, 12.1, 0.55, (20, 30, 50))
        add_textbox(slide, line, 0.9, 4.27 + i * 0.65, 11.8, 0.4, 12, False, clr, "center")

    # ─── SLIDE 8: Summary ────────────────────────────────────────────────────
    slide = add_slide(prs)
    set_bg(slide, *DARK_BG)
    add_rect(slide, 0, 0, 13.33, 0.08, ACCENT)
    add_rect(slide, 0, 7.42, 13.33, 0.08, ACCENT2)

    add_textbox(slide, "Ready. Offline. Yours.", 0.5, 0.5, 12, 0.9, 44, True, ACCENT, "center")

    summary = (
        "Web Designs & Care is a complete digital marketplace built with Python + Flask + SQLite. "
        "It runs 100% offline on any PC or Android phone (Pydroid3). The admin panel features 10 full tabs "
        "with dropdown controls for products, orders, users, coupons, affiliates, domains, apps, "
        "webhooks, and settings. Advanced SEO tools include auto-generated sitemaps, configurable robots.txt, "
        "JSON-LD structured data, per-product meta tags, and a 0-100 SEO health scorer. "
        "Stripe payments and AutoDS dropshipping are pre-built and disabled by default — "
        "enable them in Admin → Settings the moment you go online."
    )
    add_textbox(slide, summary, 0.8, 1.5, 11.7, 2.0, 14, False, LIGHT_GRAY, "center")

    stats = [
        ("6", "Demo Products"),
        ("14", "API Route Files"),
        ("16", "Database Tables"),
        ("10", "Admin Panel Tabs"),
        ("10", "SEO Features"),
        ("8", "CLI Tools"),
    ]
    for i, (num, label) in enumerate(stats):
        x = 0.5 + i * 2.05
        add_rect(slide, x, 3.7, 1.9, 1.5, CARD_BG)
        add_textbox(slide, num, x, 3.8, 1.9, 0.7, 36, True, ACCENT, "center")
        add_textbox(slide, label, x, 4.5, 1.9, 0.55, 11, False, LIGHT_GRAY, "center")

    quick = [
        ("Windows", "Double-click run_pc.bat"),
        ("Linux/Mac", "chmod +x run_pc.sh && ./run_pc.sh"),
        ("Android", "Pydroid3 → open app.py → ▶"),
        ("Manual", "pip install -r requirements.txt && python app.py"),
    ]
    for i, (platform, cmd) in enumerate(quick):
        x = 0.5 + i * 3.2
        add_rect(slide, x, 5.5, 3.0, 1.0, (20, 30, 70))
        add_textbox(slide, platform, x + 0.1, 5.55, 2.8, 0.35, 12, True, ACCENT, "center")
        add_textbox(slide, cmd, x + 0.1, 5.88, 2.8, 0.55, 10, False, LIGHT_GRAY, "center", font_name="Courier New")

    add_textbox(slide, "http://localhost:5000   ·   admin@webdesignscare.com   ·   SAVE10  SAVE20  FLAT5  WELCOME",
                0.5, 6.8, 12.3, 0.4, 12, False, (71, 85, 105), "center")

    prs.save(output_file)
    return output_file


def main():
    parser = argparse.ArgumentParser(description="Generate PowerPoint presentation for Web Designs & Care")
    parser.add_argument("--output", "-o", default="web_designs_care_presentation.pptx",
                        help="Output file name (default: web_designs_care_presentation.pptx)")
    args = parser.parse_args()

    if not check_pptx():
        sys.exit(1)

    print("")
    print("=" * 52)
    print("  Web Designs & Care — Presentation Generator")
    print("=" * 52)
    print("")
    print("Creating 8-slide PowerPoint presentation...")

    output_file = create_presentation(args.output)
    size_kb = os.path.getsize(output_file) / 1024

    print("")
    print("  [OK] Presentation created!")
    print("  File: {}".format(output_file))
    print("  Size: {:.1f} KB".format(size_kb))
    print("  Slides: 8")
    print("")
    print("  Open with: Microsoft PowerPoint, LibreOffice Impress,")
    print("             or Google Slides (File → Import)")
    print("=" * 52)
    print("")


if __name__ == "__main__":
    main()
