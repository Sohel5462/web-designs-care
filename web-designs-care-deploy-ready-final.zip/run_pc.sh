#!/bin/bash
echo ""
echo "=========================================="
echo "  Web Designs & Care — Start (Mac/Linux)"
echo "=========================================="
echo ""
python3 --version >/dev/null 2>&1 && PY=python3 || PY=python
echo "Using: $PY"
echo ""
echo "[1/3] Installing dependencies..."
$PY -m pip install Flask==3.0.3 Flask-Cors==4.0.1 SQLAlchemy==2.0.31 PyJWT==2.8.0 Werkzeug==3.0.3 --quiet
echo "  Done."
echo ""
echo "[2/3] Ready."
echo ""
echo "  Browser:      http://localhost:5000"
echo "  Admin panel:  http://localhost:5000/admin-panel"
echo "  My Downloads: http://localhost:5000/my-downloads"
echo "  Admin login:  admin@webdesignscare.com / admin123"
echo ""
echo "[3/3] Starting server... Press Ctrl+C to stop."
echo ""
$PY app.py
