/**
 * Web Designs & Care — Wallet Widget
 * Floating wallet balance badge + checkout interceptor for the React storefront.
 * - Shows live balance for logged-in users
 * - "Pay with Wallet" toggle: intercepts /api/orders POST and sets paymentMethod='wallet'
 * - Top-up shortcut without leaving the store
 */
(function () {
  'use strict';

  // Skip on admin panel
  if (window.__wdcAdminPanel) return;

  let _walletBalance = null;
  let _useWallet = false;
  let _user = null;
  let _visible = false;

  // ─── Inject CSS ──────────────────────────────────────────────────────────────
  var style = document.createElement('style');
  style.textContent = [
    '#wdc-wallet-btn{position:fixed;bottom:90px;right:20px;z-index:9990;background:#10b981;color:#fff;',
    'border:none;border-radius:999px;padding:10px 16px;font-size:0.82rem;font-weight:700;cursor:pointer;',
    'box-shadow:0 4px 16px rgba(0,0,0,0.25);display:flex;align-items:center;gap:7px;transition:all 0.2s;}',
    '#wdc-wallet-btn:hover{background:#059669;transform:scale(1.04);}',
    '#wdc-wallet-btn.hidden{display:none!important;}',
    '#wdc-wallet-panel{position:fixed;bottom:150px;right:20px;z-index:9991;width:280px;',
    'background:#1e293b;border:1px solid #334155;border-radius:16px;padding:0;overflow:hidden;',
    'box-shadow:0 12px 40px rgba(0,0,0,0.5);display:none;flex-direction:column;}',
    '#wdc-wallet-panel.open{display:flex;}',
    '#wdc-wp-header{background:linear-gradient(135deg,#064e3b,#1e293b);padding:16px 18px;',
    'display:flex;align-items:center;justify-content:space-between;}',
    '#wdc-wp-header h3{margin:0;font-size:0.9rem;font-weight:700;color:#fff;}',
    '#wdc-wp-close{background:none;border:none;color:#94a3b8;font-size:1.1rem;cursor:pointer;padding:2px 6px;}',
    '#wdc-wp-balance{padding:14px 18px;border-bottom:1px solid #334155;}',
    '#wdc-wp-bal-lbl{font-size:0.72rem;color:#94a3b8;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:3px;}',
    '#wdc-wp-bal-val{font-size:1.9rem;font-weight:900;color:#4ade80;letter-spacing:-0.02em;}',
    '#wdc-wp-toggle{padding:12px 18px;border-bottom:1px solid #334155;display:flex;align-items:center;gap:10px;}',
    '#wdc-wp-toggle label{font-size:0.82rem;color:#f1f5f9;flex:1;cursor:pointer;}',
    '#wdc-wp-toggle input{width:16px;height:16px;cursor:pointer;accent-color:#10b981;}',
    '#wdc-wp-actions{padding:12px 18px;display:flex;flex-direction:column;gap:8px;}',
    '#wdc-wp-topup-row{display:flex;gap:8px;}',
    '#wdc-wp-topup-input{flex:1;padding:8px 10px;background:#273549;border:1px solid #475569;',
    'border-radius:8px;color:#f1f5f9;font-size:0.82rem;outline:none;}',
    '#wdc-wp-topup-btn{padding:8px 14px;background:#10b981;color:#fff;border:none;',
    'border-radius:8px;font-size:0.8rem;font-weight:700;cursor:pointer;}',
    '#wdc-wp-topup-btn:hover{background:#059669;}',
    '#wdc-wp-link{text-align:center;padding:0 0 10px;font-size:0.75rem;color:#3b82f6;text-decoration:none;display:block;}',
    '#wdc-wp-link:hover{color:#60a5fa;}',
    '#wdc-wallet-toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%) translateY(60px);',
    'background:#1e293b;border:1px solid #334155;border-radius:10px;padding:10px 20px;font-size:0.82rem;',
    'color:#f1f5f9;z-index:9999;opacity:0;transition:all 0.3s;white-space:nowrap;}',
    '#wdc-wallet-toast.show{transform:translateX(-50%) translateY(0);opacity:1;}',
  ].join('');
  document.head.appendChild(style);

  // ─── Create DOM ──────────────────────────────────────────────────────────────
  function createDOM() {
    var btn = document.createElement('button');
    btn.id = 'wdc-wallet-btn';
    btn.className = 'hidden';
    btn.innerHTML = '💰 <span id="wdc-wb-bal">Wallet</span>';
    btn.onclick = togglePanel;
    document.body.appendChild(btn);

    var panel = document.createElement('div');
    panel.id = 'wdc-wallet-panel';
    panel.innerHTML = [
      '<div id="wdc-wp-header">',
      '  <h3>💰 My Wallet</h3>',
      '  <button id="wdc-wp-close" onclick="document.getElementById(\'wdc-wallet-panel\').classList.remove(\'open\')">✕</button>',
      '</div>',
      '<div id="wdc-wp-balance">',
      '  <div id="wdc-wp-bal-lbl">Available Balance</div>',
      '  <div id="wdc-wp-bal-val">Loading...</div>',
      '</div>',
      '<div id="wdc-wp-toggle">',
      '  <input type="checkbox" id="wdc-use-wallet" onchange="window.__wdcWalletToggle(this.checked)">',
      '  <label for="wdc-use-wallet">Use wallet for next checkout</label>',
      '</div>',
      '<div id="wdc-wp-actions">',
      '  <div id="wdc-wp-topup-row">',
      '    <input type="number" id="wdc-wp-topup-input" placeholder="Top-up amount ($)" min="1" step="1">',
      '    <button id="wdc-wp-topup-btn" onclick="window.__wdcTopup()">Add</button>',
      '  </div>',
      '</div>',
      '<a href="/my-downloads" id="wdc-wp-link">→ Full wallet &amp; transaction history</a>',
    ].join('');
    document.body.appendChild(panel);

    var toast = document.createElement('div');
    toast.id = 'wdc-wallet-toast';
    document.body.appendChild(toast);
  }

  function showToast(msg, ms) {
    var t = document.getElementById('wdc-wallet-toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(function () { t.classList.remove('show'); }, ms || 2500);
  }

  function togglePanel() {
    var panel = document.getElementById('wdc-wallet-panel');
    if (panel) panel.classList.toggle('open');
  }

  function updateBalanceDisplay(bal) {
    _walletBalance = bal;
    var fmted = '$' + parseFloat(bal || 0).toFixed(2);
    var balEl = document.getElementById('wdc-wp-bal-val');
    var btnBal = document.getElementById('wdc-wb-bal');
    if (balEl) balEl.textContent = fmted;
    if (btnBal) btnBal.textContent = fmted;
  }

  window.__wdcWalletToggle = function (checked) {
    _useWallet = checked;
    showToast(checked ? '✅ Wallet payment enabled for next checkout' : '💳 Switched to standard payment', 2000);
  };

  window.__wdcTopup = function () {
    var input = document.getElementById('wdc-wp-topup-input');
    var amount = parseFloat(input ? input.value : 0);
    if (!amount || amount < 1) { showToast('⚠️ Enter at least $1', 2000); return; }
    fetch('/api/wallet/topup', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: amount }),
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (d.error) { showToast('❌ ' + d.error, 3000); return; }
      updateBalanceDisplay(d.newBalance);
      if (input) input.value = '';
      showToast('✅ Added $' + amount.toFixed(2) + '! Balance: $' + parseFloat(d.newBalance).toFixed(2), 3000);
    }).catch(function () { showToast('❌ Top-up failed', 2500); });
  };

  // ─── Fetch interceptor for checkout ──────────────────────────────────────────
  var _origFetch = window.fetch;
  window.fetch = function (url, opts) {
    // Intercept POST /api/orders to inject wallet payment method
    if (_useWallet && typeof url === 'string' && url.indexOf('/api/orders') !== -1
        && opts && opts.method === 'POST') {
      try {
        var body = typeof opts.body === 'string' ? JSON.parse(opts.body) : (opts.body || {});
        if (!body.paymentMethod || body.paymentMethod === 'demo') {
          if (_walletBalance !== null && _walletBalance <= 0) {
            showToast('⚠️ Wallet balance is $0. Switching to demo payment.', 3000);
            _useWallet = false;
            var cb = document.getElementById('wdc-use-wallet');
            if (cb) cb.checked = false;
          } else {
            body.paymentMethod = 'wallet';
            opts = Object.assign({}, opts, { body: JSON.stringify(body) });
          }
        }
      } catch (e) {}
      // After checkout, refresh balance and reset toggle
      return _origFetch.call(this, url, opts).then(function (resp) {
        var clone = resp.clone();
        clone.json().then(function (d) {
          if (d && d.orderId) {
            _useWallet = false;
            var cb = document.getElementById('wdc-use-wallet');
            if (cb) cb.checked = false;
            refreshBalance();
            showToast('✅ Order #' + d.orderId + ' paid from wallet!', 3000);
          }
        }).catch(function () {});
        return resp;
      });
    }
    return _origFetch.apply(this, arguments);
  };

  // ─── Load user + balance ──────────────────────────────────────────────────────
  function refreshBalance() {
    fetch('/api/wallet/balance', { credentials: 'include' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (d && d.balance !== undefined) {
          updateBalanceDisplay(d.balance);
          var btn = document.getElementById('wdc-wallet-btn');
          if (btn) btn.classList.remove('hidden');
        }
      }).catch(function () {});
  }

  function init() {
    fetch('/api/auth/me', { credentials: 'include' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (user) {
        if (user && user.id) {
          _user = user;
          createDOM();
          refreshBalance();
        }
      }).catch(function () {});
  }

  // ─── Start ───────────────────────────────────────────────────────────────────
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 300);
  }

  // Re-check auth when page focus returns (React SPA navigation)
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && _user) refreshBalance();
  });

})();
