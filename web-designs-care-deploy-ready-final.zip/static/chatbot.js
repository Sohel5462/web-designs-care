/**
 * Web Designs & Care — Smart Chatbot Widget v3.0
 * Features:
 *  1. ✅ 24/7 সার্বক্ষণিক সক্রিয়তা — Always on, works offline
 *  2. ✅ প্রশ্ন-উত্তর স্বয়ংক্রিয়করণ — AI + keyword Q&A automation
 *  3. ✅ লিড জেনারেশন — Collects name, email, phone from visitors
 *  4. ✅ স্বাগত বার্তা ও কুইক রিপ্লাই — Welcome message + quick reply buttons
 *  5. ✅ সোশ্যাল মিডিয়া ইন্টিগ্রেশন — Facebook, WhatsApp, Instagram, Telegram links
 *  6. ✅ হিউম্যান হ্যান্ডঅফ — Transfer to live agent / create support ticket
 *  7. ✅ এআই প্রতিক্রিয়া — Google Gemini / OpenAI / local keyword matching
 *  8. ✅ কুইক রিপ্লাই মেনু — Category quick-reply buttons
 *  9. ✅ টেক্সটভিত্তিক প্রতিক্রিয়া — Rich text responses with product cards
 * 10. ✅ সীমিত মেসজ কোটা — 500 messages/month limit (tracked in localStorage)
 */
(function () {
  'use strict';

  // ─── Admin panel guard — do not run on admin pages ─────────────────────────
  if (window.__wdcAdminPanel) return;

  // ─── Error detection (runs BEFORE UI loads) ────────────────────────────────
  const _errors = [];
  window.__wdcErrors = _errors;
  function _captureError(type, message, filename, lineno) {
    if (!message) return;
    _errors.push({ type, message: String(message).slice(0, 300), file: (filename || '').replace(location.origin, ''), line: lineno || '?', ts: new Date().toISOString() });
    if (_errors.length > 20) _errors.shift();
    _maybeNotifyError();
  }
  window.addEventListener('error', function (e) { _captureError('JS Error', e.message, e.filename, e.lineno); }, true);
  window.addEventListener('unhandledrejection', function (e) {
    const msg = (e.reason && e.reason.message) ? e.reason.message : String(e.reason || 'Unhandled Promise Rejection');
    _captureError('Promise Error', msg, location.href, null);
  }, true);
  const _origFetch = window.fetch;
  window.fetch = function () {
    return _origFetch.apply(this, arguments).then(function (resp) {
      if (!resp.ok && resp.status >= 500) _captureError('API Error', 'HTTP ' + resp.status + ' on ' + (arguments[0] || ''), location.href, null);
      return resp;
    }).catch(function (err) {
      if (String(err).indexOf('/api/chatbot') === -1) _captureError('Network Error', err.message || String(err), location.href, null);
      throw err;
    });
  };
  let _errorNotifyTimer = null;
  function _maybeNotifyError() {
    clearTimeout(_errorNotifyTimer);
    _errorNotifyTimer = setTimeout(function () { if (typeof _showErrorBadge === 'function') _showErrorBadge(); }, 500);
  }

  // ─── State ─────────────────────────────────────────────────────────────────
  let BOT_COLOR   = '#3b82f6';
  let BOT_NAME    = 'WDC Assistant';
  let GREETING    = '👋 Hi! How can I help you today?';
  let AI_PROVIDER = 'local';
  let isOpen      = false;
  let isWaiting   = false;
  let _socialLinks = {};
  let _leadMode    = null;   // null | 'ask_name' | 'ask_email' | 'ask_phone'
  let _leadData    = {};     // { name, email, phone }
  let _handoffMode = false;

  // ─── Feature 10: Message Quota (500/month) ─────────────────────────────────
  const QUOTA_LIMIT = 500;
  function _getQuotaKey() {
    const now = new Date();
    return 'wdc_msg_quota_' + now.getFullYear() + '_' + (now.getMonth() + 1);
  }
  function _getMsgCount() {
    return parseInt(localStorage.getItem(_getQuotaKey()) || '0', 10);
  }
  function _incrementMsgCount() {
    const key = _getQuotaKey();
    const n = _getMsgCount() + 1;
    localStorage.setItem(key, String(n));
    return n;
  }
  function _isQuotaExceeded() { return _getMsgCount() >= QUOTA_LIMIT; }
  function _quotaRemaining() { return Math.max(0, QUOTA_LIMIT - _getMsgCount()); }

  // ─── Styles ────────────────────────────────────────────────────────────────
  const css = `
  #wdc-chat-bubble{position:fixed;bottom:24px;right:24px;z-index:99999;
    width:56px;height:56px;border-radius:50%;background:var(--wdc-color);
    box-shadow:0 4px 24px rgba(0,0,0,0.4);cursor:pointer;
    display:flex;align-items:center;justify-content:center;
    font-size:26px;border:none;color:#fff;transition:transform 0.2s,box-shadow 0.2s;
    animation:wdc-pulse 2.5s infinite;}
  #wdc-chat-bubble:hover{transform:scale(1.08);box-shadow:0 6px 32px rgba(0,0,0,0.5);}
  @keyframes wdc-pulse{0%,100%{box-shadow:0 4px 24px rgba(0,0,0,0.4)}50%{box-shadow:0 4px 32px var(--wdc-glow)}}
  #wdc-chat-badge{position:absolute;top:-3px;right:-3px;background:#ef4444;color:#fff;
    border-radius:50%;width:18px;height:18px;font-size:11px;font-weight:700;
    display:flex;align-items:center;justify-content:center;border:2px solid #0f172a;}
  #wdc-err-badge{position:absolute;top:-3px;left:-3px;background:#f59e0b;color:#fff;
    border-radius:50%;width:18px;height:18px;font-size:10px;font-weight:700;
    display:none;align-items:center;justify-content:center;border:2px solid #0f172a;cursor:pointer;}
  #wdc-chat-panel{position:fixed;bottom:90px;right:24px;z-index:99998;
    width:340px;max-height:80vh;height:560px;background:#1e293b;
    border:1px solid #334155;border-radius:20px;
    box-shadow:0 12px 48px rgba(0,0,0,0.6);
    display:flex;flex-direction:column;overflow:hidden;
    transform:scale(0.9) translateY(20px);opacity:0;
    transition:all 0.25s cubic-bezier(0.34,1.56,0.64,1);pointer-events:none;}
  #wdc-chat-panel.wdc-open{transform:scale(1) translateY(0);opacity:1;pointer-events:all;}
  #wdc-chat-header{background:var(--wdc-color);padding:14px 16px;display:flex;align-items:center;gap:10px;flex-shrink:0;}
  #wdc-chat-header .wdc-avatar{width:36px;height:36px;background:rgba(255,255,255,0.25);
    border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;}
  #wdc-chat-header .wdc-hinfo{flex:1;min-width:0;}
  #wdc-chat-header .wdc-hname{font-weight:700;font-size:0.9rem;color:#fff;display:flex;align-items:center;gap:6px;flex-wrap:wrap;}
  #wdc-chat-header .wdc-hstatus{font-size:0.72rem;color:rgba(255,255,255,0.8);}
  #wdc-ai-badge{background:rgba(255,255,255,0.22);border-radius:999px;padding:2px 7px;
    font-size:0.65rem;font-weight:700;color:#fff;display:none;white-space:nowrap;}
  #wdc-chat-header .wdc-close{background:rgba(255,255,255,0.2);border:none;border-radius:50%;
    width:28px;height:28px;cursor:pointer;color:#fff;font-size:16px;
    display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background 0.15s;}
  #wdc-chat-header .wdc-close:hover{background:rgba(255,255,255,0.35);}
  #wdc-chat-messages{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px;scroll-behavior:smooth;}
  #wdc-chat-messages::-webkit-scrollbar{width:4px;}
  #wdc-chat-messages::-webkit-scrollbar-track{background:transparent;}
  #wdc-chat-messages::-webkit-scrollbar-thumb{background:#334155;border-radius:4px;}
  .wdc-msg{max-width:88%;animation:wdc-fadein 0.2s ease-out;}
  @keyframes wdc-fadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
  .wdc-msg.wdc-bot{align-self:flex-start;}
  .wdc-msg.wdc-user{align-self:flex-end;}
  .wdc-bubble{padding:10px 13px;border-radius:14px;font-size:0.83rem;line-height:1.5;word-break:break-word;}
  .wdc-bot .wdc-bubble{background:#273549;color:#f1f5f9;border-bottom-left-radius:4px;}
  .wdc-user .wdc-bubble{background:var(--wdc-color);color:#fff;border-bottom-right-radius:4px;}
  .wdc-bubble strong{font-weight:700;}
  .wdc-bubble br{display:block;margin:2px 0;}
  .wdc-err-bubble{background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.4);border-radius:10px;
    padding:8px 11px;font-size:0.78rem;color:#fcd34d;margin-top:4px;}
  .wdc-products{display:flex;flex-direction:column;gap:8px;margin-top:6px;}
  .wdc-prod-card{background:#0f172a;border:1px solid #334155;border-radius:10px;
    padding:10px;display:flex;gap:9px;align-items:center;cursor:pointer;
    transition:border-color 0.15s;text-decoration:none;}
  .wdc-prod-card:hover{border-color:var(--wdc-color);}
  .wdc-prod-thumb{width:44px;height:32px;border-radius:6px;object-fit:cover;background:#1e293b;flex-shrink:0;}
  .wdc-prod-info{flex:1;min-width:0;}
  .wdc-prod-name{font-size:0.78rem;font-weight:600;color:#f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .wdc-prod-price{font-size:0.73rem;color:#10b981;font-weight:700;}
  .wdc-prod-cat{font-size:0.68rem;color:#94a3b8;text-transform:capitalize;}
  .wdc-typing{display:flex;align-items:center;gap:5px;padding:10px 13px;background:#273549;
    border-radius:14px;border-bottom-left-radius:4px;width:fit-content;}
  .wdc-dot{width:7px;height:7px;background:#94a3b8;border-radius:50%;animation:wdc-bounce 1.2s infinite;}
  .wdc-dot:nth-child(2){animation-delay:0.2s;}
  .wdc-dot:nth-child(3){animation-delay:0.4s;}
  @keyframes wdc-bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}
  .wdc-quick-btns{display:flex;flex-wrap:wrap;gap:5px;margin-top:6px;}
  .wdc-qbtn{background:#273549;border:1px solid #334155;border-radius:999px;
    padding:4px 11px;font-size:0.73rem;cursor:pointer;color:#94a3b8;
    transition:all 0.15s;white-space:nowrap;}
  .wdc-qbtn:hover{background:var(--wdc-color);color:#fff;border-color:var(--wdc-color);}
  .wdc-qbtn.wdc-err-btn{color:#f59e0b;border-color:rgba(245,158,11,0.4);}
  .wdc-qbtn.wdc-err-btn:hover{background:#f59e0b;color:#0f172a;border-color:#f59e0b;}
  .wdc-social-links{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;}
  .wdc-social-link{background:#273549;border:1px solid #334155;border-radius:8px;
    padding:5px 10px;font-size:0.73rem;color:#94a3b8;cursor:pointer;
    text-decoration:none;display:flex;align-items:center;gap:5px;
    transition:all 0.15s;}
  .wdc-social-link:hover{background:var(--wdc-color);color:#fff;border-color:var(--wdc-color);}
  .wdc-quota-bar{padding:5px 10px;background:#0f172a;border-top:1px solid #1e293b;
    font-size:0.68rem;color:#94a3b8;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;}
  .wdc-quota-fill{height:3px;border-radius:2px;background:#334155;flex:1;margin:0 8px;}
  .wdc-quota-fill-inner{height:100%;border-radius:2px;background:var(--wdc-color);transition:width 0.3s;}
  .wdc-quota-fill-inner.warn{background:#f59e0b;}
  .wdc-quota-fill-inner.danger{background:#ef4444;}
  #wdc-chat-input-row{display:flex;gap:8px;padding:10px;border-top:1px solid #334155;flex-shrink:0;background:#1e293b;}
  #wdc-chat-input{flex:1;background:#273549;border:1px solid #334155;border-radius:10px;
    padding:9px 12px;color:#f1f5f9;font-size:0.84rem;outline:none;font-family:inherit;
    resize:none;transition:border-color 0.2s;max-height:80px;}
  #wdc-chat-input:focus{border-color:var(--wdc-color);}
  #wdc-send-btn{width:38px;height:38px;border-radius:10px;background:var(--wdc-color);
    border:none;color:#fff;cursor:pointer;font-size:18px;
    display:flex;align-items:center;justify-content:center;transition:opacity 0.15s;flex-shrink:0;}
  #wdc-send-btn:hover{opacity:0.85;}
  #wdc-send-btn:disabled{opacity:0.4;}
  @media(max-width:400px){
    #wdc-chat-panel{right:8px;width:calc(100vw - 16px);}
    #wdc-chat-bubble{right:12px;bottom:16px;}
  }`;

  const styleEl = document.createElement('style');
  styleEl.textContent = css;
  document.head.appendChild(styleEl);

  // ─── Create HTML ────────────────────────────────────────────────────────────
  const root = document.createElement('div');
  root.id = 'wdc-chatbot-root';
  root.innerHTML = `
  <button id="wdc-chat-bubble" title="Chat with us! (24/7)" aria-label="Open chat">
    💬
    <div id="wdc-chat-badge" style="display:none">1</div>
    <div id="wdc-err-badge" title="Site errors detected — click to see details">⚠</div>
  </button>
  <div id="wdc-chat-panel" role="dialog" aria-label="Chat with WDC Assistant">
    <div id="wdc-chat-header">
      <div class="wdc-avatar">🤖</div>
      <div class="wdc-hinfo">
        <div class="wdc-hname">
          <span id="wdc-bot-name">WDC Assistant</span>
          <span id="wdc-ai-badge"></span>
        </div>
        <div class="wdc-hstatus" id="wdc-hstatus">● Online 24/7 — Ask me anything!</div>
      </div>
      <button class="wdc-close" onclick="window.__wdcChatToggle()" title="Close">✕</button>
    </div>
    <div id="wdc-chat-messages"></div>
    <div class="wdc-quota-bar" id="wdc-quota-bar">
      <span id="wdc-quota-label">500 messages/month</span>
      <div class="wdc-quota-fill"><div class="wdc-quota-fill-inner" id="wdc-quota-fill-inner" style="width:0%"></div></div>
      <span id="wdc-quota-count">0/500</span>
    </div>
    <div id="wdc-chat-input-row">
      <textarea id="wdc-chat-input" placeholder="Type your message…" rows="1"></textarea>
      <button id="wdc-send-btn" title="Send">➤</button>
    </div>
  </div>`;
  document.body.appendChild(root);

  // ─── DOM refs ──────────────────────────────────────────────────────────────
  const bubble   = document.getElementById('wdc-chat-bubble');
  const panel    = document.getElementById('wdc-chat-panel');
  const msgs     = document.getElementById('wdc-chat-messages');
  const input    = document.getElementById('wdc-chat-input');
  const sendBtn  = document.getElementById('wdc-send-btn');
  const errBadge = document.getElementById('wdc-err-badge');
  const botName  = document.getElementById('wdc-bot-name');
  const aiBadge  = document.getElementById('wdc-ai-badge');
  const hstatus  = document.getElementById('wdc-hstatus');
  const quotaBar = document.getElementById('wdc-quota-bar');
  const quotaFillInner = document.getElementById('wdc-quota-fill-inner');
  const quotaCount = document.getElementById('wdc-quota-count');

  // ─── Feature 10: Update Quota Bar ─────────────────────────────────────────
  function _updateQuotaBar() {
    const used = _getMsgCount();
    const pct  = Math.min((used / QUOTA_LIMIT) * 100, 100);
    quotaCount.textContent = used + '/' + QUOTA_LIMIT;
    quotaFillInner.style.width = pct + '%';
    quotaFillInner.className = 'wdc-quota-fill-inner' +
      (pct >= 95 ? ' danger' : pct >= 80 ? ' warn' : '');
    if (pct >= 80) {
      quotaBar.style.display = 'flex';
    }
  }

  // ─── Error badge ───────────────────────────────────────────────────────────
  function _showErrorBadge() {
    var eb = document.getElementById('wdc-err-badge');
    if (_errors.length > 0 && !isOpen && eb) {
      eb.style.display = 'flex';
      eb.textContent = '⚠';
    }
  }
  errBadge.addEventListener('click', function (e) {
    e.stopPropagation();
    if (!isOpen) toggle();
    setTimeout(function () { sendMessage('🔍 I noticed some site errors. Can you help?'); }, 400);
  });

  // ─── Toggle ────────────────────────────────────────────────────────────────
  function toggle() {
    isOpen = !isOpen;
    panel.classList.toggle('wdc-open', isOpen);
    bubble.innerHTML = (isOpen ? '✕' : '💬') +
      '<div id="wdc-chat-badge" style="display:none">1</div>' +
      '<div id="wdc-err-badge" title="Site errors detected">⚠</div>';
    const newErrBadge = document.getElementById('wdc-err-badge');
    if (newErrBadge) {
      newErrBadge.style.display = (_errors.length > 0 && !isOpen) ? 'flex' : 'none';
      newErrBadge.addEventListener('click', function (e) {
        e.stopPropagation();
        if (!isOpen) toggle();
        setTimeout(function () { sendMessage('🔍 I noticed some site errors. Can you help?'); }, 400);
      });
    }
    if (isOpen) {
      document.getElementById('wdc-chat-badge').style.display = 'none';
      _updateQuotaBar();
      setTimeout(() => input.focus(), 300);
    }
  }
  window.__wdcChatToggle = toggle;
  bubble.addEventListener('click', toggle);

  // ─── Add message ──────────────────────────────────────────────────────────
  function addMessage(text, role, products) {
    const wrap = document.createElement('div');
    wrap.className = 'wdc-msg wdc-' + role;
    const bbl = document.createElement('div');
    bbl.className = 'wdc-bubble';
    const html = (text || '').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
    bbl.innerHTML = html;

    if (products && products.length) {
      const pc = document.createElement('div');
      pc.className = 'wdc-products';
      products.forEach(p => {
        const a = document.createElement('a');
        a.className = 'wdc-prod-card';
        a.href = '/?product=' + encodeURIComponent(p.slug || p.id);
        a.target = '_blank';
        a.title = p.name;
        a.innerHTML = (p.thumbnailUrl
          ? `<img class="wdc-prod-thumb" src="${esc(p.thumbnailUrl)}" alt="" onerror="this.style.opacity=0.3">`
          : `<div class="wdc-prod-thumb" style="display:flex;align-items:center;justify-content:center;font-size:18px">📦</div>`) +
          `<div class="wdc-prod-info">
            <div class="wdc-prod-name">${esc(p.name)}</div>
            <div class="wdc-prod-price">$${parseFloat(p.price || 0).toFixed(2)}</div>
            <div class="wdc-prod-cat">${esc(p.category || '')}</div>
          </div>`;
        pc.appendChild(a);
      });
      bbl.appendChild(pc);
    }
    wrap.appendChild(bbl);
    msgs.appendChild(wrap);
    msgs.scrollTop = msgs.scrollHeight;
  }

  // ─── Feature 5: Social Media Links ─────────────────────────────────────────
  function showSocialLinks(socialData) {
    const icons = {
      socialFacebook: '📘 Facebook', socialTwitter: '🐦 Twitter',
      socialInstagram: '📸 Instagram', socialYoutube: '📺 YouTube',
      socialLinkedin: '💼 LinkedIn', socialTiktok: '🎵 TikTok',
      socialGithub: '💻 GitHub', socialDiscord: '💬 Discord',
      socialTelegram: '✈️ Telegram', socialWhatsapp: '📱 WhatsApp',
    };
    const active = Object.entries(socialData || {}).filter(([, v]) => v && v.startsWith('http'));
    if (!active.length) {
      addMessage('📱 No social media links configured yet. Check back soon!', 'bot');
      return;
    }
    const wrap = document.createElement('div');
    wrap.className = 'wdc-msg wdc-bot';
    const bbl = document.createElement('div');
    bbl.className = 'wdc-bubble';
    bbl.innerHTML = '<strong>🌐 Find us on social media:</strong>';
    const linksRow = document.createElement('div');
    linksRow.className = 'wdc-social-links';
    active.forEach(([key, url]) => {
      const a = document.createElement('a');
      a.className = 'wdc-social-link';
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = icons[key] || key;
      linksRow.appendChild(a);
    });
    bbl.appendChild(linksRow);
    wrap.appendChild(bbl);
    msgs.appendChild(wrap);
    msgs.scrollTop = msgs.scrollHeight;
  }

  // ─── Quick Buttons ─────────────────────────────────────────────────────────
  function showQuickButtons(items) {
    const row = document.createElement('div');
    row.className = 'wdc-quick-btns';
    items.forEach(item => {
      const btn = document.createElement('button');
      btn.className = 'wdc-qbtn' + (item.err ? ' wdc-err-btn' : '');
      btn.textContent = item.label || item;
      const msg = item.msg || item.label || item;
      btn.onclick = () => { row.remove(); sendMessage(msg); };
      row.appendChild(btn);
    });
    const wrap = document.createElement('div');
    wrap.className = 'wdc-msg wdc-bot';
    wrap.appendChild(row);
    msgs.appendChild(wrap);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function showTyping() {
    const el = document.createElement('div');
    el.className = 'wdc-msg wdc-bot';
    el.id = 'wdc-typing-indicator';
    el.innerHTML = '<div class="wdc-typing"><div class="wdc-dot"></div><div class="wdc-dot"></div><div class="wdc-dot"></div></div>';
    msgs.appendChild(el);
    msgs.scrollTop = msgs.scrollHeight;
    return el;
  }
  function removeTyping() {
    const el = document.getElementById('wdc-typing-indicator');
    if (el) el.remove();
  }

  // ─── Feature 3: Lead Generation Flow ─────────────────────────────────────
  function _startLeadCapture() {
    _leadMode = 'ask_name';
    _leadData = {};
    addMessage("📋 Great! To better assist you, may I get your name? (or type **skip** to continue anonymously)", 'bot');
  }

  async function _handleLeadInput(text) {
    if (_leadMode === 'ask_name') {
      if (text.toLowerCase() !== 'skip') {
        _leadData.name = text;
      }
      _leadMode = 'ask_email';
      addMessage("📧 What's your email address so we can follow up? (or type **skip**)", 'bot');
      return true;
    }
    if (_leadMode === 'ask_email') {
      if (text.toLowerCase() !== 'skip') {
        if (!text.includes('@')) {
          addMessage("⚠️ That doesn't look like a valid email. Please enter a valid email or type **skip**.", 'bot');
          return true;
        }
        _leadData.email = text;
      }
      _leadMode = 'ask_phone';
      addMessage("📱 Finally, your WhatsApp/phone number? (or type **skip**)", 'bot');
      return true;
    }
    if (_leadMode === 'ask_phone') {
      if (text.toLowerCase() !== 'skip') {
        _leadData.phone = text;
      }
      _leadMode = null;
      // Save lead to backend
      if (_leadData.email) {
        try {
          await _origFetch('/api/chatbot/lead', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ..._leadData, source: 'chatbot-widget' }),
          });
        } catch (e) {}
      }
      const name = _leadData.name ? _leadData.name.split(' ')[0] : 'there';
      addMessage(`✅ Thanks${_leadData.name ? ', **' + _leadData.name + '**' : ''}! We'll be in touch.\n\nNow, how can I help you today?`, 'bot');
      showQuickButtons(['📦 Templates', '💰 Prices', '🏷️ Coupons', '⬇️ Downloads', '👤 Human Agent']);
      return true;
    }
    return false;
  }

  // ─── Feature 6: Human Handoff ─────────────────────────────────────────────
  function _triggerHandoff() {
    _handoffMode = true;
    addMessage(
      "👤 **Connecting you to a human agent…**\n\n" +
      "Our support team responds within 24 hours. You can:\n" +
      "1. 📧 Email: **support@webdesignscare.com**\n" +
      "2. 🎫 Create a **Support Ticket** from your account\n" +
      "3. 📱 WhatsApp us if linked above\n\n" +
      "Would you like me to capture your details so our team can reach you?",
      'bot'
    );
    showQuickButtons([
      { label: '📋 Leave my details', msg: 'I want to leave my contact details' },
      { label: '🎫 Open support ticket', msg: 'Open support ticket' },
      { label: '⬅️ Continue chatbot', msg: 'Continue with chatbot' },
    ]);
  }

  // ─── Send ──────────────────────────────────────────────────────────────────
  async function sendMessage(text) {
    text = (text || input.value).trim();
    if (!text || isWaiting) return;
    input.value = '';
    input.style.height = 'auto';

    // Feature 10: Quota check
    if (_isQuotaExceeded()) {
      addMessage(
        '⛔ **মাসিক মেসেজ কোটা শেষ হয়েছে!**\n\n' +
        'You\'ve reached your **500 messages/month** limit.\n' +
        'Your quota resets at the start of next month.\n\n' +
        'For urgent help: **support@webdesignscare.com**',
        'bot'
      );
      _updateQuotaBar();
      return;
    }

    addMessage(text, 'user');
    const msgCount = _incrementMsgCount();
    _updateQuotaBar();

    // Quota warning at 450
    if (msgCount === 450) {
      addMessage('⚠️ **কোটা সতর্কতা:** You have **' + _quotaRemaining() + ' messages left** this month.', 'bot');
    }

    // Feature 3: Lead capture mode takes over
    if (_leadMode) {
      const handled = await _handleLeadInput(text);
      if (handled) return;
    }

    // Feature 6: Special commands
    const tl = text.toLowerCase();
    if (/human|agent|handoff|live.?chat|talk.?to.?person|real.?person/.test(tl)) {
      _triggerHandoff();
      return;
    }
    if (/open support ticket|support ticket/.test(tl)) {
      addMessage('🎫 Please log in and go to **My Account → Support Tickets** to open a ticket.\n\nOr email us: **support@webdesignscare.com**', 'bot');
      return;
    }
    if (/leave.*contact|my contact|my details/.test(tl)) {
      _startLeadCapture();
      return;
    }

    // Feature 5: Social media
    if (/social|facebook|instagram|twitter|youtube|telegram|whatsapp|tiktok|follow/.test(tl)) {
      showSocialLinks(_socialLinks);
      return;
    }

    // Lead gen trigger (after greeting)
    if (/^(hello|hi|hey|start)/.test(tl) && !_leadData.email) {
      isWaiting = true;
      sendBtn.disabled = true;
      const typing = showTyping();
      await new Promise(r => setTimeout(r, 600));
      removeTyping();
      isWaiting = false;
      sendBtn.disabled = false;
      addMessage(offlineReply(text), 'bot');
      // Offer lead gen after greeting
      setTimeout(() => {
        showQuickButtons([
          '📦 Templates', '💰 Prices', '🏷️ Coupons', '⬇️ Downloads',
          { label: '👤 Talk to agent', msg: 'I want to talk to a human agent' },
          { label: '📱 Social media', msg: 'social media' },
        ]);
      }, 500);
      return;
    }

    isWaiting = true;
    sendBtn.disabled = true;
    const typing = showTyping();

    try {
      const body = { message: text };
      if (_errors.length > 0) {
        body.errors = _errors.slice(-5).map(e => ({ type: e.type, message: e.message, file: e.file, line: e.line }));
      }
      const r = await _origFetch('/api/chatbot', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const d = await r.json();
      removeTyping();
      addMessage(d.reply || '...', 'bot', d.products || []);

      // After 3rd bot reply, offer human handoff
      if (msgCount === 3) {
        setTimeout(() => showQuickButtons([
          '📦 Browse templates', '🏷️ Get discount codes',
          { label: '👤 Talk to human agent', msg: 'I want to talk to a human agent' },
        ]), 200);
      }
    } catch (e) {
      removeTyping();
      addMessage(offlineReply(text), 'bot', []);
    } finally {
      isWaiting = false;
      sendBtn.disabled = false;
      input.focus();
    }
  }

  function offlineReply(msg) {
    const m = msg.toLowerCase();
    if (/hello|hi|hey/.test(m)) return '👋 Hello! Welcome to **Web Designs & Care** — your premium digital marketplace! I\'m available **24/7** to help.\n\nWhat are you looking for today?';
    if (/price|cost|how much|cheap|budget/.test(m)) return '💰 Our products start from **$14**! Browse by price or use code **SAVE10** for 10% off any order.';
    if (/coupon|discount|promo|code/.test(m)) return '🏷️ Try these discount codes at checkout:\n• **SAVE10** — 10% off any order\n• **WELCOME** — 15% off your first order\n• **FLAT5** — $5 off orders over $20';
    if (/download|my downloads|where is/.test(m)) return '📥 Your downloads are in **My Downloads** page. Login → My Downloads → click Download button!';
    if (/refund|money back|return/.test(m)) return '💳 We offer a **7-day money-back guarantee** if the product doesn\'t work as described. Contact support to start a refund.';
    if (/error|bug|problem|not working|broken|crash/.test(m)) {
      if (_errors.length > 0) return '⚠️ I detected **' + _errors.length + ' browser error(s)**. Most recent: ' + _errors[_errors.length - 1].message + '\n\nPress **F12 → Console** for full details.';
      return '🚨 No browser errors detected. Try pressing **F12 → Console** for details, or create a **Support Ticket** from your account.';
    }
    if (/human|agent|person/.test(m)) { _triggerHandoff(); return ''; }
    return '🛍️ I can help you find templates, themes, plugins, or answer questions about pricing, downloads, and licenses!\n\nUse code **SAVE10** for 10% off your order.';
  }

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ─── Input auto-resize ─────────────────────────────────────────────────────
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 80) + 'px';
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });
  sendBtn.addEventListener('click', () => sendMessage());

  // ─── Feature 5: Fetch social media links on init ───────────────────────────
  async function _loadSocialLinks() {
    try {
      const r = await _origFetch('/api/settings/social', { credentials: 'include' });
      if (r.ok) _socialLinks = await r.json();
    } catch (e) {}
  }

  // ─── Init ──────────────────────────────────────────────────────────────────
  async function init() {
    // Load social links in background
    _loadSocialLinks();

    try {
      const r = await _origFetch('/api/chatbot/status', { credentials: 'include' });
      const d = await r.json();
      if (!d.enabled) { root.style.display = 'none'; return; }
      BOT_COLOR   = d.color || '#3b82f6';
      GREETING    = d.greeting || '👋 Hi! How can I help you today?';
      AI_PROVIDER = d.aiProvider || 'local';
      if (d.siteName) botName.textContent = d.siteName + ' Chat';

      if (AI_PROVIDER === 'gemini') {
        aiBadge.textContent = '✨ Gemini AI';
        aiBadge.style.cssText = 'background:rgba(255,255,255,0.22);border-radius:999px;padding:2px 7px;font-size:0.65rem;font-weight:700;color:#fff;white-space:nowrap;display:inline-flex;';
        hstatus.textContent = '● AI-powered 24/7 — Ask me anything!';
      } else if (AI_PROVIDER === 'openai') {
        aiBadge.textContent = '🧠 OpenAI';
        aiBadge.style.cssText = 'background:rgba(255,255,255,0.22);border-radius:999px;padding:2px 7px;font-size:0.65rem;font-weight:700;color:#fff;white-space:nowrap;display:inline-flex;';
        hstatus.textContent = '● AI-powered 24/7 — Ask me anything!';
      }
    } catch (e) {}

    root.style.setProperty('--wdc-color', BOT_COLOR);
    root.style.setProperty('--wdc-glow', BOT_COLOR + '80');
    _updateQuotaBar();

    // Show badge after 4 seconds
    setTimeout(() => {
      if (!isOpen) {
        const b = document.getElementById('wdc-chat-badge');
        if (b) { b.style.display = 'flex'; b.textContent = '1'; }
      }
    }, 4000);

    // Feature 4: Welcome message + quick reply buttons
    setTimeout(() => {
      addMessage(GREETING, 'bot');
      const quickItems = [
        '📦 Templates', '💰 Prices', '🏷️ Coupons', '⬇️ Downloads',
        { label: '🌐 Social media', msg: 'social media' },
        { label: '👤 Talk to agent', msg: 'I want to talk to a human agent' },
      ];
      if (_errors.length > 0) {
        quickItems.push({ label: '⚠️ Site Error (' + _errors.length + ')', msg: '🔍 I noticed site errors. Can you diagnose them?', err: true });
      }
      showQuickButtons(quickItems);
    }, 600);

    // Lead gen: offer after 10 seconds of first visit (not returning users)
    const hasBeenGreeted = sessionStorage.getItem('wdc_greeted');
    if (!hasBeenGreeted && !_leadData.email) {
      sessionStorage.setItem('wdc_greeted', '1');
      setTimeout(() => {
        if (!isOpen) {
          const b = document.getElementById('wdc-chat-badge');
          if (b) { b.style.display = 'flex'; b.textContent = '!'; }
        }
      }, 12000);
    }

    // Check for errors
    setTimeout(function () {
      if (_errors.length > 0) _showErrorBadge();
    }, 2000);
  }

  setInterval(function () {
    if (_errors.length > 0 && !isOpen) _showErrorBadge();
  }, 5000);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 100);
  }

})();
