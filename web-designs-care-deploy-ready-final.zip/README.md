# Web Designs & Care v2 — Fixed Edition

A self-hosted **digital product marketplace** built with Python Flask + SQLite.
Sell website templates, themes, plugins, UI kits, and more — no third-party platform needed.

---

## Quick Start

```bash
# Install dependencies (Python 3.8+)
pip install flask flask-cors sqlalchemy pyjwt

# Start the server
python app.py

# Open in browser
http://localhost:5000            ← Customer storefront
http://localhost:5000/admin      ← Admin panel
http://localhost:5000/my-downloads.html  ← Customer downloads page
```

---

## Default Admin Login

| Field    | Value                        |
|----------|------------------------------|
| Email    | admin@webdesignscare.com     |
| Password | admin123                     |

> Admin account is auto-created on first run. Login on the admin panel.

---

## Admin Panel — 13 Tabs

| # | Tab | What you can do |
|---|-----|----------------|
| 1 | 📊 **Dashboard** | Total revenue, orders, tickets, unread messages, recent orders |
| 2 | 📈 **Analytics** | Monthly revenue chart, top-selling products, category breakdown |
| 3 | 📦 **Products** | Add / edit / delete / duplicate products; upload downloadable file (⬆️ Upload) |
| 4 | 🧾 **Orders** | View all customer orders, update status, issue refunds |
| 5 | 🏷️ **Coupons** | Create percentage or fixed discount coupons with expiry and usage limits |
| 6 | ⭐ **Reviews** | Approve / hide / reply to / delete customer product reviews |
| 7 | 👥 **Users** | View all customers, adjust wallet balance, promote to admin |
| 8 | 🎫 **Support Tickets** | Reply to and close support tickets from customers |
| 9 | 💬 **Messages** | Read and reply to contact form messages |
| 10 | 📧 **Newsletter** | Manage subscribers, send email newsletters via SMTP |
| 11 | 📄 **Pages** | Edit About Us, FAQ, Terms, Privacy Policy, Refund Policy |
| 12 | ⚙️ **Settings** | Site name, colors, SEO tags, SMTP, social links, chatbot toggle |
| 13 | 💾 **Backup** | Download full SQLite database backup |

---

## Product File Upload

1. Open **Products** tab → find the product row
2. Click **⬆️ Upload** button in the Actions column
3. Select the downloadable file (ZIP, PDF, etc.)
4. The file is stored on the server and customers receive a download link after purchase
5. The **File** column shows ✅ Uploaded or "No file"

---

## Reviews Management (⭐ Tab)

| Button | Action |
|--------|--------|
| ✓ **Show** | Make review visible on the storefront |
| ⏸ **Hide** | Hide review from customers (not deleted) |
| 💬 **Reply** | Add admin reply shown below the review |
| 🗑 **Delete** | Permanently remove the review |

Filter by status (All / Approved / Pending) or by star rating (1–5).

---

## Chatbot (🤖 Floating Widget)

Appears on all customer-facing pages (store, my-downloads).

- **Offline mode** — keyword matching in JavaScript, works without the server
- **Online mode** — calls `/api/chatbot` for contextual product recommendations
- **Admin control** — Settings tab → 🤖 Chatbot section:
  - Enable / disable toggle
  - Greeting message
  - Accent color
- **Handles**: pricing questions, downloads, license keys, templates, plugins, coupons, support, refunds

---

## Full API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Email + password login |
| POST | `/api/auth/register` | Register new account |
| POST | `/api/auth/demo-login` | Quick login without password (demo) |
| GET  | `/api/auth/me` | Get current user |
| POST | `/api/auth/logout` | Sign out |

### Products
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/products` | List products (query: limit, category, search, sort) |
| GET  | `/api/products/featured` | Featured products |
| GET  | `/api/products/<slug>` | Single product detail |
| GET  | `/api/admin/products` | Admin: all products |
| POST | `/api/admin/products` | Admin: create product |
| PUT  | `/api/admin/products/<id>` | Admin: update product |
| DELETE | `/api/admin/products/<id>` | Admin: delete product |
| POST | `/api/admin/products/<id>/upload` | Admin: upload downloadable file |
| POST | `/api/admin/products/<id>/duplicate` | Admin: duplicate product |

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/orders` | My orders |
| POST | `/api/orders` | Place new order |
| GET  | `/api/orders/downloads` | My downloadable files |
| GET  | `/api/orders/<id>/download/<product_id>` | Download file |
| GET  | `/api/admin/orders` | Admin: all orders |
| PUT  | `/api/admin/orders/<id>` | Admin: update order status |
| POST | `/api/admin/orders/<id>/refund` | Admin: issue refund |

### Reviews *(added in v2)*
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/reviews` | Customer: post a review |
| GET  | `/api/products/<slug>` | Reviews included in product detail |
| GET  | `/api/admin/reviews` | Admin: all reviews |
| PUT  | `/api/admin/reviews/<id>` | Admin: approve/hide/reply |
| DELETE | `/api/admin/reviews/<id>` | Admin: delete review |

### Coupons
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/admin/coupons` | Admin: list coupons |
| POST | `/api/admin/coupons` | Admin: create coupon |
| PUT  | `/api/admin/coupons/<id>` | Admin: update coupon |
| DELETE | `/api/admin/coupons/<id>` | Admin: delete coupon |

### Tickets & Messages
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET/POST | `/api/tickets` | Customer: my tickets / create ticket |
| GET | `/api/admin/tickets` | Admin: all tickets |
| PUT | `/api/admin/tickets/<id>` | Admin: reply / change status |
| DELETE | `/api/admin/tickets/<id>` | Admin: delete ticket |
| GET/PUT | `/api/admin/messages/<id>` | Admin: read / reply to contact message |

### Pages & Settings
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/pages/<slug>` | Get page (slug: about, faq, terms, privacy, refund) |
| PUT  | `/api/admin/pages/<slug>` | Admin: update page content |
| GET  | `/api/settings` | Get all site settings |
| PUT  | `/api/settings` | Admin: update settings |

### Chatbot
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/chatbot/status` | Is chatbot enabled? |
| POST | `/api/chatbot` | Send message, receive response |

### Newsletter
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/admin/newsletter/subscribers` | List all subscribers |
| POST | `/api/admin/newsletter/send` | Send newsletter |
| DELETE | `/api/admin/newsletter/subscribers/<id>` | Unsubscribe |

### Backup
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/admin/backup/info` | Database info (size, path, type) |
| GET  | `/api/admin/backup/download` | Download full SQLite backup |

---

## Project Structure

```
web-designs-care-python/
├── app.py                     ← Flask entry point; seed data; blueprint registration
├── database.py                ← All SQLAlchemy models + auto-migration
├── auth_helper.py             ← JWT helpers; require_auth; require_admin decorators
├── config.py                  ← Configuration (DATABASE_URL, SECRET_KEY)
├── routes/
│   ├── admin_routes.py        ← Stats, analytics, users, orders, coupons, backup
│   ├── auth_routes.py         ← Login, register, demo-login, logout, /me
│   ├── misc_routes.py         ← Chatbot, pages, newsletter, notifications, image upload
│   ├── order_routes.py        ← Orders, license keys, file downloads
│   ├── product_routes.py      ← Products, categories, file upload
│   ├── review_routes.py       ← Reviews (customer POST + full admin CRUD)
│   ├── settings_routes.py     ← Site settings, chatbot config
│   └── ticket_routes.py       ← Support tickets (customer + admin)
└── static/
    ├── admin-panel.html        ← Self-contained admin panel (13 tabs, no framework)
    ├── chatbot.js              ← Floating chat widget (offline + online)
    ├── index.html              ← Customer storefront (loads compiled React app)
    ├── my-downloads.html       ← Customer orders & downloads page
    └── assets/
        └── index-*.js          ← Compiled React frontend bundle
```

---

## Database Models

| Model | Table | Key Fields |
|-------|-------|-----------|
| User | users | id, email, name, role, wallet_balance, password_hash |
| Product | products | id, name, slug, price, category, status, file_path, rating |
| Order | orders | id, user_id, total, status, payment_method |
| OrderItem | order_items | id, order_id, product_id, price |
| License | licenses | id, order_item_id, key, is_revoked |
| **Review** | reviews | id, user_id, product_id, rating, comment, **is_approved**, **admin_reply** |
| Ticket | tickets | id, user_id, subject, status, priority, admin_reply |
| Coupon | coupons | id, code, type, value, max_uses, used_count, expires_at |
| ContactMessage | contact_messages | id, name, email, message, is_read, admin_reply |
| SiteSetting | site_settings | id, key, value |
| StaticPage | static_pages | id, slug, title, content |

---

## All Bug Fixes Applied in v2

| Bug | Root Cause | Fix |
|-----|-----------|-----|
| **Admin panel white screen** | Login overlay relied on CSS class `display:flex`; CSS variable `var(--bg)` fallback absent | Added `style="display:flex"` inline on overlay; `style="background:#0f172a"` inline on body |
| **CSS `inset` not supported** | `inset: 0` is CSS shorthand not supported in older browsers / Pydroid WebView | Replaced with explicit `top:0;left:0;right:0;bottom:0` everywhere |
| **Header CSS collision** | `<div class="header h1">` caused styling conflict with `h1` element styles | Removed extra class |
| **`/admin` URL 404** | Flask only had `/admin-panel`, React router caught `/admin` | Added `@app.route("/admin")` in app.py |
| **Add Product form out of tab** | `addProductPanel` div was outside the `#tab-products` div | Moved inside products tab div |
| **Login asked for Name** | Old form had Name field instead of Password | Replaced with Password input; real auth with demo fallback |
| **Sidebar broken on mobile** | `@media (max-width:700px) { .sidebar { display:none } }` hid sidebar completely | Added hamburger ☰ button + slide-in sidebar with backdrop overlay |
| **Reviews tab missing** | No UI to manage customer reviews | Added full ⭐ Reviews tab (approve/hide/reply/delete) |
| **Pages tab missing** | No UI to edit static pages | Added 📄 Pages tab (About, FAQ, Terms, Privacy, Refund) |
| **Chatbot missing** | No customer chat support | Added `chatbot.js` floating widget on all customer pages |
| **Review model missing fields** | `is_approved` and `admin_reply` columns didn't exist | Added columns + `_run_migrations()` auto-adds them to existing databases |
| **Coupon import error** | `Coupon` not imported in misc_routes.py | Added to import |

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Admin panel is blank / white | Ensure Flask is running: `python app.py` on port 5000 |
| Cannot log in to admin | Email: `admin@webdesignscare.com` — Password: `admin123` |
| "Not an admin" after login | Check user's `role` in DB is `admin` |
| File upload fails | The `static/uploads/` folder is auto-created; check disk space |
| Newsletter not sending | Configure SMTP host/user/pass in Settings → Marketing tab |
| DB error on startup | Delete `wdc.sqlite` and restart; fresh DB will be auto-seeded |
| Chatbot not appearing | Check Settings → Chatbot → toggle must be ON |
| Mobile sidebar not opening | Tap the ☰ hamburger button in the top-left of the admin header |

---

## Environment Requirements

- **Python**: 3.8 or newer
- **Packages**: `flask`, `flask-cors`, `sqlalchemy`, `pyjwt`
- **Database**: SQLite (auto-created as `wdc.sqlite`)
- **No `.env` file needed** — safe defaults are set in `config.py`
- **Port**: 5000 (configurable via `PORT` environment variable)
